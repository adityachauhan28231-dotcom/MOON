-- ============================================================================
-- MOON Messenger — Private 1-to-1 Chat Media Storage Bucket & RLS Policies
-- Zero Database Table Changes (Option A)
--
-- Security Model:
-- 1. Bucket `chat-media` is strictly PRIVATE (`public = false`).
-- 2. Object path format: `<sender_id>/<receiver_id>/<timestamp>_<filename>`
--    - (storage.foldername(name))[1] = sender_id (UUID)
--    - (storage.foldername(name))[2] = receiver_id (UUID)
-- 3. Reuses `public.are_friends(user_a, user_b)` so ONLY accepted friends in
--    `public.friendships (user1, user2)` can upload or view private media.
-- ============================================================================

-- 1. Ensure the friend-check helper function exists and uses canonical (user1, user2)
create or replace function public.are_friends(user_a uuid, user_b uuid)
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select exists (
    select 1
    from public.friendships f
    where (f.user1 = least(user_a, user_b) and f.user2 = greatest(user_a, user_b))
       or (f.user1 = user_a and f.user2 = user_b)
       or (f.user1 = user_b and f.user2 = user_a)
  );
$$;

-- 2. Create or update the PRIVATE `chat-media` bucket (never public)
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'chat-media',
  'chat-media',
  false,
  52428800, -- 50 MB max limit
  array[
    'image/jpeg',
    'image/png',
    'image/webp',
    'image/gif',
    'video/mp4',
    'video/webm',
    'video/quicktime',
    'video/3gpp'
  ]
)
on conflict (id) do update
set
  public = false,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

-- 3. RLS Policy: Only authenticated sender can upload into `<sender_id>/<receiver_id>/...`
--    AND sender & receiver must be accepted friends in `public.friendships`.
drop policy if exists "chat_media_insert_friends_only" on storage.objects;
create policy "chat_media_insert_friends_only"
  on storage.objects for insert
  to authenticated
  with check (
    bucket_id = 'chat-media'
    and auth.uid() is not null
    and (storage.foldername(name))[1] = auth.uid()::text
    and (storage.foldername(name))[2] is not null
    and (storage.foldername(name))[2] <> auth.uid()::text
    and (storage.foldername(name))[2] ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
    and public.are_friends(auth.uid(), ((storage.foldername(name))[2])::uuid)
  );

-- 4. RLS Policy: Only the sender or receiver can view / create signed URLs for the object,
--    AND they must currently be accepted friends in `public.friendships`.
drop policy if exists "chat_media_select_friends_only" on storage.objects;
create policy "chat_media_select_friends_only"
  on storage.objects for select
  to authenticated
  using (
    bucket_id = 'chat-media'
    and auth.uid() is not null
    and (
      (storage.foldername(name))[1] = auth.uid()::text
      or (storage.foldername(name))[2] = auth.uid()::text
    )
    and (storage.foldername(name))[1] ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
    and (storage.foldername(name))[2] ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
    and public.are_friends(
      ((storage.foldername(name))[1])::uuid,
      ((storage.foldername(name))[2])::uuid
    )
  );

-- 5. RLS Policy: Sender can delete their own uploaded media objects if needed
drop policy if exists "chat_media_delete_sender_only" on storage.objects;
create policy "chat_media_delete_sender_only"
  on storage.objects for delete
  to authenticated
  using (
    bucket_id = 'chat-media'
    and auth.uid() is not null
    and (storage.foldername(name))[1] = auth.uid()::text
  );
