-- ============================================================================
-- Safe Additive Migration: Add avatar_hue (text) to public.profiles
-- Preserves all existing columns, data, and RLS policies.
-- Reloads the Supabase PostgREST schema cache immediately.
-- ============================================================================

alter table public.profiles
  add column if not exists avatar_hue text not null default '268';

-- Refresh Supabase PostgREST schema cache so the new column is immediately visible
notify pgrst, 'reload schema';
