-- ============================================================================
-- MOON Messenger — Supabase Schema, Triggers, Realtime & Friend-Only RLS
-- Matches confirmed production columns:
--   public.profiles (id, username, friend_code, created_at, avatar_hue, display_name, is_guest, bio)
--   public.friend_requests (id, sender_id, receiver_id, status, created_at)
--   public.friendships (id, user1, user2, created_at) -- canonical least/greatest pair
--   public.messages (id, sender_id, receiver_id, content, created_at)
-- ============================================================================

-- 1. PROFILES TABLE
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null check (char_length(username) between 3 and 24),
  display_name text not null default '',
  friend_code text unique not null,
  is_guest boolean not null default false,
  bio text not null default '',
  avatar_hue text not null default '268',
  created_at timestamptz not null default now()
);

alter table public.profiles add column if not exists avatar_hue text not null default '268';
alter table public.profiles add column if not exists display_name text not null default '';
alter table public.profiles add column if not exists is_guest boolean not null default false;
alter table public.profiles add column if not exists bio text not null default '';

create index if not exists idx_profiles_friend_code on public.profiles (friend_code);

alter table public.profiles enable row level security;

drop policy if exists "profiles_select_authenticated" on public.profiles;
create policy "profiles_select_authenticated"
  on public.profiles for select
  to authenticated
  using (auth.uid() is not null);

drop policy if exists "profiles_insert_own" on public.profiles;
create policy "profiles_insert_own"
  on public.profiles for insert
  to authenticated
  with check (auth.uid() = id);

drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own"
  on public.profiles for update
  to authenticated
  using (auth.uid() = id)
  with check (auth.uid() = id);

-- 2. FRIEND REQUESTS TABLE (sender_id, receiver_id, status, created_at)
create table if not exists public.friend_requests (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  receiver_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending', 'accepted', 'rejected')),
  created_at timestamptz not null default now(),
  constraint friend_requests_no_self check (sender_id <> receiver_id),
  unique (sender_id, receiver_id)
);

alter table public.friend_requests enable row level security;

drop policy if exists "friend_requests_select_involved" on public.friend_requests;
create policy "friend_requests_select_involved"
  on public.friend_requests for select
  to authenticated
  using (auth.uid() = sender_id or auth.uid() = receiver_id);

drop policy if exists "friend_requests_insert_sender" on public.friend_requests;
create policy "friend_requests_insert_sender"
  on public.friend_requests for insert
  to authenticated
  with check (
    auth.uid() = sender_id
    and sender_id <> receiver_id
    and status = 'pending'
  );

drop policy if exists "friend_requests_update_involved" on public.friend_requests;
create policy "friend_requests_update_involved"
  on public.friend_requests for update
  to authenticated
  using (auth.uid() = receiver_id or auth.uid() = sender_id)
  with check (auth.uid() = receiver_id or auth.uid() = sender_id);

drop policy if exists "friend_requests_delete_involved" on public.friend_requests;
create policy "friend_requests_delete_involved"
  on public.friend_requests for delete
  to authenticated
  using (auth.uid() = sender_id or auth.uid() = receiver_id);

-- 3. FRIENDSHIPS TABLE (user1, user2 stored canonically with least/greatest)
create table if not exists public.friendships (
  id uuid primary key default gen_random_uuid(),
  user1 uuid not null references public.profiles(id) on delete cascade,
  user2 uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  constraint friendships_no_self check (user1 <> user2),
  unique (user1, user2)
);

alter table public.friendships enable row level security;

drop policy if exists "friendships_select_involved" on public.friendships;
create policy "friendships_select_involved"
  on public.friendships for select
  to authenticated
  using (auth.uid() = user1 or auth.uid() = user2);

drop policy if exists "friendships_insert_when_accepted" on public.friendships;
create policy "friendships_insert_when_accepted"
  on public.friendships for insert
  to authenticated
  with check (
    (auth.uid() = user1 or auth.uid() = user2)
    and exists (
      select 1 from public.friend_requests fr
      where fr.status = 'accepted'
        and (
          (fr.sender_id = user1 and fr.receiver_id = user2)
          or (fr.sender_id = user2 and fr.receiver_id = user1)
        )
    )
  );

-- Helper function checking whether two users are accepted friends in public.friendships (user1, user2)
create or replace function public.are_friends(user_a uuid, user_b uuid)
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select exists (
    select 1
    from public.friendships f
    where (f.user1 = least(user_a, user_b) and f.user2 = greatest(user_a, user_b))
       or (f.user1 = user_a and f.user2 = user_b)
       or (f.user1 = user_b and f.user2 = user_a)
  );
$$;

-- Idempotent trigger inserting canonical (least, greatest) pair into public.friendships (user1, user2)
create or replace function public.handle_accepted_friend_request()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  u1 uuid := least(new.sender_id, new.receiver_id);
  u2 uuid := greatest(new.sender_id, new.receiver_id);
begin
  if new.status = 'accepted' and (old.status is distinct from 'accepted') then
    insert into public.friendships (user1, user2)
    values (u1, u2)
    on conflict (user1, user2) do nothing;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_friend_request_accepted on public.friend_requests;
create trigger trg_friend_request_accepted
  after update on public.friend_requests
  for each row
  execute function public.handle_accepted_friend_request();

-- 4. MESSAGES TABLE (sender_id, receiver_id, content, created_at)
create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  receiver_id uuid not null references public.profiles(id) on delete cascade,
  content text not null check (char_length(trim(content)) between 1 and 4000),
  created_at timestamptz not null default now(),
  constraint messages_no_self check (sender_id <> receiver_id)
);

create index if not exists idx_messages_participants on public.messages (sender_id, receiver_id, created_at);

alter table public.messages enable row level security;

drop policy if exists "messages_select_friends_only" on public.messages;
create policy "messages_select_friends_only"
  on public.messages for select
  to authenticated
  using (
    (auth.uid() = sender_id or auth.uid() = receiver_id)
    and public.are_friends(sender_id, receiver_id)
  );

drop policy if exists "messages_insert_friends_only" on public.messages;
create policy "messages_insert_friends_only"
  on public.messages for insert
  to authenticated
  with check (
    auth.uid() = sender_id
    and sender_id <> receiver_id
    and public.are_friends(sender_id, receiver_id)
  );

-- 5. ENABLE SUPABASE REALTIME & RELOAD SCHEMA CACHE
do $$
begin
  begin alter publication supabase_realtime add table public.messages; exception when duplicate_object then null; end;
  begin alter publication supabase_realtime add table public.friend_requests; exception when duplicate_object then null; end;
  begin alter publication supabase_realtime add table public.friendships; exception when duplicate_object then null; end;
end $$;

notify pgrst, 'reload schema';
