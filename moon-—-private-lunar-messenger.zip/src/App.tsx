/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Film,
  Inbox,
  Loader2,
  MessageSquare,
  Newspaper,
  TrendingUp,
  User,
  UserPlus,
  Users,
} from 'lucide-react';
import { supabase } from './lib/supabaseClient';
import {
  AppScreen,
  ChatLocationAttachment,
  ChatMessage,
  FriendContact,
  FriendRequest,
  LiveKitTokenResponse,
  UserProfile,
  VoiceCallSignalPayload,
  VoiceCallStatus,
} from './types/moon';
import {
  fetchFriendRequestsFromSupabase,
  fetchFriendsFromSupabase,
  fetchMessagesForFriendSupabase,
  fetchOrBootstrapProfile,
  formatClockTime,
  respondToFriendRequestSupabase,
  sendLocationMessageToFriendSupabase,
  sendMediaMessageToFriendSupabase,
  sendMessageToFriendSupabase,
  signOutSupabase,
  subscribeToMoonRealtime,
} from './services/supabaseAdapter';
import {
  createLunarRingtoneController,
  getCanonicalCallRoomName,
  requestLiveKitCallToken,
  subscribeToVoiceCallSignaling,
} from './services/livekitCallService';
import { MoonLogo } from './components/ui/MoonLogo';
import { MoonButton } from './components/ui/ReusablePrimitives';
import { PWAInstallButton } from './components/ui/PWAInstallButton';
import { IncomingCallModal } from './components/ui/IncomingCallModal';
import { DevilNightSkyBackground } from './components/ui/DevilNightSkyBackground';
import { WelcomeAuthScreen } from './components/screens/WelcomeAuthScreen';
import { FriendsListScreen } from './components/screens/FriendsListScreen';
import { AddFriendScreen } from './components/screens/AddFriendScreen';
import { FriendRequestsScreen } from './components/screens/FriendRequestsScreen';
import { ProfileScreen } from './components/screens/ProfileScreen';
import { PrivateChatScreen } from './components/screens/PrivateChatScreen';
import { VoiceCallScreen } from './components/screens/VoiceCallScreen';
import { MoonReelsScreen } from './components/screens/MoonReelsScreen';
import { MoonNewsHomeScreen } from './components/screens/MoonNewsHomeScreen';
import { MoonTradingScreen } from './components/screens/MoonTradingScreen';

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [isRestoringSession, setIsRestoringSession] = useState<boolean>(true);
  const [sessionRestoreError, setSessionRestoreError] = useState<string | null>(
    null
  );

  const [activeScreen, setActiveScreen] = useState<AppScreen>('home');
  const [selectedReelEmbedCode, setSelectedReelEmbedCode] = useState<
    string | null
  >(null);
  const [rightPaneMode, setRightPaneMode] = useState<'chat' | 'voice-call'>(
    'chat'
  );

  const [friends, setFriends] = useState<FriendContact[]>([]);
  const friendsRef = useRef<FriendContact[]>([]);
  friendsRef.current = friends;

  const [isLoadingFriends, setIsLoadingFriends] = useState(false);
  const [friendsError, setFriendsError] = useState<string | null>(null);

  const [activeFriendId, setActiveFriendId] = useState<string>('');
  const activeFriendIdRef = useRef<string>('');
  activeFriendIdRef.current = activeFriendId;

  const [friendRequests, setFriendRequests] = useState<FriendRequest[]>([]);
  const [isLoadingRequests, setIsLoadingRequests] = useState(false);
  const [requestsError, setRequestsError] = useState<string | null>(null);

  const [messagesByFriend, setMessagesByFriend] = useState<
    Record<string, ChatMessage[]>
  >({});
  const [isLoadingMessages, setIsLoadingMessages] = useState(false);
  const [messageError, setMessageError] = useState<string | null>(null);

  // Voice Calling & LiveKit State
  const [callStatus, setCallStatus] = useState<VoiceCallStatus>('idle');
  const callStatusRef = useRef<VoiceCallStatus>('idle');
  callStatusRef.current = callStatus;

  const [activeCallId, setActiveCallId] = useState<string | null>(null);
  const activeCallIdRef = useRef<string | null>(null);
  activeCallIdRef.current = activeCallId;

  const [callPeerUserId, setCallPeerUserId] = useState<string | null>(null);
  const callPeerUserIdRef = useRef<string | null>(null);
  callPeerUserIdRef.current = callPeerUserId;

  const [incomingCallSignal, setIncomingCallSignal] =
    useState<VoiceCallSignalPayload | null>(null);
  const [liveKitTokenData, setLiveKitTokenData] =
    useState<LiveKitTokenResponse | null>(null);
  const [callError, setCallError] = useState<string | null>(null);

  const sendSignalRef = useRef<
    ((signal: VoiceCallSignalPayload) => Promise<void>) | null
  >(null);
  const ringtoneRef = useRef(createLunarRingtoneController());

  // Restore active Supabase session on initial page load
  useEffect(() => {
    let isMounted = true;
    async function restoreSession() {
      if (!supabase) {
        if (isMounted) setIsRestoringSession(false);
        return;
      }
      try {
        const {
          data: { session },
          error: sessionErr,
        } = await supabase.auth.getSession();

        if (sessionErr) {
          throw new Error(`Session check failed: ${sessionErr.message}`);
        }

        if (session?.user && isMounted) {
          const profile = await fetchOrBootstrapProfile(session.user);
          if (isMounted) {
            setCurrentUser(profile);
          }
        }
      } catch (err) {
        if (isMounted) {
          setSessionRestoreError(
            err instanceof Error
              ? err.message
              : 'Failed to restore previous Supabase session.'
          );
        }
      } finally {
        if (isMounted) setIsRestoringSession(false);
      }
    }
    restoreSession();
    return () => {
      isMounted = false;
    };
  }, []);

  const loadFriends = useCallback(async (userId: string) => {
    setIsLoadingFriends(true);
    setFriendsError(null);
    try {
      const list = await fetchFriendsFromSupabase(userId);
      setFriends(list);
      setActiveFriendId((prev) => {
        if (prev && list.some((f) => f.id === prev)) return prev;
        return list[0]?.id || '';
      });
    } catch (err) {
      setFriendsError(
        err instanceof Error ? err.message : 'Failed to load friends.'
      );
    } finally {
      setIsLoadingFriends(false);
    }
  }, []);

  const loadRequests = useCallback(async (userId: string) => {
    setIsLoadingRequests(true);
    setRequestsError(null);
    try {
      const reqs = await fetchFriendRequestsFromSupabase(userId);
      setFriendRequests(reqs);
    } catch (err) {
      setRequestsError(
        err instanceof Error ? err.message : 'Failed to load friend requests.'
      );
    } finally {
      setIsLoadingRequests(false);
    }
  }, []);

  const loadMessagesForFriend = useCallback(
    async (userId: string, friendId: string) => {
      if (!friendId) return;
      setIsLoadingMessages(true);
      setMessageError(null);
      try {
        const list = await fetchMessagesForFriendSupabase(userId, friendId);
        setMessagesByFriend((prev) => ({
          ...prev,
          [friendId]: list,
        }));
      } catch (err) {
        setMessageError(
          err instanceof Error ? err.message : 'Failed to load messages.'
        );
      } finally {
        setIsLoadingMessages(false);
      }
    },
    []
  );

  // Load initial data and subscribe to Supabase Realtime + Voice Signaling when currentUser changes
  useEffect(() => {
    if (!currentUser) return;

    loadFriends(currentUser.id);
    loadRequests(currentUser.id);

    const unsubscribeDbRealtime = subscribeToMoonRealtime(currentUser.id, {
      onIncomingOrSyncedMessage: (newMsg, rawSenderId) => {
        const friendId = newMsg.threadFriendId;
        setMessagesByFriend((prev) => {
          const existing = prev[friendId] || [];
          if (existing.some((m) => m.id === newMsg.id)) {
            return prev;
          }
          return {
            ...prev,
            [friendId]: [...existing, newMsg],
          };
        });

        if (
          rawSenderId !== currentUser.id &&
          activeFriendIdRef.current !== friendId
        ) {
          setFriends((prev) =>
            prev.map((f) =>
              f.id === friendId ? { ...f, unreadCount: f.unreadCount + 1 } : f
            )
          );
        }
      },
      onFriendRequestsChanged: () => {
        loadRequests(currentUser.id);
      },
      onFriendshipsChanged: () => {
        loadFriends(currentUser.id);
      },
    });

    const { sendSignal, unsubscribe: unsubscribeSignaling } =
      subscribeToVoiceCallSignaling(currentUser.id, (signal) => {
        if (signal.type === 'call:invite') {
          // If already in an active call with someone else, reply busy
          if (
            callStatusRef.current === 'calling' ||
            callStatusRef.current === 'connecting' ||
            callStatusRef.current === 'connected'
          ) {
            sendSignalRef.current
              ?.({
                type: 'call:busy',
                callId: signal.callId,
                roomName: signal.roomName,
                fromUserId: currentUser.id,
                fromUsername: currentUser.username,
                fromDisplayName: currentUser.displayName,
                fromFriendCode: currentUser.friendCode,
                fromAvatarHue: currentUser.avatarHue,
                toUserId: signal.fromUserId,
                sentAtIso: new Date().toISOString(),
                reason: 'User is currently in another call.',
              })
              .catch(() => {});
            return;
          }

          setIncomingCallSignal(signal);
          setActiveCallId(signal.callId);
          setCallPeerUserId(signal.fromUserId);
          setCallStatus('incoming');
          setCallError(null);
          ringtoneRef.current.start('incoming');
          return;
        }

        if (signal.type === 'call:accept') {
          ringtoneRef.current.stop();
          setCallStatus('connected');
          return;
        }

        if (signal.type === 'call:reject' || signal.type === 'call:busy') {
          ringtoneRef.current.stop();
          setLiveKitTokenData(null);
          setIncomingCallSignal(null);
          setCallStatus('rejected');
          setCallError(
            signal.type === 'call:busy'
              ? `@${signal.fromUsername} is currently busy on another call.`
              : `@${signal.fromUsername} declined the voice call.`
          );
          return;
        }

        if (signal.type === 'call:end') {
          ringtoneRef.current.stop();
          setLiveKitTokenData(null);
          setIncomingCallSignal(null);
          setActiveCallId(null);
          setCallPeerUserId(null);
          setCallStatus('ended');
        }
      });

    sendSignalRef.current = sendSignal;

    return () => {
      ringtoneRef.current.stop();
      unsubscribeDbRealtime();
      unsubscribeSignaling();
      sendSignalRef.current = null;
    };
  }, [currentUser, loadFriends, loadRequests]);

  // Load conversation messages whenever activeFriendId changes
  useEffect(() => {
    if (currentUser && activeFriendId) {
      loadMessagesForFriend(currentUser.id, activeFriendId);
    }
  }, [currentUser, activeFriendId, loadMessagesForFriend]);

  const activeFriend =
    friends.find((f) => f.id === activeFriendId) || friends[0] || null;

  const pendingIncomingCount = friendRequests.filter(
    (r) => r.direction === 'incoming' && r.status === 'pending'
  ).length;

  const handleAuthenticated = (profile: UserProfile) => {
    setCurrentUser(profile);
    setActiveScreen('home');
    setRightPaneMode('chat');
  };

  const handleSignOut = async () => {
    ringtoneRef.current.stop();
    await signOutSupabase();
    setCurrentUser(null);
    setFriends([]);
    setFriendRequests([]);
    setMessagesByFriend({});
    setActiveFriendId('');
    setLiveKitTokenData(null);
    setIncomingCallSignal(null);
    setCallStatus('idle');
  };

  const handleSelectChat = (friendId: string) => {
    setActiveFriendId(friendId);
    setRightPaneMode('chat');
    setActiveScreen('chats');
    setFriends((prev) =>
      prev.map((f) => (f.id === friendId ? { ...f, unreadCount: 0 } : f))
    );
  };

  const handleStartVoiceCallUI = (friendId: string) => {
    setActiveFriendId(friendId);
    setRightPaneMode('voice-call');
    setActiveScreen('voice-call');
  };

  const handleStartOutgoingCall = async (targetFriend: FriendContact) => {
    if (!currentUser) return;
    setCallError(null);
    setCallStatus('connecting');
    setActiveFriendId(targetFriend.id);
    setRightPaneMode('voice-call');
    setActiveScreen('voice-call');

    try {
      // 1. Verify friendship and obtain short-lived LiveKit token from server
      const tokenData = await requestLiveKitCallToken(targetFriend.id);

      const newCallId = `call-${Date.now()}-${currentUser.id.slice(0, 6)}`;
      setActiveCallId(newCallId);
      setCallPeerUserId(targetFriend.id);
      setLiveKitTokenData(tokenData);
      setCallStatus('calling');
      ringtoneRef.current.start('outgoing');

      // 2. Broadcast incoming call invite to targetFriend over Supabase Realtime
      if (sendSignalRef.current) {
        await sendSignalRef.current({
          type: 'call:invite',
          callId: newCallId,
          roomName:
            tokenData.roomName ||
            getCanonicalCallRoomName(currentUser.id, targetFriend.id),
          fromUserId: currentUser.id,
          fromUsername: currentUser.username,
          fromDisplayName: currentUser.displayName,
          fromFriendCode: currentUser.friendCode,
          fromAvatarHue: currentUser.avatarHue,
          toUserId: targetFriend.id,
          sentAtIso: new Date().toISOString(),
        });
      }
    } catch (err) {
      ringtoneRef.current.stop();
      setLiveKitTokenData(null);
      setCallStatus('error');
      setCallError(
        err instanceof Error
          ? err.message
          : 'Could not start LiveKit voice call.'
      );
    }
  };

  const handleAcceptIncomingCall = async (signal: VoiceCallSignalPayload) => {
    if (!currentUser) return;
    ringtoneRef.current.stop();
    setCallError(null);
    setIncomingCallSignal(null);
    setActiveFriendId(signal.fromUserId);
    setRightPaneMode('voice-call');
    setActiveScreen('voice-call');
    setCallStatus('connecting');

    try {
      // Ensure caller is in our local friends list (refresh if just accepted)
      if (!friendsRef.current.some((f) => f.id === signal.fromUserId)) {
        await loadFriends(currentUser.id);
      }

      // 1. Verify friendship on server and fetch short-lived LiveKit token
      const tokenData = await requestLiveKitCallToken(signal.fromUserId);

      setLiveKitTokenData(tokenData);
      setActiveCallId(signal.callId);
      setCallPeerUserId(signal.fromUserId);
      setCallStatus('connected');

      // 2. Notify caller that call was accepted
      if (sendSignalRef.current) {
        await sendSignalRef.current({
          type: 'call:accept',
          callId: signal.callId,
          roomName: tokenData.roomName,
          fromUserId: currentUser.id,
          fromUsername: currentUser.username,
          fromDisplayName: currentUser.displayName,
          fromFriendCode: currentUser.friendCode,
          fromAvatarHue: currentUser.avatarHue,
          toUserId: signal.fromUserId,
          sentAtIso: new Date().toISOString(),
        });
      }
    } catch (err) {
      setLiveKitTokenData(null);
      setCallStatus('error');
      setCallError(
        err instanceof Error
          ? err.message
          : 'Failed to join incoming LiveKit voice call.'
      );
    }
  };

  const handleRejectIncomingCall = async (signal: VoiceCallSignalPayload) => {
    if (!currentUser) return;
    ringtoneRef.current.stop();
    setIncomingCallSignal(null);
    setCallStatus('idle');

    try {
      if (sendSignalRef.current) {
        await sendSignalRef.current({
          type: 'call:reject',
          callId: signal.callId,
          roomName: signal.roomName,
          fromUserId: currentUser.id,
          fromUsername: currentUser.username,
          fromDisplayName: currentUser.displayName,
          fromFriendCode: currentUser.friendCode,
          fromAvatarHue: currentUser.avatarHue,
          toUserId: signal.fromUserId,
          sentAtIso: new Date().toISOString(),
          reason: 'Call declined by user.',
        });
      }
    } catch (err) {
      setCallError(
        err instanceof Error
          ? err.message
          : 'Failed to send call rejection signal.'
      );
    }
  };

  const handleEndCall = async (reason?: string) => {
    ringtoneRef.current.stop();
    const peerId = callPeerUserIdRef.current || activeFriend?.id;
    const callIdToClose = activeCallIdRef.current || `call-${Date.now()}`;

    setLiveKitTokenData(null);
    setIncomingCallSignal(null);
    setActiveCallId(null);
    setCallPeerUserId(null);
    setCallStatus('ended');

    if (currentUser && peerId && sendSignalRef.current) {
      try {
        await sendSignalRef.current({
          type: 'call:end',
          callId: callIdToClose,
          roomName: getCanonicalCallRoomName(currentUser.id, peerId),
          fromUserId: currentUser.id,
          fromUsername: currentUser.username,
          fromDisplayName: currentUser.displayName,
          fromFriendCode: currentUser.friendCode,
          fromAvatarHue: currentUser.avatarHue,
          toUserId: peerId,
          sentAtIso: new Date().toISOString(),
          reason,
        });
      } catch {
        // Ignore network disconnect error on hangup
      }
    }
  };

  const handleRequestCreated = (newReq: FriendRequest) => {
    setFriendRequests((prev) => [
      newReq,
      ...prev.filter((r) => r.id !== newReq.id),
    ]);
  };

  const handleRespondToRequest = async (
    request: FriendRequest,
    action: 'accept' | 'reject'
  ) => {
    if (!currentUser) return;
    await respondToFriendRequestSupabase({
      currentUserId: currentUser.id,
      request,
      action,
    });

    await Promise.all([
      loadRequests(currentUser.id),
      loadFriends(currentUser.id),
    ]);

    if (action === 'accept') {
      setActiveFriendId(request.fromUser.id);
      setRightPaneMode('chat');
    }
  };

  const handleSendMessage = async (friendId: string, text: string) => {
    if (!currentUser) return;
    setMessageError(null);

    const tempId = `optimistic-${Date.now()}`;
    const optimisticMsg: ChatMessage = {
      id: tempId,
      threadFriendId: friendId,
      senderId: 'me',
      text,
      timestampText: formatClockTime(),
      deliveryState: 'sending',
    };

    setMessagesByFriend((prev) => ({
      ...prev,
      [friendId]: [...(prev[friendId] || []), optimisticMsg],
    }));

    try {
      const savedMsg = await sendMessageToFriendSupabase({
        currentUserId: currentUser.id,
        friendId,
        text,
      });

      setMessagesByFriend((prev) => {
        const list = prev[friendId] || [];
        const alreadyFromRealtime = list.some((m) => m.id === savedMsg.id);
        if (alreadyFromRealtime) {
          return {
            ...prev,
            [friendId]: list.filter((m) => m.id !== tempId),
          };
        }
        return {
          ...prev,
          [friendId]: list.map((m) => (m.id === tempId ? savedMsg : m)),
        };
      });
    } catch (err) {
      setMessageError(
        err instanceof Error ? err.message : 'Failed to send message.'
      );
      setMessagesByFriend((prev) => ({
        ...prev,
        [friendId]: (prev[friendId] || []).map((m) =>
          m.id === tempId ? { ...m, deliveryState: 'failed' } : m
        ),
      }));
    }
  };

  const handleRetryMessage = async (
    friendId: string,
    failedMessageId: string,
    text: string
  ) => {
    setMessagesByFriend((prev) => ({
      ...prev,
      [friendId]: (prev[friendId] || []).filter(
        (m) => m.id !== failedMessageId
      ),
    }));
    await handleSendMessage(friendId, text);
  };

  const handleSendMediaMessage = async (params: {
    friendId: string;
    file: File;
    caption?: string;
    onProgress?: (percent: number, stageLabel: string) => void;
  }) => {
    if (!currentUser) return;
    setMessageError(null);

    const savedMsg = await sendMediaMessageToFriendSupabase({
      currentUserId: currentUser.id,
      friendId: params.friendId,
      file: params.file,
      caption: params.caption,
      onProgress: params.onProgress,
    });

    setMessagesByFriend((prev) => {
      const list = prev[params.friendId] || [];
      if (list.some((m) => m.id === savedMsg.id)) {
        return prev;
      }
      return {
        ...prev,
        [params.friendId]: [...list, savedMsg],
      };
    });
  };

  const handleSendLocationMessage = async (params: {
    friendId: string;
    location: Omit<ChatLocationAttachment, 'version'>;
  }) => {
    if (!currentUser) return;
    setMessageError(null);

    const savedMsg = await sendLocationMessageToFriendSupabase({
      currentUserId: currentUser.id,
      friendId: params.friendId,
      location: params.location,
    });

    setMessagesByFriend((prev) => {
      const list = prev[params.friendId] || [];
      if (list.some((m) => m.id === savedMsg.id)) {
        return prev;
      }
      return {
        ...prev,
        [params.friendId]: [...list, savedMsg],
      };
    });
  };

  if (isRestoringSession) {
    return (
      <div className="min-h-screen w-full bg-black text-[#F8FAFC] flex flex-col items-center justify-center gap-3 relative overflow-hidden">
        <DevilNightSkyBackground />
        <div className="relative z-10 flex flex-col items-center gap-3">
          <MoonLogo size="lg" showCreatorSubtitle />
          <div className="flex items-center gap-2 text-xs text-rose-200/90 mt-1">
            <Loader2 className="w-4 h-4 animate-spin text-rose-400" />
            <span>Restoring Supabase session...</span>
          </div>
        </div>
      </div>
    );
  }

  if (!currentUser) {
    return (
      <WelcomeAuthScreen
        onAuthenticated={handleAuthenticated}
        initialError={sessionRestoreError}
      />
    );
  }

  const leftPanelScreen =
    activeScreen === 'chats' ||
    activeScreen === 'voice-call' ||
    activeScreen === 'reels'
      ? 'friends'
      : activeScreen;

  return (
    <div className="min-h-screen w-full bg-black text-[#F8FAFC] flex flex-col relative overflow-x-hidden">
      {/* Realistic Animated Devil Night Moon Atmospheric Sky */}
      <DevilNightSkyBackground />

      {/* Global Incoming Call Overlay for Real-Time Calls from Any Screen */}
      <IncomingCallModal
        incomingSignal={
          callStatus === 'incoming' ? incomingCallSignal : null
        }
        onAccept={handleAcceptIncomingCall}
        onReject={handleRejectIncomingCall}
      />

      {/* Top Bar */}
      <header className="sticky top-0 z-30 h-14 bg-[#050208]/90 backdrop-blur-md border-b border-[#2D142C]/80 shadow-[0_4px_24px_rgba(0,0,0,0.85)]">
        <div className="w-full max-w-7xl mx-auto h-full px-4 sm:px-6 flex items-center justify-between gap-4">
          <button
            type="button"
            onClick={() => setActiveScreen('home')}
            className="text-left whitespace-nowrap shrink-0 cursor-pointer"
          >
            <MoonLogo size="sm" showWordmark headerCreatorBadge />
          </button>

          <nav className="hidden md:flex items-center gap-5 text-xs font-medium text-[#A39BB5]">
            <button
              type="button"
              onClick={() => setActiveScreen('home')}
              className={`hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer inline-flex items-center gap-1.5 ${
                activeScreen !== 'reels' && leftPanelScreen === 'home'
                  ? 'text-rose-300 drop-shadow-[0_0_8px_rgba(225,29,72,0.5)]'
                  : ''
              }`}
            >
              <Newspaper className="w-3.5 h-3.5 text-rose-400" />
              <span>Home</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveScreen('trading')}
              className={`hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer inline-flex items-center gap-1.5 ${
                activeScreen !== 'reels' && leftPanelScreen === 'trading'
                  ? 'text-pink-300 drop-shadow-[0_0_8px_rgba(236,72,153,0.55)]'
                  : ''
              }`}
            >
              <TrendingUp className="w-3.5 h-3.5 text-pink-400" />
              <span>Trading</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveScreen('friends')}
              className={`hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeScreen !== 'reels' && leftPanelScreen === 'friends'
                  ? 'text-rose-300 drop-shadow-[0_0_8px_rgba(225,29,72,0.5)]'
                  : ''
              }`}
            >
              Friends ({friends.length})
            </button>
            <button
              type="button"
              onClick={() => setActiveScreen('reels')}
              className={`hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer inline-flex items-center gap-1.5 ${
                activeScreen === 'reels'
                  ? 'text-rose-300 drop-shadow-[0_0_8px_rgba(225,29,72,0.5)]'
                  : ''
              }`}
            >
              <Film className="w-3.5 h-3.5 text-rose-400" />
              <span>Reels</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveScreen('requests')}
              className={`hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeScreen !== 'reels' && leftPanelScreen === 'requests'
                  ? 'text-rose-300 drop-shadow-[0_0_8px_rgba(225,29,72,0.5)]'
                  : ''
              }`}
            >
              Requests ({pendingIncomingCount})
            </button>
            <button
              type="button"
              onClick={() => setActiveScreen('add-friend')}
              className={`hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeScreen !== 'reels' && leftPanelScreen === 'add-friend'
                  ? 'text-rose-300 drop-shadow-[0_0_8px_rgba(225,29,72,0.5)]'
                  : ''
              }`}
            >
              Add Friend
            </button>
            <button
              type="button"
              onClick={() => setActiveScreen('profile')}
              className={`hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeScreen !== 'reels' && leftPanelScreen === 'profile'
                  ? 'text-rose-300 drop-shadow-[0_0_8px_rgba(225,29,72,0.5)]'
                  : ''
              }`}
            >
              Profile ({currentUser.friendCode})
            </button>
            <button
              type="button"
              onClick={() => {
                setRightPaneMode((prev) =>
                  prev === 'voice-call' ? 'chat' : 'voice-call'
                );
                setActiveScreen(
                  rightPaneMode === 'voice-call' ? 'chats' : 'voice-call'
                );
              }}
              className={`hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeScreen !== 'reels' && rightPaneMode === 'voice-call'
                  ? 'text-rose-300 drop-shadow-[0_0_8px_rgba(225,29,72,0.5)]'
                  : ''
              }`}
            >
              Voice Call
            </button>
          </nav>

          <div className="flex items-center gap-2 shrink-0">
            <PWAInstallButton />
            <MoonButton
              type="button"
              variant="secondary"
              onClick={handleSignOut}
            >
              Sign Out
            </MoonButton>
          </div>
        </div>
      </header>

      {/* Main Responsive Workspace */}
      <main
        className={`relative z-10 flex-1 w-full max-w-7xl mx-auto ${
          activeScreen === 'reels'
            ? 'p-0 lg:px-6 lg:py-3 pb-14 lg:pb-3'
            : 'px-4 sm:px-6 py-4 sm:py-6 pb-20 lg:pb-6'
        }`}
      >
        {activeScreen === 'reels' ? (
          <div className="devil-screen-transition w-full h-full">
            <MoonReelsScreen
              friends={friends}
              onShareReelToFriend={async (friendId, text) => {
                await handleSendMessage(friendId, text);
              }}
              onOpenChatWithFriend={handleSelectChat}
              onBackToFriends={() => setActiveScreen('friends')}
              initialReelEmbedCode={selectedReelEmbedCode}
              onClearInitialReel={() => setSelectedReelEmbedCode(null)}
            />
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* LEFT COLUMN (Screens 4, 5, 6, 7) */}
            <div
              className={`lg:col-span-5 space-y-5 ${
                activeScreen === 'chats' || activeScreen === 'voice-call'
                  ? 'hidden lg:block'
                  : 'block'
              }`}
            >
              <div className="hidden lg:grid grid-cols-7 gap-1 p-1 rounded-2xl bg-[#07030C]/90 backdrop-blur-md border border-[#2D142C] shadow-[0_12px_32px_rgba(0,0,0,0.85)]">
                <button
                  type="button"
                  onClick={() => setActiveScreen('home')}
                  className={`min-h-[40px] px-2 py-1.5 rounded-xl text-xs font-medium transition-all whitespace-nowrap shrink-0 cursor-pointer inline-flex items-center justify-center gap-1 ${
                    leftPanelScreen === 'home'
                      ? 'bg-gradient-to-r from-[#6D28D9] to-[#9F1239] text-white shadow-[0_0_16px_rgba(225,29,72,0.35)]'
                      : 'text-[#A39BB5] hover:text-white'
                  }`}
                >
                  <Newspaper className="w-3.5 h-3.5 text-rose-300" />
                  <span>Home</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveScreen('trading')}
                  className={`min-h-[40px] px-2 py-1.5 rounded-xl text-xs font-medium transition-all whitespace-nowrap shrink-0 cursor-pointer inline-flex items-center justify-center gap-1 ${
                    leftPanelScreen === 'trading'
                      ? 'bg-gradient-to-r from-[#7E22CE] to-[#EC4899] text-white shadow-[0_0_16px_rgba(236,72,153,0.4)]'
                      : 'text-[#A39BB5] hover:text-white'
                  }`}
                >
                  <TrendingUp className="w-3.5 h-3.5 text-pink-300" />
                  <span>Trading</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveScreen('friends')}
                  className={`min-h-[40px] px-2 py-1.5 rounded-xl text-xs font-medium transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                    leftPanelScreen === 'friends'
                      ? 'bg-gradient-to-r from-[#6D28D9] to-[#9F1239] text-white shadow-[0_0_16px_rgba(225,29,72,0.35)]'
                      : 'text-[#A39BB5] hover:text-white'
                  }`}
                >
                  Friends
                </button>
                <button
                  type="button"
                  onClick={() => setActiveScreen('reels')}
                  className="min-h-[40px] px-2 py-1.5 rounded-xl text-xs font-medium transition-all whitespace-nowrap shrink-0 cursor-pointer text-[#A39BB5] hover:text-white inline-flex items-center justify-center gap-1"
                >
                  <Film className="w-3.5 h-3.5 text-rose-400" />
                  <span>Reels</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveScreen('requests')}
                  className={`min-h-[40px] px-2 py-1.5 rounded-xl text-xs font-medium transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                    leftPanelScreen === 'requests'
                      ? 'bg-gradient-to-r from-[#6D28D9] to-[#9F1239] text-white shadow-[0_0_16px_rgba(225,29,72,0.35)]'
                      : 'text-[#A39BB5] hover:text-white'
                  }`}
                >
                  Requests ({pendingIncomingCount})
                </button>
                <button
                  type="button"
                  onClick={() => setActiveScreen('add-friend')}
                  className={`min-h-[40px] px-2 py-1.5 rounded-xl text-xs font-medium transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                    leftPanelScreen === 'add-friend'
                      ? 'bg-gradient-to-r from-[#6D28D9] to-[#9F1239] text-white shadow-[0_0_16px_rgba(225,29,72,0.35)]'
                      : 'text-[#A39BB5] hover:text-white'
                  }`}
                >
                  Add Code
                </button>
                <button
                  type="button"
                  onClick={() => setActiveScreen('profile')}
                  className={`min-h-[40px] px-2 py-1.5 rounded-xl text-xs font-medium transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                    leftPanelScreen === 'profile'
                      ? 'bg-gradient-to-r from-[#6D28D9] to-[#9F1239] text-white shadow-[0_0_16px_rgba(225,29,72,0.35)]'
                      : 'text-[#A39BB5] hover:text-white'
                  }`}
                >
                  Profile
                </button>
              </div>

              <div key={leftPanelScreen} className="devil-screen-transition">
                {leftPanelScreen === 'home' && (
                  <MoonNewsHomeScreen
                    currentUser={currentUser}
                    friends={friends}
                    onShareNewsToFriend={async (friendId, text) => {
                      await handleSendMessage(friendId, text);
                    }}
                    onOpenChatWithFriend={handleSelectChat}
                  />
                )}

                {leftPanelScreen === 'trading' && (
                  <MoonTradingScreen
                    currentUser={currentUser}
                    friends={friends}
                    onShareTradingToFriend={async (friendId, text) => {
                      await handleSendMessage(friendId, text);
                    }}
                    onOpenChatWithFriend={handleSelectChat}
                  />
                )}

                {leftPanelScreen === 'friends' && (
                  <FriendsListScreen
                    friends={friends}
                    activeFriendId={activeFriend?.id || ''}
                    isLoading={isLoadingFriends}
                    errorMessage={friendsError}
                    onRefreshFriends={() => loadFriends(currentUser.id)}
                    onSelectChat={handleSelectChat}
                    onStartVoiceCallUI={handleStartVoiceCallUI}
                    onNavigateAddFriend={() => setActiveScreen('add-friend')}
                  />
                )}

                {leftPanelScreen === 'add-friend' && (
                  <AddFriendScreen
                    currentUser={currentUser}
                    onRequestCreated={handleRequestCreated}
                    onNavigateRequests={() => setActiveScreen('requests')}
                    onNavigateFriends={() => setActiveScreen('friends')}
                  />
                )}

                {leftPanelScreen === 'requests' && (
                  <FriendRequestsScreen
                    requests={friendRequests}
                    isLoading={isLoadingRequests}
                    errorMessage={requestsError}
                    onRefreshRequests={() => loadRequests(currentUser.id)}
                    onRespondToRequest={handleRespondToRequest}
                    onNavigateAddFriend={() => setActiveScreen('add-friend')}
                  />
                )}

                {leftPanelScreen === 'profile' && (
                  <ProfileScreen
                    user={currentUser}
                    friends={friends}
                    friendRequests={friendRequests}
                    onUpdateUser={setCurrentUser}
                    onSignOut={handleSignOut}
                    onNavigateScreen={setActiveScreen}
                    onSelectFriendChat={handleSelectChat}
                    onOpenReelInPlayer={(embedCode) => {
                      setSelectedReelEmbedCode(embedCode);
                      setActiveScreen('reels');
                    }}
                  />
                )}
              </div>
            </div>

            {/* RIGHT COLUMN (Screens 8 & 9: Private 1-to-1 Chat & LiveKit Voice Call Screen) */}
            <div
              className={`lg:col-span-7 devil-screen-transition ${
                activeScreen === 'chats' || activeScreen === 'voice-call'
                  ? 'block'
                  : 'hidden lg:block'
              }`}
            >
              {rightPaneMode === 'voice-call' || activeScreen === 'voice-call' ? (
                <VoiceCallScreen
                  currentUser={currentUser}
                  friend={activeFriend}
                  callStatus={callStatus}
                  activeCallId={activeCallId}
                  incomingSignal={incomingCallSignal}
                  liveKitTokenData={liveKitTokenData}
                  callError={callError}
                  onStartOutgoingCall={handleStartOutgoingCall}
                  onAcceptIncomingCall={handleAcceptIncomingCall}
                  onRejectIncomingCall={handleRejectIncomingCall}
                  onEndCall={handleEndCall}
                  onClearCallError={() => setCallError(null)}
                  onReturnToChat={() => {
                    setRightPaneMode('chat');
                    setActiveScreen('chats');
                  }}
                />
              ) : (
                <PrivateChatScreen
                  currentUser={currentUser}
                  friend={activeFriend}
                  messages={
                    activeFriend ? messagesByFriend[activeFriend.id] || [] : []
                  }
                  isLoadingMessages={isLoadingMessages}
                  messageError={messageError}
                  onSendMessage={handleSendMessage}
                  onSendMediaMessage={handleSendMediaMessage}
                  onSendLocationMessage={handleSendLocationMessage}
                  onRetryMessage={handleRetryMessage}
                  onOpenVoiceCallUI={handleStartVoiceCallUI}
                  onNavigateAddFriend={() => setActiveScreen('add-friend')}
                  onBackMobile={() => setActiveScreen('friends')}
                />
              )}
            </div>
          </div>
        )}
      </main>

      {/* Fixed Bottom Tab Bar for Mobile / Android Thumb-Zone Ergonomics (< 1024px) */}
      <nav
        aria-label="Mobile Primary Navigation"
        className="lg:hidden fixed bottom-0 left-0 right-0 z-40 h-14 bg-[#050208]/95 backdrop-blur-md border-t border-[#2D142C] grid grid-cols-8 items-center px-1 shadow-[0_-8px_24px_rgba(0,0,0,0.9)]"
      >
        <button
          type="button"
          onClick={() => setActiveScreen('home')}
          className={`min-h-[48px] flex flex-col items-center justify-center cursor-pointer transition-colors ${
            activeScreen === 'home'
              ? 'text-rose-300 drop-shadow-[0_0_8px_rgba(225,29,72,0.5)]'
              : 'text-[#8E8AA6]'
          }`}
        >
          <Newspaper className="w-5 h-5" />
          <span className="text-[10px] font-medium tracking-tight mt-0.5 whitespace-nowrap">
            Home
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveScreen('trading')}
          className={`min-h-[48px] flex flex-col items-center justify-center cursor-pointer transition-colors ${
            activeScreen === 'trading'
              ? 'text-pink-300 drop-shadow-[0_0_8px_rgba(236,72,153,0.55)]'
              : 'text-[#8E8AA6]'
          }`}
        >
          <TrendingUp className="w-5 h-5" />
          <span className="text-[10px] font-medium tracking-tight mt-0.5 whitespace-nowrap">
            Trading
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveScreen('friends')}
          className={`min-h-[48px] flex flex-col items-center justify-center cursor-pointer transition-colors ${
            activeScreen === 'friends'
              ? 'text-rose-300 drop-shadow-[0_0_8px_rgba(225,29,72,0.5)]'
              : 'text-[#8E8AA6]'
          }`}
        >
          <Users className="w-5 h-5" />
          <span className="text-[10px] font-medium tracking-tight mt-0.5 whitespace-nowrap">
            Friends
          </span>
        </button>

        <button
          type="button"
          onClick={() => {
            setRightPaneMode('chat');
            setActiveScreen('chats');
          }}
          className={`min-h-[48px] flex flex-col items-center justify-center cursor-pointer transition-colors ${
            activeScreen === 'chats'
              ? 'text-rose-300 drop-shadow-[0_0_8px_rgba(225,29,72,0.5)]'
              : 'text-[#8E8AA6]'
          }`}
        >
          <MessageSquare className="w-5 h-5" />
          <span className="text-[10px] font-medium tracking-tight mt-0.5 whitespace-nowrap">
            Chat
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveScreen('reels')}
          className={`min-h-[48px] flex flex-col items-center justify-center cursor-pointer transition-colors ${
            activeScreen === 'reels'
              ? 'text-rose-300 drop-shadow-[0_0_8px_rgba(225,29,72,0.5)]'
              : 'text-[#8E8AA6]'
          }`}
        >
          <Film className="w-5 h-5" />
          <span className="text-[10px] font-medium tracking-tight mt-0.5 whitespace-nowrap">
            Reels
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveScreen('add-friend')}
          className={`min-h-[48px] flex flex-col items-center justify-center cursor-pointer transition-colors ${
            activeScreen === 'add-friend'
              ? 'text-rose-300 drop-shadow-[0_0_8px_rgba(225,29,72,0.5)]'
              : 'text-[#8E8AA6]'
          }`}
        >
          <UserPlus className="w-5 h-5" />
          <span className="text-[10px] font-medium tracking-tight mt-0.5 whitespace-nowrap">
            Add Code
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveScreen('requests')}
          className={`min-h-[48px] flex flex-col items-center justify-center cursor-pointer transition-colors ${
            activeScreen === 'requests'
              ? 'text-rose-300 drop-shadow-[0_0_8px_rgba(225,29,72,0.5)]'
              : 'text-[#8E8AA6]'
          }`}
        >
          <Inbox className="w-5 h-5" />
          <span className="text-[10px] font-medium tracking-tight mt-0.5 whitespace-nowrap">
            Requests{pendingIncomingCount > 0 ? ` (${pendingIncomingCount})` : ''}
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveScreen('profile')}
          className={`min-h-[48px] flex flex-col items-center justify-center cursor-pointer transition-colors ${
            activeScreen === 'profile'
              ? 'text-rose-300 drop-shadow-[0_0_8px_rgba(225,29,72,0.5)]'
              : 'text-[#8E8AA6]'
          }`}
        >
          <User className="w-5 h-5" />
          <span className="text-[10px] font-medium tracking-tight mt-0.5 whitespace-nowrap">
            Profile
          </span>
        </button>
      </nav>
    </div>
  );
}
