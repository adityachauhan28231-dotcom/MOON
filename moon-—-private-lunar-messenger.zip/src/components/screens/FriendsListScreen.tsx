import React, { useState } from 'react';
import {
  MessageSquare,
  Phone,
  RefreshCw,
  Search,
  UserPlus,
} from 'lucide-react';
import { FriendContact } from '../../types/moon';
import {
  ErrorBanner,
  LoadingListSkeleton,
  LunarAvatar,
  MoonButton,
  MoonInput,
} from '../ui/ReusablePrimitives';

interface FriendsListScreenProps {
  friends: FriendContact[];
  activeFriendId: string;
  isLoading: boolean;
  errorMessage: string | null;
  onRefreshFriends: () => Promise<void>;
  onSelectChat: (friendId: string) => void;
  onStartVoiceCallUI: (friendId: string) => void;
  onNavigateAddFriend: () => void;
}

type FriendFilter = 'all' | 'unread';

export const FriendsListScreen: React.FC<FriendsListScreenProps> = ({
  friends,
  activeFriendId,
  isLoading,
  errorMessage,
  onRefreshFriends,
  onSelectChat,
  onStartVoiceCallUI,
  onNavigateAddFriend,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filter, setFilter] = useState<FriendFilter>('all');

  const filteredFriends = friends.filter((friend) => {
    const matchesSearch =
      friend.displayName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      friend.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
      friend.friendCode.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;
    if (filter === 'unread') return friend.unreadCount > 0;
    return true;
  });

  return (
    <div className="space-y-5 pb-6">
      {/* Header & Actions */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-xl font-bold text-white drop-shadow-[0_2px_10px_rgba(0,0,0,0.85)]">
            Friends Directory
          </h2>
          <p className="text-xs text-[#CBD5E1] mt-0.5">
            <span>{friends.length} accepted friends</span>
            <span className="mx-1.5 text-rose-400" aria-hidden="true">
              ·
            </span>
            <span>Friend-only RLS messaging enabled</span>
          </p>
        </div>

        <div className="flex items-center gap-2">
          <MoonButton
            type="button"
            variant="secondary"
            isLoading={isLoading}
            onClick={onRefreshFriends}
            leftIcon={<RefreshCw className="w-4 h-4 text-rose-300" />}
          >
            Sync
          </MoonButton>
          <MoonButton
            type="button"
            variant="primary"
            onClick={onNavigateAddFriend}
            leftIcon={<UserPlus className="w-4 h-4" />}
          >
            Add by Code
          </MoonButton>
        </div>
      </div>

      {/* Search & Interactive Segmented Filter Bar */}
      <div className="space-y-3">
        <MoonInput
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search name, @username, or MOON-XXXX-XX..."
          rightSlot={<Search className="w-4 h-4 text-[#A39BB5] mr-2.5" />}
        />

        <div className="flex items-center gap-1 p-1 rounded-xl bg-[#07030C]/90 backdrop-blur-md border border-[#2D142C] w-fit">
          <button
            type="button"
            onClick={() => setFilter('all')}
            className={`min-h-[38px] px-3 py-1.5 text-xs font-medium rounded-lg transition-all whitespace-nowrap shrink-0 cursor-pointer ${
              filter === 'all'
                ? 'bg-gradient-to-r from-[#6D28D9] to-[#9F1239] text-white shadow-[0_0_14px_rgba(225,29,72,0.3)]'
                : 'text-[#A39BB5] hover:text-white'
            }`}
          >
            All Friends ({friends.length})
          </button>
          <button
            type="button"
            onClick={() => setFilter('unread')}
            className={`min-h-[38px] px-3 py-1.5 text-xs font-medium rounded-lg transition-all whitespace-nowrap shrink-0 cursor-pointer ${
              filter === 'unread'
                ? 'bg-gradient-to-r from-[#6D28D9] to-[#9F1239] text-white shadow-[0_0_14px_rgba(225,29,72,0.3)]'
                : 'text-[#A39BB5] hover:text-white'
            }`}
          >
            Unread ({friends.filter((f) => f.unreadCount > 0).length})
          </button>
        </div>
      </div>

      {errorMessage && (
        <ErrorBanner
          title="Could Not Load Friends List"
          message={errorMessage}
          onRetry={onRefreshFriends}
        />
      )}

      {isLoading ? (
        <LoadingListSkeleton
          rows={3}
          label="Querying public.friendships & public.profiles..."
        />
      ) : filteredFriends.length === 0 ? (
        <div className="rounded-3xl bg-black/55 border border-rose-500/30 p-8 text-center space-y-3 shadow-[0_18px_45px_rgba(0,0,0,0.85)]">
          <p className="font-display text-base font-semibold text-white drop-shadow-[0_2px_8px_rgba(0,0,0,0.95)]">
            {friends.length === 0
              ? 'No friends connected yet'
              : 'No matching friends found'}
          </p>
          <p className="text-xs text-[#E2E8F0] max-w-xs mx-auto leading-relaxed">
            {friends.length === 0
              ? 'Share your MOON-XXXX-XX friend code or enter a friend’s code to establish a friendship and unlock private messaging.'
              : 'Try clearing your search query or filter.'}
          </p>
          <div className="pt-2">
            <MoonButton
              type="button"
              variant="secondary"
              onClick={onNavigateAddFriend}
              leftIcon={<UserPlus className="w-4 h-4 text-rose-300" />}
            >
              Add Friend by Code
            </MoonButton>
          </div>
        </div>
      ) : (
        <div className="rounded-3xl bg-black/55 border border-rose-500/30 divide-y divide-[#2D142C]/80 overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.88)]">
          {filteredFriends.map((friend) => {
            const isSelected = friend.id === activeFriendId;

            return (
              <div
                key={friend.id}
                className={`p-4 flex items-center justify-between gap-3 transition-all ${
                  isSelected
                    ? 'bg-gradient-to-r from-[#1A0B26]/85 to-[#22091B]/80 shadow-[inset_3px_0_0_#E11D48]'
                    : 'bg-black/35 hover:bg-[#13081E]/75'
                }`}
              >
                <button
                  type="button"
                  onClick={() => onSelectChat(friend.id)}
                  className="flex-1 min-w-0 flex items-center gap-3.5 text-left min-h-[48px] cursor-pointer"
                >
                  <LunarAvatar
                    name={friend.displayName}
                    hue={friend.avatarHue}
                    size="md"
                  />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-display text-sm font-semibold text-white truncate drop-shadow-[0_1px_6px_rgba(0,0,0,0.95)]">
                        {friend.displayName}
                      </span>
                      {friend.unreadCount > 0 && (
                        <span className="text-xs font-mono font-semibold text-rose-300 drop-shadow-[0_0_8px_rgba(225,29,72,0.5)]">
                          · {friend.unreadCount} new
                        </span>
                      )}
                    </div>

                    <div className="flex flex-wrap items-center gap-1.5 text-xs text-[#E2E8F0] mt-0.5 truncate">
                      <span>@{friend.username}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono text-rose-300">
                        {friend.friendCode}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{friend.lastSeenText}</span>
                    </div>

                    <p className="text-xs text-[#CBD5E1] truncate mt-1">
                      {friend.bio}
                    </p>
                  </div>
                </button>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => onSelectChat(friend.id)}
                    aria-label={`Message ${friend.displayName}`}
                    className="min-h-[44px] min-w-[44px] rounded-xl bg-[#160A24]/90 hover:bg-gradient-to-r hover:from-[#6D28D9] hover:to-[#9F1239] text-rose-200 hover:text-white border border-rose-500/30 flex items-center justify-center transition-all shadow-[0_0_12px_rgba(109,40,217,0.25)] cursor-pointer"
                    title="Open Private Chat"
                  >
                    <MessageSquare className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => onStartVoiceCallUI(friend.id)}
                    aria-label={`Voice call ${friend.displayName}`}
                    className="min-h-[44px] min-w-[44px] rounded-xl bg-[#160A24]/90 hover:bg-[#261136] text-[#F8FAFC] border border-[#3B1736] flex items-center justify-center transition-colors cursor-pointer"
                    title="Voice Call Friend"
                  >
                    <Phone className="w-4 h-4 text-rose-300" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
