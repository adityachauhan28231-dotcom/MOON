import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  BookOpen,
  Bookmark,
  Check,
  Copy,
  ExternalLink,
  Globe,
  Heart,
  Info,
  Languages,
  Loader2,
  RefreshCw,
  Search,
  Send,
  Share2,
  ShieldCheck,
  TrendingUp,
  X,
} from 'lucide-react';
import { FriendContact, UserProfile } from '../../types/moon';
import { MoonLogo } from '../ui/MoonLogo';
import { LunarAvatar } from '../ui/ReusablePrimitives';

export type TradingCategoryType =
  | 'India Market'
  | 'World Market'
  | 'Business News'
  | 'Gold & Silver'
  | 'Company Updates'
  | 'Crypto Education'
  | 'Trading Basics'
  | 'Market Updates';

export type TradingFilterId =
  | 'all'
  | 'india_market'
  | 'gold_silver'
  | 'company_updates'
  | 'world_market'
  | 'business_news'
  | 'crypto_education'
  | 'trading_basics'
  | 'market_updates'
  | 'saved';

export type TradingLanguageMode = 'hi' | 'en' | 'both';
export type TradingDateFilterMode = 'today' | 'previous' | 'all';

export interface MoonTradingArticleItem {
  id: string;
  sourceId: string;
  sourceName: string;
  sourceHandle: string;
  sourceLogoBadge: string;
  sourceWebsite: string;
  headline: string;
  summary: string;
  hindiHeadline: string;
  hindiSummary: string;
  englishSummary: string;
  articleUrl: string;
  imageUrl?: string;
  publishedAtIso: string;
  publishedAtText: string;
  publishedDateIst: string;
  isTodayIst: boolean;
  isYesterdayIst: boolean;
  dayBucket: 'today' | 'previous';
  relativeTimeText: string;
  language: 'hi' | 'en';
  primaryCategory: TradingCategoryType;
  categories: TradingCategoryType[];
  marketRegion: 'IN' | 'GLOBAL';
  marketRegionLabel: string;
  marketTags: string[];
  educationalTakeawayHindi: string;
  educationalTakeawayEnglish: string;
}

interface MoonTradingScreenProps {
  currentUser: UserProfile;
  friends: FriendContact[];
  onShareTradingToFriend: (
    friendId: string,
    messageText: string
  ) => Promise<void>;
  onOpenChatWithFriend: (friendId: string) => void;
}

const LIKED_TRADING_STORAGE_KEY = 'moon_trading_liked_ids_v1';
const SAVED_TRADING_ITEMS_STORAGE_KEY = 'moon_trading_saved_items_v1';

const TRADING_CATEGORY_TABS: Array<{
  id: TradingFilterId;
  labelHi: string;
  labelEn: string;
}> = [
  { id: 'all', labelHi: 'सभी मार्केट (All)', labelEn: 'All Markets' },
  {
    id: 'india_market',
    labelHi: 'इंडिया मार्केट 🇮🇳',
    labelEn: 'India Market 🇮🇳',
  },
  {
    id: 'gold_silver',
    labelHi: 'सोना-चांदी 🪙',
    labelEn: 'Gold & Silver 🪙',
  },
  {
    id: 'company_updates',
    labelHi: 'कंपनी अपडेट्स 🏢',
    labelEn: 'Company Updates 🏢',
  },
  {
    id: 'world_market',
    labelHi: 'वर्ल्ड मार्केट 🌍',
    labelEn: 'World Market 🌍',
  },
  {
    id: 'business_news',
    labelHi: 'बिज़नेस न्यूज़',
    labelEn: 'Business News',
  },
  {
    id: 'crypto_education',
    labelHi: 'क्रिप्टो शिक्षा',
    labelEn: 'Crypto Education',
  },
  {
    id: 'trading_basics',
    labelHi: 'ट्रेडिंग बेसिक्स',
    labelEn: 'Trading Basics',
  },
  {
    id: 'market_updates',
    labelHi: 'मार्केट अपडेट्स',
    labelEn: 'Market Updates',
  },
  { id: 'saved', labelHi: 'सेव्ड (Saved)', labelEn: 'Saved' },
];

const QUICK_MARKET_TOPICS = [
  'Nifty 50',
  'Sensex',
  'Gold & Silver',
  'NSE',
  'BSE',
  'Company Results',
  'RBI',
  'SEBI',
  'IPO',
  'Mutual Fund',
  'Wall Street',
];

interface EducationalLessonModule {
  id: string;
  category: 'Trading Basics' | 'India Market' | 'Crypto Education';
  titleHi: string;
  titleEn: string;
  summaryHi: string;
  summaryEn: string;
  keyPointsHi: string[];
  keyPointsEn: string[];
  officialUrl: string;
  officialLabel: string;
}

const EDUCATIONAL_MODULES: EducationalLessonModule[] = [
  {
    id: 'edu-nse-bse-indices',
    category: 'India Market',
    titleHi: 'NSE, BSE, Nifty 50 और Sensex क्या हैं?',
    titleEn: 'Understanding NSE, BSE, Nifty 50 & Sensex',
    summaryHi:
      'भारत में दो प्रमुख स्टॉक एक्सचेंज हैं: NSE (National Stock Exchange) और BSE (Bombay Stock Exchange)। Nifty 50 में 50 बड़ी भारतीय कंपनियां और Sensex में 30 प्रमुख कंपनियां शामिल होती हैं।',
    summaryEn:
      'India has two primary stock exchanges regulated by SEBI: NSE and BSE. Nifty 50 tracks 50 large-cap Indian companies across sectors, while BSE Sensex tracks 30 established blue-chip companies.',
    keyPointsHi: [
      'भारतीय शेयर बाज़ार का समय: सोमवार से शुक्रवार, सुबह 09:15 AM से दोपहर 03:30 PM IST तक।',
      'SEBI (भारतीय प्रतिभूति और विनिमय बोर्ड) निवेशकों के हितों की रक्षा करने वाला नियामक है।',
      'इंडेक्स (Nifty/Sensex) बाज़ार के समग्र आर्थिक स्वास्थ्य का संकेतक होता है।',
    ],
    keyPointsEn: [
      'Regular Equity Trading Hours: Monday to Friday, 09:15 AM – 03:30 PM IST.',
      'SEBI (Securities and Exchange Board of India) regulates Indian securities markets.',
      'Benchmark indices reflect broad market sentiment rather than individual stock tips.',
    ],
    officialUrl: 'https://investor.sebi.gov.in/',
    officialLabel: 'SEBI Investor Portal',
  },
  {
    id: 'edu-trading-basics-risk',
    category: 'Trading Basics',
    titleHi: 'ट्रेडिंग बेसिक्स: जोखिम प्रबंधन और विविधीकरण (Risk & Diversification)',
    titleEn: 'Trading Basics: Risk Management, Market Cap & Diversification',
    summaryHi:
      'वित्तीय साक्षरता में सबसे महत्वपूर्ण नियम पूंजी की सुरक्षा (Capital Preservation) और पोर्टफोलियो विविधीकरण (Diversification) है। बिना अध्ययन के अफ़वाहों पर निवेश न करें।',
    summaryEn:
      'Core financial literacy emphasizes capital preservation, understanding P/E valuation, earnings reports, and diversifying across asset classes instead of chasing short-term speculation.',
    keyPointsHi: [
      'फंडामेंटल एनालिसिस: कंपनी के रेवेन्यू, मुनाफे, कर्ज और बिजनेस मॉडल का अध्ययन।',
      'विविधीकरण (Diversification): सारा पैसा एक ही सेक्टर या स्टॉक में न रखना।',
      'म्यूचुअल फंड और SIP दीर्घकालिक अनुशासित निवेश को समझने के प्रमुख साधन हैं।',
    ],
    keyPointsEn: [
      'Fundamental Analysis studies balance sheets, cash flows, debt, and sector growth.',
      'Diversification spreads exposure across sectors to reduce single-company risk.',
      'Systematic Investment Plans (SIP) illustrate rupee-cost averaging over long horizons.',
    ],
    officialUrl: 'https://www.nseindia.com/learn',
    officialLabel: 'NSE Learn Hub',
  },
  {
    id: 'edu-crypto-blockchain',
    category: 'Crypto Education',
    titleHi: 'क्रिप्टो शिक्षा: ब्लॉकचेन तकनीक, CBDC (e₹) और जोखिम जागरूकता',
    titleEn: 'Crypto Education: Blockchain Technology, CBDC (e₹) & Volatility Risks',
    summaryHi:
      'ब्लॉकचेन एक विकेंद्रीकृत डिजिटल लेजर तकनीक है। भारत में RBI ने आधिकारिक डिजिटल रुपया (CBDC - e₹) शुरू किया है, जो निजी क्रिप्टोकरेंसी से पूरी तरह अलग है।',
    summaryEn:
      'Blockchain is a distributed ledger technology. In India, the Reserve Bank of India (RBI) issues the sovereign Digital Rupee (CBDC / e₹), which is distinct from volatile private crypto tokens.',
    keyPointsHi: [
      'निजी क्रिप्टो संपत्तियां अत्यधिक अस्थिर (volatile) होती हैं और इनमें सरकारी गारंटी नहीं होती।',
      'भारत में VDA (Virtual Digital Assets) पर 30% टैक्स और 1% TDS के नियम लागू हैं।',
      'कभी भी अज्ञात लिंक, फ़िशिंग वॉलेट या "गारंटीड रिटर्न" स्कीम पर भरोसा न करें।',
    ],
    keyPointsEn: [
      'Private virtual digital assets (VDAs) experience extreme price swings and carry high risk.',
      'In India, VDAs are subject to specific tax & regulatory compliance disclosures.',
      'Never share private keys/seed phrases or trust guaranteed-return schemes.',
    ],
    officialUrl: 'https://rbi.org.in/',
    officialLabel: 'RBI Official Portal',
  },
];

const getIstMarketSessionStatus = () => {
  const now = new Date();
  const istString = now.toLocaleString('en-US', { timeZone: 'Asia/Kolkata' });
  const istDate = new Date(istString);
  const day = istDate.getDay(); // 0 = Sun, 6 = Sat
  const minutes = istDate.getHours() * 60 + istDate.getMinutes();
  const isWeekday = day >= 1 && day <= 5;
  const isIndianMarketOpen =
    isWeekday && minutes >= 9 * 60 + 15 && minutes <= 15 * 60 + 30;

  const ymd = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Kolkata',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(now);

  const readableIst = new Intl.DateTimeFormat('en-IN', {
    timeZone: 'Asia/Kolkata',
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  }).format(now);

  const readableHindi = new Intl.DateTimeFormat('hi-IN', {
    timeZone: 'Asia/Kolkata',
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  }).format(now);

  const timeIst =
    now.toLocaleString('en-IN', {
      timeZone: 'Asia/Kolkata',
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    }) + ' IST';

  return {
    isIndianMarketOpen,
    ymd,
    readableIst,
    readableHindi,
    timeIst,
  };
};

export const MoonTradingScreen: React.FC<MoonTradingScreenProps> = ({
  friends,
  onShareTradingToFriend,
  onOpenChatWithFriend,
}) => {
  const initialSession = useMemo(() => getIstMarketSessionStatus(), []);
  const [activeCategory, setActiveCategory] = useState<TradingFilterId>('all');
  const [languageMode, setLanguageMode] = useState<TradingLanguageMode>('hi');
  const [dateFilter, setDateFilter] = useState<TradingDateFilterMode>('today');
  const [searchQuery, setSearchQuery] = useState('');
  const [appliedSearchQuery, setAppliedSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isEducationOpen, setIsEducationOpen] = useState(false);
  const [selectedLessonId, setSelectedLessonId] = useState<string>(
    EDUCATIONAL_MODULES[0].id
  );

  const [articles, setArticles] = useState<MoonTradingArticleItem[]>([]);
  const [totalAvailable, setTotalAvailable] = useState(0);
  const [todayCount, setTodayCount] = useState(0);
  const [previousDaysCount, setPreviousDaysCount] = useState(0);
  const [todayIstDateKey, setTodayIstDateKey] = useState(initialSession.ymd);
  const [todayFormattedIst, setTodayFormattedIst] = useState(
    initialSession.readableIst
  );
  const [todayFormattedHindi, setTodayFormattedHindi] = useState(
    initialSession.readableHindi
  );
  const [lastFetchedIstText, setLastFetchedIstText] = useState(
    initialSession.timeIst
  );
  const [isIndianMarketOpen, setIsIndianMarketOpen] = useState(
    initialSession.isIndianMarketOpen
  );
  const [hasMore, setHasMore] = useState(false);
  const [sourcesActiveCount, setSourcesActiveCount] = useState(10);

  const [isLoading, setIsLoading] = useState(true);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [feedError, setFeedError] = useState<string | null>(null);

  const [likedById, setLikedById] = useState<Record<string, boolean>>(() => {
    try {
      const raw = localStorage.getItem(LIKED_TRADING_STORAGE_KEY);
      return raw ? JSON.parse(raw) : {};
    } catch {
      return {};
    }
  });

  const [savedArticles, setSavedArticles] = useState<MoonTradingArticleItem[]>(
    () => {
      try {
        const raw = localStorage.getItem(SAVED_TRADING_ITEMS_STORAGE_KEY);
        return raw ? JSON.parse(raw) : [];
      } catch {
        return [];
      }
    }
  );

  const [translatedHindiById, setTranslatedHindiById] = useState<
    Record<string, string>
  >({});
  const [translatingById, setTranslatingById] = useState<
    Record<string, boolean>
  >({});
  const [failedImageById, setFailedImageById] = useState<
    Record<string, boolean>
  >({});

  const [sharingArticle, setSharingArticle] =
    useState<MoonTradingArticleItem | null>(null);
  const [sharingFriendId, setSharingFriendId] = useState<string | null>(null);
  const [sharedSuccessFriendId, setSharedSuccessFriendId] = useState<
    string | null
  >(null);
  const [shareError, setShareError] = useState<string | null>(null);
  const [copiedArticleId, setCopiedArticleId] = useState<string | null>(null);

  const loadMoreTriggerRef = useRef<HTMLDivElement | null>(null);
  const didInitialMountRefreshRef = useRef(false);

  const fetchTradingFeed = useCallback(
    async (params: {
      category: TradingFilterId;
      dateMode: TradingDateFilterMode;
      query: string;
      offset: number;
      append: boolean;
      forceRefresh?: boolean;
    }) => {
      const sessionNow = getIstMarketSessionStatus();
      setIsIndianMarketOpen(sessionNow.isIndianMarketOpen);
      setTodayIstDateKey(sessionNow.ymd);
      setTodayFormattedIst(sessionNow.readableIst);
      setTodayFormattedHindi(sessionNow.readableHindi);

      if (params.category === 'saved') {
        setIsLoading(false);
        setIsLoadingMore(false);
        setIsRefreshing(false);
        setFeedError(null);
        return;
      }

      if (params.offset === 0) {
        if (params.forceRefresh) {
          setIsRefreshing(true);
        } else {
          setIsLoading(true);
        }
      } else {
        setIsLoadingMore(true);
      }
      setFeedError(null);

      try {
        const searchParams = new URLSearchParams({
          category: params.category,
          dateFilter: params.dateMode,
          offset: String(params.offset),
          limit: '12',
        });
        if (params.query.trim()) {
          searchParams.set('q', params.query.trim());
        }
        if (params.forceRefresh) {
          searchParams.set('refresh', '1');
        }

        const res = await fetch(`/api/trading/feed?${searchParams.toString()}`);
        if (!res.ok) {
          throw new Error(
            `Trading feed server returned status ${res.status}. Please retry.`
          );
        }

        const data = (await res.json()) as {
          items?: MoonTradingArticleItem[];
          totalCount?: number;
          todayCount?: number;
          previousDaysCount?: number;
          todayIstDateKey?: string;
          todayFormattedIst?: string;
          todayFormattedHindi?: string;
          fetchedAtIstText?: string;
          sourcesActive?: number;
          hasMore?: boolean;
          error?: string;
        };

        if (data.error) {
          throw new Error(data.error);
        }

        const rawIncoming = Array.isArray(data.items) ? data.items : [];
        const seenIncoming = new Set<string>();
        const incoming = rawIncoming.filter((item) => {
          const key = `${item.id}|${item.articleUrl}`;
          if (seenIncoming.has(item.id) || seenIncoming.has(key)) return false;
          seenIncoming.add(item.id);
          seenIncoming.add(key);
          return true;
        });

        setArticles((prev) => {
          if (!params.append) return incoming;
          const existingIds = new Set(prev.map((a) => a.id));
          const existingUrls = new Set(prev.map((a) => a.articleUrl));
          return [
            ...prev,
            ...incoming.filter(
              (item) =>
                !existingIds.has(item.id) && !existingUrls.has(item.articleUrl)
            ),
          ];
        });

        setTotalAvailable(data.totalCount ?? incoming.length);
        if (typeof data.todayCount === 'number') {
          setTodayCount(data.todayCount);
        }
        if (typeof data.previousDaysCount === 'number') {
          setPreviousDaysCount(data.previousDaysCount);
        }
        if (data.todayIstDateKey) {
          setTodayIstDateKey(data.todayIstDateKey);
        }
        if (data.todayFormattedIst) {
          setTodayFormattedIst(data.todayFormattedIst);
        }
        if (data.todayFormattedHindi) {
          setTodayFormattedHindi(data.todayFormattedHindi);
        }
        setLastFetchedIstText(
          data.fetchedAtIstText || getIstMarketSessionStatus().timeIst
        );
        if (typeof data.sourcesActive === 'number') {
          setSourcesActiveCount(data.sourcesActive);
        }
        setHasMore(Boolean(data.hasMore));
      } catch (err) {
        setFeedError(
          err instanceof Error
            ? err.message
            : 'Unable to load live market & trading news right now. Please retry.'
        );
      } finally {
        setIsLoading(false);
        setIsLoadingMore(false);
        setIsRefreshing(false);
      }
    },
    []
  );

  // Fetch fresh market news when Trading screen opens or filters change
  useEffect(() => {
    const isFirstOpen = !didInitialMountRefreshRef.current;
    didInitialMountRefreshRef.current = true;
    void fetchTradingFeed({
      category: activeCategory,
      dateMode: dateFilter,
      query: appliedSearchQuery,
      offset: 0,
      append: false,
      forceRefresh: isFirstOpen,
    });
  }, [activeCategory, dateFilter, appliedSearchQuery, fetchTradingFeed]);

  // Auto-refresh every 5 minutes while Trading screen is open + when returning to tab
  useEffect(() => {
    if (activeCategory === 'saved') return;

    const intervalId = window.setInterval(() => {
      void fetchTradingFeed({
        category: activeCategory,
        dateMode: dateFilter,
        query: appliedSearchQuery,
        offset: 0,
        append: false,
        forceRefresh: true,
      });
    }, 5 * 60 * 1000);

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        void fetchTradingFeed({
          category: activeCategory,
          dateMode: dateFilter,
          query: appliedSearchQuery,
          offset: 0,
          append: false,
          forceRefresh: true,
        });
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => {
      window.clearInterval(intervalId);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [activeCategory, dateFilter, appliedSearchQuery, fetchTradingFeed]);

  // Infinite scroll IntersectionObserver
  useEffect(() => {
    if (
      activeCategory === 'saved' ||
      !hasMore ||
      isLoading ||
      isLoadingMore ||
      Boolean(feedError)
    ) {
      return;
    }
    const target = loadMoreTriggerRef.current;
    if (!target || typeof IntersectionObserver === 'undefined') return;

    const observer = new IntersectionObserver(
      (entries) => {
        const first = entries[0];
        if (first?.isIntersecting && !isLoadingMore) {
          void fetchTradingFeed({
            category: activeCategory,
            dateMode: dateFilter,
            query: appliedSearchQuery,
            offset: articles.length,
            append: true,
          });
        }
      },
      { rootMargin: '260px' }
    );

    observer.observe(target);
    return () => observer.disconnect();
  }, [
    activeCategory,
    dateFilter,
    appliedSearchQuery,
    articles.length,
    hasMore,
    isLoading,
    isLoadingMore,
    feedError,
    fetchTradingFeed,
  ]);

  const handleToggleLike = (article: MoonTradingArticleItem) => {
    setLikedById((prev) => {
      const next = { ...prev, [article.id]: !prev[article.id] };
      try {
        localStorage.setItem(LIKED_TRADING_STORAGE_KEY, JSON.stringify(next));
      } catch {
        // Ignore storage quota
      }
      return next;
    });
  };

  const handleToggleSave = (article: MoonTradingArticleItem) => {
    setSavedArticles((prev) => {
      const exists = prev.some((a) => a.articleUrl === article.articleUrl);
      const next = exists
        ? prev.filter((a) => a.articleUrl !== article.articleUrl)
        : [article, ...prev];
      try {
        localStorage.setItem(
          SAVED_TRADING_ITEMS_STORAGE_KEY,
          JSON.stringify(next)
        );
      } catch {
        // Ignore storage quota
      }
      return next;
    });
  };

  const handleTranslateToHindi = async (article: MoonTradingArticleItem) => {
    if (translatingById[article.id] || translatedHindiById[article.id]) return;
    setTranslatingById((prev) => ({ ...prev, [article.id]: true }));
    try {
      const textToTranslate = `${article.headline}. ${article.summary.slice(
        0,
        240
      )}`;
      const res = await fetch('/api/news/translate-hindi', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: textToTranslate }),
      });
      if (res.ok) {
        const data = (await res.json()) as { hindiText?: string };
        if (data.hindiText) {
          setTranslatedHindiById((prev) => ({
            ...prev,
            [article.id]: data.hindiText!,
          }));
        }
      }
    } catch {
      // Ignore translation error
    } finally {
      setTranslatingById((prev) => ({ ...prev, [article.id]: false }));
    }
  };

  const handleCopyArticleLink = async (article: MoonTradingArticleItem) => {
    try {
      await navigator.clipboard.writeText(article.articleUrl);
      setCopiedArticleId(article.id);
      setTimeout(() => setCopiedArticleId(null), 2200);
    } catch {
      // Ignore clipboard error
    }
  };

  const handleShareToFriend = async (
    friend: FriendContact,
    article: MoonTradingArticleItem
  ) => {
    setSharingFriendId(friend.id);
    setShareError(null);
    setSharedSuccessFriendId(null);

    const hindiText =
      translatedHindiById[article.id] || article.hindiSummary;
    const messageText = `📈 MOON TRADING & MARKET UPDATE (${article.primaryCategory} • ${article.sourceName})\n${article.headline}\n🇮🇳 ${hindiText}\n🔗 ${article.articleUrl}`;

    try {
      await onShareTradingToFriend(friend.id, messageText);
      setSharedSuccessFriendId(friend.id);
    } catch (err) {
      setShareError(
        err instanceof Error
          ? err.message
          : 'Failed to share market article with friend.'
      );
    } finally {
      setSharingFriendId(null);
    }
  };

  const displayedArticles = useMemo(() => {
    if (activeCategory === 'saved') {
      return savedArticles;
    }
    return articles;
  }, [activeCategory, articles, savedArticles]);

  const activeLesson = useMemo(() => {
    return (
      EDUCATIONAL_MODULES.find((m) => m.id === selectedLessonId) ||
      EDUCATIONAL_MODULES[0]
    );
  }, [selectedLessonId]);

  return (
    <section
      aria-label="MOON Trading & Market Education Feed"
      className="w-full max-w-2xl mx-auto space-y-4 pb-16 select-none"
    >
      {/* 1. DARK PURPLE & PINK MOON TRADING HEADER BAR */}
      <div className="sticky top-14 z-20 rounded-3xl bg-[#07020F]/95 backdrop-blur-xl border border-[#4A154B] px-4 py-3.5 shadow-[0_16px_42px_rgba(0,0,0,0.92)] space-y-3">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5 min-w-0">
            <MoonLogo size="sm" showWordmark headerCreatorBadge />
            <div className="flex items-center gap-1.5 text-xs font-bold tracking-wide text-pink-300">
              <TrendingUp className="w-4 h-4 text-pink-400 shrink-0" />
              <span className="truncate">TRADING &amp; MARKETS</span>
            </div>
          </div>

          {/* Right Controls: Language Toggle (Hindi / English), Search, Education Hub, Saved, Refresh */}
          <div className="flex items-center gap-1.5 shrink-0">
            {/* Hindi / English Language Switcher */}
            <div
              role="group"
              aria-label="Trading Feed Language"
              className="flex items-center p-0.5 rounded-xl bg-[#120520] border border-[#4A154B]"
            >
              <button
                type="button"
                onClick={() => setLanguageMode('hi')}
                className={`px-2 py-1 rounded-lg text-[11px] font-bold cursor-pointer transition-colors ${
                  languageMode === 'hi'
                    ? 'bg-gradient-to-r from-[#7E22CE] to-[#EC4899] text-white'
                    : 'text-[#C4B5FD] hover:text-white'
                }`}
                title="Display Market News in Hindi"
              >
                हिंदी
              </button>
              <button
                type="button"
                onClick={() => setLanguageMode('en')}
                className={`px-2 py-1 rounded-lg text-[11px] font-bold cursor-pointer transition-colors ${
                  languageMode === 'en'
                    ? 'bg-gradient-to-r from-[#7E22CE] to-[#EC4899] text-white'
                    : 'text-[#C4B5FD] hover:text-white'
                }`}
                title="Display Market News in English"
              >
                EN
              </button>
              <button
                type="button"
                onClick={() => setLanguageMode('both')}
                className={`hidden sm:inline-block px-2 py-1 rounded-lg text-[10px] font-semibold cursor-pointer transition-colors ${
                  languageMode === 'both'
                    ? 'bg-gradient-to-r from-[#7E22CE] to-[#EC4899] text-white'
                    : 'text-[#C4B5FD] hover:text-white'
                }`}
                title="Show Both Hindi & English"
              >
                HI+EN
              </button>
            </div>

            <button
              type="button"
              onClick={() => setIsSearchOpen((prev) => !prev)}
              className={`w-9 h-9 rounded-xl border flex items-center justify-center cursor-pointer transition-all active:scale-95 ${
                isSearchOpen || appliedSearchQuery
                  ? 'bg-gradient-to-r from-[#7E22CE] to-[#EC4899] border-pink-400 text-white shadow-[0_0_14px_rgba(236,72,153,0.45)]'
                  : 'bg-[#120520] hover:bg-[#1E0933] border-[#3B1245] text-white'
              }`}
              aria-label="Search market news"
              title="Search Stocks, NSE, BSE, Nifty, Sensex"
            >
              <Search className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={() => setIsEducationOpen((prev) => !prev)}
              className={`w-9 h-9 rounded-xl border flex items-center justify-center cursor-pointer transition-all active:scale-95 ${
                isEducationOpen
                  ? 'bg-gradient-to-r from-[#7E22CE] to-[#EC4899] border-pink-400 text-white shadow-[0_0_14px_rgba(236,72,153,0.45)]'
                  : 'bg-[#120520] hover:bg-[#1E0933] border-[#3B1245] text-pink-300'
              }`}
              aria-label="Trading & Crypto Education Guides"
              title="Trading Basics & Crypto Education Guides"
            >
              <BookOpen className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={() =>
                setActiveCategory((prev) =>
                  prev === 'saved' ? 'all' : 'saved'
                )
              }
              className={`h-9 px-2.5 rounded-xl border text-xs font-semibold inline-flex items-center gap-1 cursor-pointer transition-all active:scale-95 ${
                activeCategory === 'saved'
                  ? 'bg-purple-600 border-pink-300 text-white'
                  : 'bg-[#120520] hover:bg-[#1E0933] border-[#3B1245] text-[#E9D5FF]'
              }`}
              aria-label="Saved Trading Posts"
              title="Saved Market News"
            >
              <Bookmark className="w-3.5 h-3.5 text-pink-300" />
              <span className="text-[11px]">{savedArticles.length}</span>
            </button>

            <button
              type="button"
              disabled={isRefreshing || isLoading}
              onClick={() =>
                void fetchTradingFeed({
                  category: activeCategory,
                  dateMode: dateFilter,
                  query: appliedSearchQuery,
                  offset: 0,
                  append: false,
                  forceRefresh: true,
                })
              }
              className="h-9 px-3 rounded-xl bg-gradient-to-r from-[#7E22CE] to-[#EC4899] hover:brightness-110 border border-pink-400/50 text-white text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer transition-all active:scale-95 disabled:opacity-50 shadow-[0_0_14px_rgba(236,72,153,0.4)]"
              aria-label="Refresh Market News"
              title="Refresh Live Market RSS Feeds"
            >
              <RefreshCw
                className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`}
              />
              <span className="hidden sm:inline">
                {isRefreshing ? 'Refreshing...' : 'Refresh'}
              </span>
            </button>
          </div>
        </div>

        {/* ASIA/KOLKATA DAILY MARKET STATUS & TODAY / PREVIOUS DAYS FILTER */}
        <div className="p-2.5 rounded-2xl bg-[#0D041A] border border-[#3B1245] flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-1.5 text-[11px] text-white">
              <span className="font-semibold text-pink-300">
                {languageMode === 'en' ? todayFormattedIst : todayFormattedHindi}
              </span>
              <span aria-hidden="true" className="text-[#8E8AA6]">
                ·
              </span>
              <span className="font-mono text-[#D8B4FE]">
                IST ({todayIstDateKey})
              </span>
              <span aria-hidden="true" className="text-[#8E8AA6]">
                ·
              </span>
              <span
                className={
                  isIndianMarketOpen
                    ? 'text-emerald-300 font-semibold'
                    : 'text-pink-200/90 font-medium'
                }
              >
                {isIndianMarketOpen
                  ? 'NSE/BSE Session Open (09:15–15:30 IST)'
                  : 'NSE/BSE Regular Session Closed'}
              </span>
            </div>
            <p className="text-[10px] text-[#A78BFA] mt-0.5">
              {sourcesActiveCount} Live Market RSS Feeds · Synced:{' '}
              {lastFetchedIstText}
            </p>
          </div>

          <div
            role="group"
            aria-label="Filter Market News by Date"
            className="flex items-center gap-1 p-1 rounded-xl bg-[#140626] border border-[#3B1245] shrink-0"
          >
            <button
              type="button"
              onClick={() => setDateFilter('today')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold cursor-pointer transition-colors ${
                dateFilter === 'today'
                  ? 'bg-gradient-to-r from-[#7E22CE] to-[#EC4899] text-white'
                  : 'text-[#D8B4FE] hover:text-white'
              }`}
            >
              {languageMode === 'en'
                ? `Today (${todayCount})`
                : `आज (${todayCount})`}
            </button>
            <button
              type="button"
              onClick={() => setDateFilter('previous')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold cursor-pointer transition-colors ${
                dateFilter === 'previous'
                  ? 'bg-gradient-to-r from-[#7E22CE] to-[#EC4899] text-white'
                  : 'text-[#D8B4FE] hover:text-white'
              }`}
            >
              {languageMode === 'en'
                ? `Previous (${previousDaysCount})`
                : `पिछले दिन (${previousDaysCount})`}
            </button>
            <button
              type="button"
              onClick={() => setDateFilter('all')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold cursor-pointer transition-colors ${
                dateFilter === 'all'
                  ? 'bg-gradient-to-r from-[#7E22CE] to-[#EC4899] text-white'
                  : 'text-[#D8B4FE] hover:text-white'
              }`}
            >
              {languageMode === 'en' ? 'All' : 'सभी'}
            </button>
          </div>
        </div>

        {/* EXPANDABLE MARKET SEARCH BAR */}
        {isSearchOpen && (
          <div className="pt-2 border-t border-[#3B1245] space-y-2 animate-[devilScreenFadeIn_160ms_ease-out]">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                setAppliedSearchQuery(searchQuery.trim());
                if (activeCategory === 'saved') setActiveCategory('all');
              }}
              className="flex items-center gap-2"
            >
              <div className="relative flex-1 min-w-0">
                <Search className="w-3.5 h-3.5 text-[#A78BFA] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={
                    languageMode === 'en'
                      ? 'Search Nifty 50, Sensex, NSE, BSE, RBI, IPO, Nasdaq, Crypto...'
                      : 'Nifty 50, Sensex, NSE, BSE, IPO, म्यूचुअल फंड, क्रिप्टो खोजें...'
                  }
                  className="w-full h-9 pl-8 pr-8 rounded-xl bg-black border border-[#4A154B] focus:border-pink-500 text-xs text-white placeholder:text-[#7C689B] focus:outline-none"
                />
                {(searchQuery || appliedSearchQuery) && (
                  <button
                    type="button"
                    onClick={() => {
                      setSearchQuery('');
                      setAppliedSearchQuery('');
                    }}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#A78BFA] hover:text-white cursor-pointer"
                    aria-label="Clear market search"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
              <button
                type="submit"
                className="h-9 px-3.5 rounded-xl bg-gradient-to-r from-[#7E22CE] to-[#EC4899] text-white text-xs font-semibold cursor-pointer shrink-0 active:scale-95"
              >
                {languageMode === 'en' ? 'Search' : 'खोजें'}
              </button>
            </form>

            {/* Quick Market Search Filter Buttons */}
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
              {QUICK_MARKET_TOPICS.map((topic) => (
                <button
                  key={topic}
                  type="button"
                  onClick={() => {
                    setSearchQuery(topic);
                    setAppliedSearchQuery(topic);
                    if (activeCategory === 'saved') setActiveCategory('all');
                  }}
                  className="px-2.5 py-1 rounded-lg bg-[#16072B] hover:bg-[#270B47] border border-[#4A154B] text-[10px] font-medium text-pink-200 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  {topic}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* 6 REQUIRED CATEGORIES FILTER BAR: India Market, World Market, Business News, Crypto Education, Trading Basics, Market Updates */}
        <div
          role="tablist"
          aria-label="Trading and Market Categories"
          className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5"
        >
          {TRADING_CATEGORY_TABS.map((tab) => {
            const isSelected = activeCategory === tab.id;
            return (
              <button
                key={tab.id}
                role="tab"
                aria-selected={isSelected}
                type="button"
                onClick={() => setActiveCategory(tab.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 transition-all cursor-pointer border ${
                  isSelected
                    ? 'bg-gradient-to-r from-[#7E22CE] to-[#EC4899] text-white border-pink-400/60 shadow-[0_0_16px_rgba(236,72,153,0.4)]'
                    : 'bg-[#120520] border-[#3B1245] text-[#D8B4FE] hover:text-white hover:border-pink-500/40'
                }`}
              >
                {languageMode === 'en' ? tab.labelEn : tab.labelHi}
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. OFFICIAL INDIAN & GLOBAL EXCHANGE REFERENCE BAR (NO FAKE LIVE PRICES) */}
      <div className="rounded-3xl bg-gradient-to-br from-[#120422] via-[#1B0630] to-[#080210] border border-[#4A154B] p-4 shadow-[0_14px_34px_rgba(0,0,0,0.88)] space-y-3">
        <div className="flex items-center justify-between gap-2">
          <div className="text-xs font-bold text-white flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-pink-400 shrink-0" />
            <span>
              {languageMode === 'en'
                ? 'Indian & Global Market Benchmarks (Official Exchange Links)'
                : 'भारतीय और ग्लोबल मार्केट बेंचमार्क (NSE • BSE • Nifty 50 • Sensex)'}
            </span>
          </div>
          <button
            type="button"
            onClick={() => setIsEducationOpen((prev) => !prev)}
            className="text-[11px] font-semibold text-pink-300 hover:text-white underline cursor-pointer shrink-0"
          >
            {isEducationOpen
              ? languageMode === 'en'
                ? 'Hide Learning Guide'
                : 'गाइड बंद करें'
              : languageMode === 'en'
              ? 'Trading Basics Guide'
              : 'ट्रेडिंग बेसिक्स सीखें'}
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          <button
            type="button"
            onClick={() => {
              setActiveCategory('india_market');
              setSearchQuery('Nifty 50');
              setAppliedSearchQuery('Nifty 50');
            }}
            className="p-3 rounded-2xl bg-[#0B0315]/90 hover:bg-[#19072E] border border-[#3B1245] text-left transition-colors cursor-pointer"
          >
            <p className="text-xs font-bold text-white">NIFTY 50 · NSE</p>
            <p className="text-[11px] text-pink-300 mt-0.5">
              {languageMode === 'en'
                ? 'Top 50 Indian Equities'
                : '50 प्रमुख भारतीय कंपनियां'}
            </p>
            <p className="text-[10px] text-[#A78BFA] mt-1">
              Filter Nifty 50 News →
            </p>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveCategory('india_market');
              setSearchQuery('Sensex');
              setAppliedSearchQuery('Sensex');
            }}
            className="p-3 rounded-2xl bg-[#0B0315]/90 hover:bg-[#19072E] border border-[#3B1245] text-left transition-colors cursor-pointer"
          >
            <p className="text-xs font-bold text-white">SENSEX · BSE</p>
            <p className="text-[11px] text-pink-300 mt-0.5">
              {languageMode === 'en'
                ? '30 Blue-Chip Companies'
                : '30 प्रमुख बीएसई कंपनियां'}
            </p>
            <p className="text-[10px] text-[#A78BFA] mt-1">
              Filter Sensex News →
            </p>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveCategory('world_market');
              setSearchQuery('');
              setAppliedSearchQuery('');
            }}
            className="p-3 rounded-2xl bg-[#0B0315]/90 hover:bg-[#19072E] border border-[#3B1245] text-left transition-colors cursor-pointer"
          >
            <p className="text-xs font-bold text-white">WORLD MARKETS</p>
            <p className="text-[11px] text-pink-300 mt-0.5">
              Nasdaq · S&amp;P 500 · Nikkei
            </p>
            <p className="text-[10px] text-[#A78BFA] mt-1">
              Global Market News →
            </p>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveCategory('trading_basics');
              setIsEducationOpen(true);
            }}
            className="p-3 rounded-2xl bg-[#0B0315]/90 hover:bg-[#19072E] border border-[#3B1245] text-left transition-colors cursor-pointer"
          >
            <p className="text-xs font-bold text-white">INVESTOR BASICS</p>
            <p className="text-[11px] text-pink-300 mt-0.5">
              {languageMode === 'en'
                ? 'SEBI · SIP · Crypto Edu'
                : 'निवेश और क्रिप्टो शिक्षा'}
            </p>
            <p className="text-[10px] text-[#A78BFA] mt-1">
              Open Learning Hub →
            </p>
          </button>
        </div>

        {/* Educational & Non-Advisory Notice */}
        <div className="px-3 py-2 rounded-xl bg-[#090212] border border-[#3B1245] flex items-start gap-2 text-[11px] text-[#D8B4FE]">
          <Info className="w-4 h-4 text-pink-400 shrink-0 mt-0.5" />
          <p className="leading-relaxed">
            {languageMode === 'en'
              ? 'Educational & Informational Only: MOON Trading aggregates verified market news and investor literacy resources. We do not show fabricated live prices, provide personalized financial advice, or execute real-money trades.'
              : 'केवल शैक्षिक और सूचनात्मक उद्देश्य: MOON Trading वास्तविक समाचार स्रोतों से मार्केट अपडेट और वित्तीय साक्षरता प्रदान करता है। यह कोई निवेश सलाह (Financial Advice) या खरीद-बिक्री की सिफारिश नहीं है।'}
          </p>
        </div>
      </div>

      {/* 3. INTERACTIVE TRADING BASICS & CRYPTO EDUCATION HUB (Shown when toggled or when Trading Basics / Crypto Education tab is active) */}
      {(isEducationOpen ||
        activeCategory === 'trading_basics' ||
        activeCategory === 'crypto_education') && (
        <div className="rounded-3xl bg-[#0B0317] border border-pink-500/40 p-4 shadow-[0_18px_44px_rgba(0,0,0,0.92)] space-y-3 animate-[devilScreenFadeIn_160ms_ease-out]">
          <div className="flex items-center justify-between gap-2">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-pink-400" />
              <span>
                {languageMode === 'en'
                  ? 'Trading Basics & Crypto Education Modules'
                  : 'ट्रेडिंग बेसिक्स और क्रिप्टो शिक्षा मॉड्यूल'}
              </span>
            </h2>
            {isEducationOpen && (
              <button
                type="button"
                onClick={() => setIsEducationOpen(false)}
                className="text-xs text-[#C4B5FD] hover:text-white cursor-pointer"
              >
                Close
              </button>
            )}
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
            {EDUCATIONAL_MODULES.map((mod) => {
              const isSelected = activeLesson.id === mod.id;
              return (
                <button
                  key={mod.id}
                  type="button"
                  onClick={() => setSelectedLessonId(mod.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap cursor-pointer border transition-all ${
                    isSelected
                      ? 'bg-gradient-to-r from-[#7E22CE] to-[#EC4899] text-white border-pink-400'
                      : 'bg-[#140626] border-[#3B1245] text-[#D8B4FE] hover:text-white'
                  }`}
                >
                  {languageMode === 'en' ? mod.titleEn : mod.titleHi}
                </button>
              );
            })}
          </div>

          <div className="p-3.5 rounded-2xl bg-[#120521] border border-[#3B1245] space-y-2.5">
            <h3 className="text-sm font-bold text-pink-200">
              {languageMode === 'en'
                ? activeLesson.titleEn
                : activeLesson.titleHi}
            </h3>
            <p className="text-xs text-[#F3E8FF] leading-relaxed">
              {languageMode === 'en'
                ? activeLesson.summaryEn
                : activeLesson.summaryHi}
            </p>
            {languageMode === 'both' && (
              <p className="text-xs text-[#C4B5FD] leading-relaxed">
                {activeLesson.summaryEn}
              </p>
            )}
            <ul className="space-y-1 text-xs text-[#D8B4FE] list-disc pl-4">
              {(languageMode === 'en'
                ? activeLesson.keyPointsEn
                : activeLesson.keyPointsHi
              ).map((pt) => (
                <li key={pt}>{pt}</li>
              ))}
            </ul>
            <div className="pt-1 flex items-center justify-between gap-2">
              <span className="text-[11px] text-[#A78BFA]">
                Category: {activeLesson.category}
              </span>
              <a
                href={activeLesson.officialUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-3 py-1.5 rounded-xl bg-[#1F0937] hover:bg-[#2D0D4F] border border-pink-500/40 text-xs font-semibold text-pink-200 inline-flex items-center gap-1.5"
              >
                <span>{activeLesson.officialLabel}</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        </div>
      )}

      {/* ACTIVE SEARCH FILTER BANNER */}
      {appliedSearchQuery && (
        <div className="px-4 py-2.5 rounded-2xl bg-[#16072B] border border-pink-500/40 flex items-center justify-between gap-2 text-xs text-pink-200">
          <span>
            {languageMode === 'en'
              ? 'Showing live market RSS results for '
              : 'लाइव मार्केट परिणाम: '}
            <strong className="text-white">&ldquo;{appliedSearchQuery}&rdquo;</strong>{' '}
            ({totalAvailable})
          </span>
          <button
            type="button"
            onClick={() => {
              setSearchQuery('');
              setAppliedSearchQuery('');
            }}
            className="px-2.5 py-1 rounded-lg bg-pink-600 text-white text-[11px] font-semibold cursor-pointer"
          >
            {languageMode === 'en' ? 'Clear' : 'हटाएं'}
          </button>
        </div>
      )}

      {/* 4. INSTAGRAM-STYLE MARKET NEWS FEED CARDS */}
      {isLoading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((n) => (
            <div
              key={n}
              className="rounded-3xl bg-[#090214]/95 border border-[#3B1245] p-4 space-y-3 animate-pulse"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-[#1F0937]" />
                <div className="space-y-1.5 flex-1">
                  <div className="h-3 w-36 rounded bg-[#1F0937]" />
                  <div className="h-2.5 w-24 rounded bg-[#140626]" />
                </div>
              </div>
              <div className="w-full aspect-[16/10] rounded-2xl bg-[#140626]" />
              <div className="h-4 w-5/6 rounded bg-[#1F0937]" />
              <div className="h-3 w-2/3 rounded bg-[#140626]" />
            </div>
          ))}
        </div>
      ) : feedError ? (
        <div className="rounded-3xl bg-[#0B0317] border border-pink-500/45 p-6 text-center space-y-3 shadow-2xl">
          <div className="w-12 h-12 rounded-2xl bg-pink-950/80 border border-pink-500/40 flex items-center justify-center mx-auto">
            <AlertTriangle className="w-6 h-6 text-pink-400" />
          </div>
          <h2 className="text-base font-bold text-white">
            Unable to Load Live Market News
          </h2>
          <p className="text-xs text-[#D8B4FE] max-w-md mx-auto leading-relaxed">
            {feedError}
          </p>
          <button
            type="button"
            onClick={() =>
              void fetchTradingFeed({
                category: activeCategory,
                dateMode: dateFilter,
                query: appliedSearchQuery,
                offset: 0,
                append: false,
                forceRefresh: true,
              })
            }
            className="min-h-[42px] px-5 py-2.5 rounded-2xl bg-gradient-to-r from-[#7E22CE] to-[#EC4899] text-white text-xs font-semibold inline-flex items-center gap-2 cursor-pointer"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Retry Loading Market Feed</span>
          </button>
        </div>
      ) : displayedArticles.length === 0 ? (
        <div className="rounded-3xl bg-[#090214]/95 border border-[#3B1245] p-8 text-center space-y-3">
          <TrendingUp className="w-10 h-10 text-pink-400/70 mx-auto" />
          <h3 className="text-sm font-bold text-white">
            {activeCategory === 'saved'
              ? languageMode === 'en'
                ? 'No Saved Market News Yet'
                : 'अभी कोई मार्केट न्यूज़ सेव नहीं की गई है'
              : languageMode === 'en'
              ? 'No Market News Found in This Filter'
              : 'इस फ़िल्टर में कोई नई मार्केट ख़बर उपलब्ध नहीं है'}
          </h3>
          <p className="text-xs text-[#C4B5FD] max-w-md mx-auto leading-relaxed">
            {activeCategory === 'saved'
              ? 'Tap the Bookmark icon on any NSE, BSE, World Market, or Crypto Education post to save it for later reading.'
              : 'Try refreshing live RSS feeds or switching to All Markets / Previous Days.'}
          </p>
          <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
            <button
              type="button"
              onClick={() => {
                setActiveCategory('all');
                setDateFilter('all');
                setSearchQuery('');
                setAppliedSearchQuery('');
              }}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#7E22CE] to-[#EC4899] text-white text-xs font-semibold cursor-pointer"
            >
              {languageMode === 'en'
                ? 'View All Market News'
                : 'सभी मार्केट ख़बरें देखें'}
            </button>
          </div>
        </div>
      ) : (
        <div className="space-y-5">
          {displayedArticles.map((article) => {
            const isLiked = Boolean(likedById[article.id]);
            const isSaved = savedArticles.some(
              (a) => a.articleUrl === article.articleUrl
            );
            const hasValidImage =
              Boolean(article.imageUrl) && !failedImageById[article.id];
            const displayedHindiSummary =
              translatedHindiById[article.id] || article.hindiSummary;
            const isArticleToday =
              article.isTodayIst ??
              article.publishedDateIst === todayIstDateKey;

            const primaryTitle =
              languageMode === 'hi'
                ? article.hindiHeadline || article.headline
                : article.headline;

            return (
              <article
                key={article.id}
                className="rounded-3xl bg-[#07020F]/95 border border-[#4A154B] overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.92)] transition-all hover:border-pink-500/50"
              >
                {/* POST HEADER: Source Avatar, Source Name, Clean Unboxed Metadata (Category · Date · Region) */}
                <div className="px-4 py-3 flex items-center justify-between gap-3 border-b border-[#2A0B35]">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="p-[2px] rounded-full bg-gradient-to-tr from-[#EC4899] via-[#A855F7] to-[#6D28D9] shrink-0">
                      <div className="w-9 h-9 rounded-full bg-[#0B0315] flex items-center justify-center text-[10px] font-extrabold tracking-tighter text-pink-200 border border-black">
                        {article.sourceLogoBadge.slice(0, 6)}
                      </div>
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <a
                          href={article.articleUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-xs sm:text-sm font-bold text-white hover:text-pink-300 truncate"
                        >
                          {article.sourceName}
                        </a>
                        <span
                          title="Verified Market RSS Publisher"
                          className="inline-flex items-center shrink-0"
                        >
                          <ShieldCheck className="w-3.5 h-3.5 text-pink-400" />
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center gap-1.5 text-[11px] text-[#C4B5FD]">
                        <span className="text-pink-300 font-medium">
                          {article.primaryCategory}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span>{article.publishedAtText}</span>
                        <span aria-hidden="true">·</span>
                        <span
                          className={
                            isArticleToday
                              ? 'text-emerald-300 font-semibold'
                              : 'text-amber-300'
                          }
                        >
                          {isArticleToday
                            ? languageMode === 'en'
                              ? 'Today'
                              : 'आज (Today)'
                            : article.publishedDateIst}
                        </span>
                      </div>
                    </div>
                  </div>

                  <a
                    href={article.articleUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-8 h-8 rounded-full bg-[#16072B] hover:bg-pink-950/80 border border-[#3B1245] text-pink-300 flex items-center justify-center shrink-0"
                    title="Open original market article"
                    aria-label={`Open ${article.headline} on ${article.sourceName}`}
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>

                {/* POST IMAGE OR DARK PURPLE/PINK MARKET VISUAL STAGE */}
                <div
                  onDoubleClick={() => handleToggleLike(article)}
                  className="relative w-full bg-[#0D041A] overflow-hidden border-b border-[#2A0B35]"
                >
                  {hasValidImage ? (
                    <a
                      href={article.articleUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block relative w-full aspect-[16/10] overflow-hidden group"
                    >
                      <img
                        src={article.imageUrl}
                        alt={article.headline}
                        loading="lazy"
                        onError={() =>
                          setFailedImageById((prev) => ({
                            ...prev,
                            [article.id]: true,
                          }))
                        }
                        className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
                      <div className="absolute bottom-3 left-3 right-3 flex items-end justify-between gap-2 text-xs text-white">
                        <span className="font-medium text-pink-200 drop-shadow">
                          {article.marketRegionLabel} · {article.sourceName}
                        </span>
                        <span className="px-2.5 py-1 rounded-lg bg-pink-600/90 text-white text-[10px] font-semibold inline-flex items-center gap-1 shadow-lg">
                          <span>
                            {languageMode === 'en'
                              ? 'Open Report'
                              : 'रिपोर्ट पढ़ें'}
                          </span>
                          <ExternalLink className="w-3 h-3" />
                        </span>
                      </div>
                    </a>
                  ) : (
                    <a
                      href={article.articleUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block relative w-full py-7 px-5 bg-gradient-to-br from-[#1E0836] via-[#3B0A45] to-[#090214] hover:brightness-110 transition-all"
                    >
                      <div className="flex items-center justify-between gap-2 mb-2.5 text-[11px] text-pink-300">
                        <span className="font-semibold">
                          {article.marketRegionLabel} · {article.primaryCategory}
                        </span>
                        <span className="font-mono text-[#D8B4FE]">
                          {article.sourceName}
                        </span>
                      </div>
                      <h3 className="font-display text-base sm:text-lg font-bold text-white leading-snug">
                        {primaryTitle}
                      </h3>
                    </a>
                  )}
                </div>

                {/* SOCIAL ACTION BAR: Like, Share with Friends, Copy Link, Save/Bookmark */}
                <div className="px-4 pt-3 pb-2 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 sm:gap-2.5">
                    <button
                      type="button"
                      onClick={() => handleToggleLike(article)}
                      className={`h-9 px-3 rounded-xl border text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer transition-all active:scale-90 ${
                        isLiked
                          ? 'bg-pink-600 border-pink-400 text-white shadow-[0_0_16px_rgba(236,72,153,0.5)]'
                          : 'bg-[#120520] hover:bg-pink-950/60 border-[#3B1245] text-white'
                      }`}
                      aria-label={
                        isLiked ? 'Unlike market post' : 'Like market post'
                      }
                    >
                      <Heart
                        className={`w-4 h-4 ${
                          isLiked ? 'fill-current text-white' : 'text-pink-400'
                        }`}
                      />
                      <span>
                        {isLiked
                          ? languageMode === 'en'
                            ? 'Liked'
                            : 'पसंद किया'
                          : languageMode === 'en'
                          ? 'Like'
                          : 'लाइक'}
                      </span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setSharingArticle(article);
                        setSharedSuccessFriendId(null);
                        setShareError(null);
                      }}
                      className="h-9 px-3 rounded-xl bg-[#120520] hover:bg-[#1F0937] border border-[#3B1245] text-xs font-semibold text-white inline-flex items-center gap-1.5 cursor-pointer transition-all active:scale-95"
                      aria-label="Share market news with MOON friends"
                    >
                      <Share2 className="w-4 h-4 text-pink-300" />
                      <span>{languageMode === 'en' ? 'Share' : 'शेयर'}</span>
                    </button>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => void handleCopyArticleLink(article)}
                      className="w-9 h-9 rounded-xl bg-[#120520] hover:bg-[#1F0937] border border-[#3B1245] text-[#D8B4FE] hover:text-white flex items-center justify-center cursor-pointer transition-all active:scale-95"
                      title="Copy Market Article Link"
                      aria-label="Copy Market Article Link"
                    >
                      {copiedArticleId === article.id ? (
                        <Check className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={() => handleToggleSave(article)}
                      className={`w-9 h-9 rounded-xl border flex items-center justify-center cursor-pointer transition-all active:scale-90 ${
                        isSaved
                          ? 'bg-purple-600 border-pink-300 text-white shadow-[0_0_14px_rgba(168,85,247,0.5)]'
                          : 'bg-[#120520] hover:bg-purple-950/60 border-[#3B1245] text-white'
                      }`}
                      aria-label={
                        isSaved
                          ? 'Remove from Saved Market News'
                          : 'Save Market Post'
                      }
                      title={isSaved ? 'Saved' : 'Save Market Post'}
                    >
                      <Bookmark
                        className={`w-4 h-4 ${isSaved ? 'fill-current' : ''}`}
                      />
                    </button>
                  </div>
                </div>

                {/* POST BODY: Headline, Hindi Summary, English Option, Educational Takeaway & Read Full News Button */}
                <div className="px-4 pb-4 space-y-2.5">
                  <a
                    href={article.articleUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block group"
                  >
                    <h2 className="text-sm sm:text-base font-bold text-white group-hover:text-pink-300 transition-colors leading-snug">
                      {primaryTitle}
                    </h2>
                    {languageMode === 'both' &&
                      article.hindiHeadline !== article.headline && (
                        <p className="text-xs font-medium text-[#D8B4FE] mt-1">
                          {article.headline}
                        </p>
                      )}
                  </a>

                  {/* Hindi Market Summary Card (Always shown in 'hi' and 'both' modes, or toggleable in 'en' mode) */}
                  {(languageMode === 'hi' || languageMode === 'both') && (
                    <div className="p-3 rounded-2xl bg-[#110420] border border-pink-500/30 space-y-1.5">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-pink-300">
                          🇮🇳 हिंदी मार्केट सारांश (Hindi Summary)
                        </span>

                        {article.language === 'en' &&
                          !translatedHindiById[article.id] && (
                            <button
                              type="button"
                              disabled={translatingById[article.id]}
                              onClick={() => void handleTranslateToHindi(article)}
                              className="px-2 py-0.5 rounded-lg bg-pink-950/90 hover:bg-pink-800 border border-pink-500/40 text-[10px] font-semibold text-pink-100 inline-flex items-center gap-1 cursor-pointer disabled:opacity-50"
                            >
                              {translatingById[article.id] ? (
                                <Loader2 className="w-3 h-3 animate-spin" />
                              ) : (
                                <Languages className="w-3 h-3 text-pink-300" />
                              )}
                              <span>
                                {translatingById[article.id]
                                  ? 'अनुवाद हो रहा है...'
                                  : 'पूरा हिंदी अनुवाद करें'}
                              </span>
                            </button>
                          )}
                      </div>

                      <p className="text-xs sm:text-[13px] text-[#F5D0FE] leading-relaxed">
                        {displayedHindiSummary}
                      </p>
                    </div>
                  )}

                  {/* English Summary (Shown in 'en' and 'both' modes) */}
                  {(languageMode === 'en' || languageMode === 'both') && (
                    <div className="p-3 rounded-2xl bg-[#0E031A] border border-purple-500/30 space-y-1">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-purple-300">
                          🇬🇧 English Market Summary
                        </span>
                        {languageMode === 'en' && (
                          <button
                            type="button"
                            onClick={() => setLanguageMode('hi')}
                            className="text-[10px] text-pink-300 hover:underline cursor-pointer"
                          >
                            हिंदी में देखें
                          </button>
                        )}
                      </div>
                      <p className="text-xs sm:text-[13px] text-[#E9D5FF] leading-relaxed">
                        {article.englishSummary}
                      </p>
                    </div>
                  )}

                  {/* Educational Note */}
                  <p className="text-[11px] text-[#C4B5FD] leading-relaxed">
                    {languageMode === 'en'
                      ? article.educationalTakeawayEnglish
                      : article.educationalTakeawayHindi}
                  </p>

                  {/* Footer Metadata & Read Full News Button */}
                  <div className="pt-1 flex flex-wrap items-center justify-between gap-2">
                    <div className="text-[11px] text-[#A78BFA] flex flex-wrap items-center gap-1.5">
                      <span className="text-white font-medium">
                        Published: {article.publishedAtText}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{article.relativeTimeText}</span>
                      <span aria-hidden="true">·</span>
                      <span className="text-pink-300 font-medium">
                        {article.sourceName}
                      </span>
                    </div>

                    <a
                      href={article.articleUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="min-h-[38px] px-4 py-2 rounded-xl bg-gradient-to-r from-[#7E22CE] to-[#EC4899] text-white text-xs font-semibold inline-flex items-center gap-1.5 shadow-[0_0_16px_rgba(236,72,153,0.35)] hover:brightness-110 active:scale-95 transition-all"
                    >
                      <span>
                        {languageMode === 'en'
                          ? 'Read Full News'
                          : 'पूरी ख़बर पढ़ें (Read Full News)'}
                      </span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </div>
              </article>
            );
          })}

          {/* PAGINATION / INFINITE SCROLL */}
          {activeCategory !== 'saved' && (
            <div
              ref={loadMoreTriggerRef}
              className="py-4 flex flex-col items-center justify-center gap-2"
            >
              {hasMore ? (
                <button
                  type="button"
                  disabled={isLoadingMore}
                  onClick={() =>
                    void fetchTradingFeed({
                      category: activeCategory,
                      dateMode: dateFilter,
                      query: appliedSearchQuery,
                      offset: articles.length,
                      append: true,
                    })
                  }
                  className="min-h-[42px] px-5 py-2.5 rounded-2xl bg-[#140626] hover:bg-[#210A3D] border border-pink-500/40 text-xs font-semibold text-pink-200 inline-flex items-center gap-2 cursor-pointer"
                >
                  {isLoadingMore ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin text-pink-400" />
                      <span>Loading more market news...</span>
                    </>
                  ) : (
                    <>
                      <Globe className="w-4 h-4 text-pink-400" />
                      <span>
                        Load More Market News ({articles.length}/{totalAvailable})
                      </span>
                    </>
                  )}
                </button>
              ) : (
                <p className="text-xs text-[#A78BFA]">
                  Showing all {articles.length} verified market dispatches.
                </p>
              )}
            </div>
          )}
        </div>
      )}

      {/* SHARE MARKET NEWS WITH MOON FRIENDS MODAL */}
      {sharingArticle && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Share Market News with MOON Friends"
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4"
        >
          <div className="w-full max-w-md rounded-3xl bg-[#090214] border border-[#4A154B] p-5 shadow-[0_24px_60px_rgba(0,0,0,0.95)] space-y-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                  <Share2 className="w-4 h-4 text-pink-400" />
                  <span>Share Market News with MOON Friends</span>
                </h3>
                <p className="text-[11px] text-[#C4B5FD] line-clamp-1 mt-0.5">
                  {sharingArticle.sourceName}: {sharingArticle.headline}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSharingArticle(null)}
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center cursor-pointer"
                aria-label="Close share modal"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {shareError && (
              <div className="p-2.5 rounded-xl bg-pink-950/90 border border-pink-500/40 text-xs text-pink-200">
                {shareError}
              </div>
            )}

            <div className="space-y-2 max-h-64 overflow-y-auto">
              {friends.length === 0 ? (
                <p className="text-xs text-[#A78BFA] py-4 text-center">
                  No accepted MOON friends yet. Add a friend using their MOON
                  Friend Code to share market news directly in chat.
                </p>
              ) : (
                friends.map((friend) => {
                  const isSent = sharedSuccessFriendId === friend.id;
                  const isSending = sharingFriendId === friend.id;
                  return (
                    <div
                      key={friend.id}
                      className="flex items-center justify-between gap-3 p-2.5 rounded-2xl bg-[#120520] border border-[#3B1245]"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <LunarAvatar
                          name={friend.displayName}
                          hue={friend.avatarHue}
                          size="sm"
                          presence={friend.presence}
                        />
                        <div className="min-w-0">
                          <p className="text-xs font-semibold text-white truncate">
                            {friend.displayName}
                          </p>
                          <p className="text-[10px] font-mono text-[#C4B5FD] truncate">
                            @{friend.username}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          disabled={isSending}
                          onClick={() =>
                            void handleShareToFriend(friend, sharingArticle)
                          }
                          className={`px-3 py-1.5 rounded-xl text-xs font-semibold inline-flex items-center gap-1 cursor-pointer ${
                            isSent
                              ? 'bg-emerald-600 text-white'
                              : 'bg-gradient-to-r from-[#7E22CE] to-[#EC4899] text-white'
                          }`}
                        >
                          {isSending ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          ) : isSent ? (
                            <>
                              <Check className="w-3.5 h-3.5" />
                              <span>Sent</span>
                            </>
                          ) : (
                            <>
                              <Send className="w-3.5 h-3.5" />
                              <span>Send</span>
                            </>
                          )}
                        </button>

                        {isSent && (
                          <button
                            type="button"
                            onClick={() => {
                              setSharingArticle(null);
                              onOpenChatWithFriend(friend.id);
                            }}
                            className="px-2.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-[11px] text-white cursor-pointer"
                          >
                            Open Chat
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            <div className="pt-2 border-t border-[#3B1245] flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => void handleCopyArticleLink(sharingArticle)}
                className="flex-1 h-10 rounded-xl bg-[#16072B] hover:bg-[#230B42] border border-[#4A154B] text-xs font-semibold text-pink-200 inline-flex items-center justify-center gap-1.5 cursor-pointer"
              >
                {copiedArticleId === sharingArticle.id ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-300">Link Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-pink-400" />
                    <span>Copy Article Link</span>
                  </>
                )}
              </button>

              <a
                href={sharingArticle.articleUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="h-10 px-4 rounded-xl bg-gradient-to-r from-[#7E22CE] to-[#EC4899] text-white text-xs font-semibold inline-flex items-center gap-1.5"
              >
                <span>Open Source</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
