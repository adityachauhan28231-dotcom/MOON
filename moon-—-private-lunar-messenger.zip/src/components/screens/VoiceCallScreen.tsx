import React, { useCallback, useEffect, useState } from 'react';
import {
  LiveKitRoom,
  RoomAudioRenderer,
  useConnectionState,
  useLocalParticipant,
  useRemoteParticipants,
  useRoomContext,
} from '@livekit/components-react';
import { ConnectionState, Room } from 'livekit-client';
import {
  AlertTriangle,
  ArrowLeft,
  CheckCircle2,
  Loader2,
  Mic,
  MicOff,
  Phone,
  PhoneCall,
  PhoneIncoming,
  PhoneOff,
  RefreshCw,
  ShieldCheck,
  Sliders,
  Volume2,
  VolumeX,
} from 'lucide-react';
import {
  FriendContact,
  LiveKitServerStatus,
  LiveKitTokenResponse,
  UserProfile,
  VoiceCallSignalPayload,
  VoiceCallStatus,
} from '../../types/moon';
import {
  fetchLiveKitServerStatus,
  requestLiveKitCallToken,
} from '../../services/livekitCallService';
import { ErrorBanner, LunarAvatar, MoonButton } from '../ui/ReusablePrimitives';

interface VoiceCallScreenProps {
  currentUser: UserProfile;
  friend: FriendContact | null;
  callStatus: VoiceCallStatus;
  activeCallId: string | null;
  incomingSignal: VoiceCallSignalPayload | null;
  liveKitTokenData: LiveKitTokenResponse | null;
  callError: string | null;
  onStartOutgoingCall: (friend: FriendContact) => Promise<void>;
  onAcceptIncomingCall: (signal: VoiceCallSignalPayload) => Promise<void>;
  onRejectIncomingCall: (signal: VoiceCallSignalPayload) => Promise<void>;
  onEndCall: (reason?: string) => Promise<void>;
  onClearCallError: () => void;
  onReturnToChat: () => void;
}

interface ActiveLiveKitSessionViewProps {
  currentUser: UserProfile;
  friend: FriendContact;
  callStatus: VoiceCallStatus;
  roomName: string;
  onEndCall: (reason?: string) => Promise<void>;
}

const ActiveLiveKitSessionView: React.FC<ActiveLiveKitSessionViewProps> = ({
  currentUser,
  friend,
  callStatus,
  roomName,
  onEndCall,
}) => {
  const room = useRoomContext();
  const connectionState = useConnectionState();
  const { localParticipant, isMicrophoneEnabled } = useLocalParticipant();
  const remoteParticipants = useRemoteParticipants();

  const [isSpeakerOn, setIsSpeakerOn] = useState<boolean>(true);
  const [showAudioPanel, setShowAudioPanel] = useState<boolean>(false);
  const [audioOutputDevices, setAudioOutputDevices] = useState<
    MediaDeviceInfo[]
  >([]);
  const [selectedOutputDeviceId, setSelectedOutputDeviceId] =
    useState<string>('default');
  const [deviceError, setDeviceError] = useState<string | null>(null);
  const [elapsedSeconds, setElapsedSeconds] = useState<number>(0);

  const remoteFriendParticipant = remoteParticipants.find(
    (p) => p.identity === friend.id
  ) || remoteParticipants[0];

  const isPeerInRoom = Boolean(remoteFriendParticipant);

  // Elapsed timer when connected with peer
  useEffect(() => {
    if (connectionState !== ConnectionState.Connected || !isPeerInRoom) {
      return;
    }
    const timer = window.setInterval(() => {
      setElapsedSeconds((prev) => prev + 1);
    }, 1000);
    return () => window.clearInterval(timer);
  }, [connectionState, isPeerInRoom]);

  // Load available audio output devices
  useEffect(() => {
    let mounted = true;
    async function loadDevices() {
      try {
        const devices = await Room.getLocalDevices('audiooutput', false);
        if (mounted) {
          setAudioOutputDevices(devices);
        }
      } catch {
        // Browsers on some mobile devices do not enumerate audiooutput devices
      }
    }
    loadDevices();
    return () => {
      mounted = false;
    };
  }, []);

  const handleToggleMute = async () => {
    setDeviceError(null);
    try {
      await localParticipant.setMicrophoneEnabled(!isMicrophoneEnabled);
    } catch (err) {
      setDeviceError(
        err instanceof Error
          ? `Microphone error: ${err.message}`
          : 'Could not toggle microphone. Ensure microphone permissions are granted.'
      );
    }
  };

  const handleToggleSpeaker = async () => {
    setDeviceError(null);
    const nextSpeakerState = !isSpeakerOn;
    setIsSpeakerOn(nextSpeakerState);

    try {
      await room.startAudio();
      if (audioOutputDevices.length > 1) {
        const targetDevice = nextSpeakerState
          ? audioOutputDevices.find((d) =>
              /speaker/i.test(d.label)
            ) || audioOutputDevices[0]
          : audioOutputDevices.find((d) =>
              /earpiece|communications|default/i.test(d.label)
            ) || audioOutputDevices[0];

        if (targetDevice?.deviceId) {
          await room.switchActiveDevice('audiooutput', targetDevice.deviceId);
          setSelectedOutputDeviceId(targetDevice.deviceId);
        }
      }
    } catch (err) {
      setDeviceError(
        err instanceof Error
          ? `Audio output routing notice: ${err.message}`
          : 'Could not switch hardware output device.'
      );
    }
  };

  const handleSelectOutputDevice = async (deviceId: string) => {
    setDeviceError(null);
    try {
      await room.switchActiveDevice('audiooutput', deviceId);
      setSelectedOutputDeviceId(deviceId);
    } catch (err) {
      setDeviceError(
        err instanceof Error
          ? `Failed to switch output device: ${err.message}`
          : 'Failed to switch output device.'
      );
    }
  };

  const formatDuration = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60)
      .toString()
      .padStart(2, '0');
    const secs = (totalSeconds % 60).toString().padStart(2, '0');
    return `${mins}:${secs}`;
  };

  const statusHeadline =
    connectionState === ConnectionState.Connecting ||
    connectionState === ConnectionState.Reconnecting
      ? 'Connecting to LiveKit Encrypted Room...'
      : isPeerInRoom
      ? `In Voice Call · ${formatDuration(elapsedSeconds)}`
      : callStatus === 'calling'
      ? 'Ringing Friend · Waiting for Answer...'
      : 'Connected to Room · Waiting for Friend Audio...';

  return (
    <div className="flex-1 flex flex-col justify-between">
      {/* LiveKit Audio Renderer for remote tracks */}
      <RoomAudioRenderer volume={isSpeakerOn ? 1.0 : 0.6} />

      {/* Center Stage: Peer & Local Participant Cards */}
      <div className="relative z-10 my-auto py-6 flex flex-col items-center text-center space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full max-w-lg">
          {/* Friend Participant Card */}
          <div
            className={`rounded-2xl p-5 border transition-all flex flex-col items-center space-y-3 ${
              remoteFriendParticipant?.isSpeaking
                ? 'bg-[#1A0926]/95 border-rose-400 shadow-[0_0_32px_rgba(225,29,72,0.38)]'
                : 'bg-[#090410]/90 border-[#351635]'
            }`}
          >
            <div className="relative">
              <LunarAvatar
                name={friend.displayName}
                hue={friend.avatarHue}
                size="lg"
              />
              {remoteFriendParticipant?.isSpeaking && (
                <span className="absolute -bottom-1 -right-1 px-1.5 py-0.5 rounded bg-gradient-to-r from-[#6D28D9] to-[#BE123C] text-[10px] font-semibold text-white shadow-[0_0_12px_rgba(225,29,72,0.6)]">
                  Speaking
                </span>
              )}
            </div>
            <div>
              <p className="text-sm font-semibold text-white">
                {friend.displayName}
              </p>
              <p className="text-xs text-[#CBD5E1]">@{friend.username}</p>
            </div>
            <p className="text-[11px] font-mono text-rose-300">
              {isPeerInRoom
                ? remoteFriendParticipant?.isMicrophoneEnabled
                  ? 'Mic Active'
                  : 'Muted'
                : 'Ringing...'}
            </p>
          </div>

          {/* Current User Participant Card */}
          <div
            className={`rounded-2xl p-5 border transition-all flex flex-col items-center space-y-3 ${
              localParticipant.isSpeaking
                ? 'bg-[#1A0926]/95 border-rose-400 shadow-[0_0_32px_rgba(225,29,72,0.38)]'
                : 'bg-[#090410]/90 border-[#351635]'
            }`}
          >
            <div className="relative">
              <LunarAvatar
                name={currentUser.displayName}
                hue={currentUser.avatarHue}
                size="lg"
              />
              {localParticipant.isSpeaking && (
                <span className="absolute -bottom-1 -right-1 px-1.5 py-0.5 rounded bg-gradient-to-r from-[#6D28D9] to-[#BE123C] text-[10px] font-semibold text-white shadow-[0_0_12px_rgba(225,29,72,0.6)]">
                  Speaking
                </span>
              )}
            </div>
            <div>
              <p className="text-sm font-semibold text-white">
                {currentUser.displayName} (You)
              </p>
              <p className="text-xs text-[#CBD5E1]">@{currentUser.username}</p>
            </div>
            <p className="text-[11px] font-mono text-rose-300">
              {isMicrophoneEnabled ? 'Mic Unmuted' : 'Mic Muted'}
            </p>
          </div>
        </div>

        <div className="space-y-1 max-w-md">
          <p className="text-sm font-semibold text-rose-200">
            {statusHeadline}
          </p>
          <p className="text-xs text-[#A39BB5] font-mono">
            Room: {roomName} · LiveKit State: {connectionState}
          </p>
        </div>

        {deviceError && (
          <div className="w-full max-w-md text-left">
            <ErrorBanner
              title="Audio Device Notice"
              message={deviceError}
              onDismiss={() => setDeviceError(null)}
            />
          </div>
        )}

        {showAudioPanel && (
          <div className="w-full max-w-md rounded-2xl bg-[#090410]/95 border border-[#351635] p-4 text-left space-y-3">
            <p className="text-xs font-semibold text-white">
              LiveKit Audio Routing &amp; Output Selection
            </p>
            <div className="text-xs text-[#CBD5E1] space-y-1.5">
              <p>
                Local Microphone:{' '}
                <span className="text-rose-300 font-mono">
                  {isMicrophoneEnabled ? 'Enabled (Publishing)' : 'Muted'}
                </span>
              </p>
              <p>
                Speaker Output Mode:{' '}
                <span className="text-rose-300 font-mono">
                  {isSpeakerOn ? 'Speakerphone (100%)' : 'Earpiece / Low (60%)'}
                </span>
              </p>
            </div>

            {audioOutputDevices.length > 0 && (
              <div className="space-y-1.5 pt-1">
                <label className="block text-[11px] text-[#CBD5E1]">
                  Hardware Output Device:
                </label>
                <select
                  value={selectedOutputDeviceId}
                  onChange={(e) => handleSelectOutputDevice(e.target.value)}
                  className="w-full min-h-[40px] px-3 rounded-xl bg-[#040208] border border-[#351635] text-xs text-white"
                >
                  {audioOutputDevices.map((dev) => (
                    <option key={dev.deviceId} value={dev.deviceId}>
                      {dev.label || `Audio Output (${dev.deviceId.slice(0, 6)})`}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Bottom Thumb-Zone Call Controls: Mute, Speaker, Audio Details, End Call */}
      <div className="relative z-10 pt-4 border-t border-[#2D142C] flex flex-col items-center gap-4">
        <div className="flex flex-wrap items-center justify-center gap-3 sm:gap-5">
          <button
            type="button"
            onClick={handleToggleMute}
            aria-pressed={!isMicrophoneEnabled}
            className={`min-h-[54px] min-w-[68px] px-4 rounded-2xl border flex flex-col items-center justify-center gap-1 transition-all cursor-pointer ${
              !isMicrophoneEnabled
                ? 'bg-gradient-to-r from-[#6D28D9] to-[#9F1239] border-rose-400/50 text-white shadow-[0_0_18px_rgba(225,29,72,0.35)]'
                : 'bg-[#12081C] hover:bg-[#1D0E2E] border-[#351635] text-[#F8FAFC]'
            }`}
          >
            {!isMicrophoneEnabled ? (
              <MicOff className="w-5 h-5" />
            ) : (
              <Mic className="w-5 h-5" />
            )}
            <span className="text-[11px] font-medium">
              {!isMicrophoneEnabled ? 'Unmute' : 'Mute'}
            </span>
          </button>

          <button
            type="button"
            onClick={handleToggleSpeaker}
            aria-pressed={isSpeakerOn}
            className={`min-h-[54px] min-w-[68px] px-4 rounded-2xl border flex flex-col items-center justify-center gap-1 transition-all cursor-pointer ${
              isSpeakerOn
                ? 'bg-gradient-to-r from-[#6D28D9] to-[#9F1239] border-rose-400/50 text-white shadow-[0_0_18px_rgba(225,29,72,0.35)]'
                : 'bg-[#12081C] hover:bg-[#1D0E2E] border-[#351635] text-[#F8FAFC]'
            }`}
          >
            {isSpeakerOn ? (
              <Volume2 className="w-5 h-5" />
            ) : (
              <VolumeX className="w-5 h-5" />
            )}
            <span className="text-[11px] font-medium">
              {isSpeakerOn ? 'Speaker On' : 'Speaker Off'}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setShowAudioPanel((prev) => !prev)}
            aria-pressed={showAudioPanel}
            className={`min-h-[54px] min-w-[68px] px-4 rounded-2xl border flex flex-col items-center justify-center gap-1 transition-all cursor-pointer ${
              showAudioPanel
                ? 'bg-[#241038] border-rose-400/50 text-rose-200'
                : 'bg-[#12081C] hover:bg-[#1D0E2E] border-[#351635] text-[#F8FAFC]'
            }`}
          >
            <Sliders className="w-5 h-5" />
            <span className="text-[11px] font-medium">Audio</span>
          </button>

          <MoonButton
            type="button"
            variant="danger"
            onClick={() => onEndCall('ended_by_user')}
            className="min-h-[54px] px-6 rounded-2xl"
            leftIcon={<PhoneOff className="w-5 h-5" />}
          >
            End Call
          </MoonButton>
        </div>
      </div>
    </div>
  );
};

export const VoiceCallScreen: React.FC<VoiceCallScreenProps> = ({
  currentUser,
  friend,
  callStatus,
  incomingSignal,
  liveKitTokenData,
  callError,
  onStartOutgoingCall,
  onAcceptIncomingCall,
  onRejectIncomingCall,
  onEndCall,
  onClearCallError,
  onReturnToChat,
}) => {
  const [serverStatus, setServerStatus] =
    useState<LiveKitServerStatus | null>(null);
  const [isCheckingServer, setIsCheckingServer] = useState<boolean>(false);
  const [serverCheckError, setServerCheckError] = useState<string | null>(null);

  const [isVerifyingToken, setIsVerifyingToken] = useState<boolean>(false);
  const [tokenVerifyMessage, setTokenVerifyMessage] = useState<string | null>(
    null
  );

  const checkLiveKitBackend = useCallback(async () => {
    setIsCheckingServer(true);
    setServerCheckError(null);
    try {
      const status = await fetchLiveKitServerStatus();
      setServerStatus(status);
    } catch (err) {
      setServerCheckError(
        err instanceof Error
          ? err.message
          : 'Failed to check /api/livekit/status.'
      );
    } finally {
      setIsCheckingServer(false);
    }
  }, []);

  useEffect(() => {
    checkLiveKitBackend();
  }, [checkLiveKitBackend]);

  const handleVerifyFriendToken = async () => {
    if (!friend) return;
    setIsVerifyingToken(true);
    setTokenVerifyMessage(null);
    setServerCheckError(null);
    onClearCallError();
    try {
      const res = await requestLiveKitCallToken(friend.id);
      await checkLiveKitBackend();
      setTokenVerifyMessage(
        `Verified! Server authenticated @${currentUser.username}, confirmed friendship with @${friend.username} in public.friendships, and validated the ${res.expiresInSeconds}s token against LiveKit Cloud (${res.wsUrl.replace(/^wss?:\/\//, '')}) for room "${res.roomName}".`
      );
    } catch (err) {
      await checkLiveKitBackend();
      setServerCheckError(
        err instanceof Error ? err.message : 'Token verification failed.'
      );
    } finally {
      setIsVerifyingToken(false);
    }
  };

  const displayTarget = friend || {
    id: '',
    username: 'select_friend',
    displayName: 'No Accepted Friend Selected',
    friendCode: 'MOON-XXXX-XX',
    presence: 'offline' as const,
    lastSeenText: '',
    bio: '',
    avatarHue: 268,
    unreadCount: 0,
  };

  const isLiveRoomActive =
    Boolean(friend && liveKitTokenData?.token && liveKitTokenData?.wsUrl) &&
    (callStatus === 'calling' ||
      callStatus === 'connecting' ||
      callStatus === 'connected');

  return (
    <div className="min-h-[560px] lg:h-[calc(100vh-5.5rem)] rounded-3xl bg-black/50 border border-rose-500/30 p-5 sm:p-7 flex flex-col justify-between relative overflow-hidden shadow-[0_24px_65px_rgba(0,0,0,0.88),0_0_36px_rgba(153,27,27,0.18)]">
      {/* Subtle deep crimson-purple ambient backdrop */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_28%,rgba(190,18,60,0.14),rgba(109,40,217,0.1)_45%,transparent_70%)]"
      />

      {/* Top Row: Back to Chat + Server Status Check */}
      <div className="relative z-10 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={onReturnToChat}
            className="min-h-[44px] px-3.5 rounded-xl bg-[#12081C] hover:bg-[#1D0E2E] border border-[#351635] text-xs font-medium text-[#F8FAFC] inline-flex items-center gap-2 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4 text-rose-300" />
            <span>Back to Private Chat</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={checkLiveKitBackend}
              disabled={isCheckingServer}
              className="min-h-[38px] px-3 rounded-xl bg-[#12081C] hover:bg-[#1D0E2E] border border-[#351635] text-xs text-rose-200 inline-flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <RefreshCw
                className={`w-3.5 h-3.5 ${
                  isCheckingServer ? 'animate-spin' : ''
                }`}
              />
              <span>Check LiveKit Server</span>
            </button>

            {friend && (
              <button
                type="button"
                onClick={handleVerifyFriendToken}
                disabled={isVerifyingToken}
                className="min-h-[38px] px-3 rounded-xl bg-[#1A0B28] hover:bg-[#27113B] border border-rose-500/35 text-xs font-medium text-rose-200 inline-flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                {isVerifyingToken ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <ShieldCheck className="w-3.5 h-3.5 text-rose-300" />
                )}
                <span>Test Friend Token</span>
              </button>
            )}
          </div>
        </div>

        {/* Server-Side LiveKit Credentials & Cloud Signature Readiness Banner */}
        {serverStatus && !serverStatus.configured && (
          <div className="rounded-2xl bg-[#19121E] border border-amber-500/35 px-4 py-3 text-xs space-y-1.5">
            <div className="flex items-center gap-2 font-semibold text-amber-200">
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
              <span>
                Action Required: Configure Server-Side LiveKit Secrets
              </span>
            </div>
            <p className="text-[#CBD5E1] leading-relaxed">
              Missing on backend:{' '}
              <code className="font-mono text-amber-300">
                {serverStatus.missingKeys.join(', ')}
              </code>
              . Add <code className="font-mono">LIVEKIT_URL</code>,{' '}
              <code className="font-mono">LIVEKIT_API_KEY</code>, and{' '}
              <code className="font-mono">LIVEKIT_API_SECRET</code> in the AI Studio Secrets / Environment Variables panel. Never prefix <code className="font-mono">LIVEKIT_API_SECRET</code> with <code className="font-mono">VITE_</code>.
            </p>
          </div>
        )}

        {serverStatus &&
          serverStatus.configured &&
          !serverStatus.cloudVerified && (
            <div className="rounded-2xl bg-[#1D121B] border border-amber-500/45 px-4 py-3 text-xs space-y-1.5">
              <div className="flex items-center gap-2 font-semibold text-amber-200">
                <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                <span>
                  LiveKit Secret Diagnostic Notice ({serverStatus.wsHostPreview})
                </span>
              </div>
              <p className="text-[#E5E1F0] leading-relaxed">
                {serverStatus.diagnosticMessage ||
                  'LiveKit Cloud rejected the server-signed token. Verify LIVEKIT_API_KEY and LIVEKIT_API_SECRET in AI Studio Secrets.'}
              </p>
            </div>
          )}

        {serverStatus &&
          serverStatus.configured &&
          serverStatus.cloudVerified && (
            <div className="rounded-2xl bg-[#100619]/90 border border-rose-500/30 px-4 py-2.5 flex flex-wrap items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-2 text-rose-200">
                <CheckCircle2 className="w-4 h-4 text-rose-400 shrink-0" />
                <span>
                  LiveKit Cloud Signal &amp; Secret Verified (
                  <code className="font-mono text-rose-300">
                    {serverStatus.wsHostPreview}
                  </code>
                  ) · Friend-Only Auth Active
                </span>
              </div>
              <span className="text-[11px] text-[#A39BB5]">
                Short-Lived 600s JWT
              </span>
            </div>
          )}

        {tokenVerifyMessage && (
          <div className="rounded-2xl bg-[#160924] border border-rose-500/40 px-4 py-2.5 text-xs text-rose-200 flex items-center justify-between gap-3">
            <span>{tokenVerifyMessage}</span>
            <button
              type="button"
              onClick={() => setTokenVerifyMessage(null)}
              className="text-rose-300 hover:text-white underline text-[11px] shrink-0 cursor-pointer"
            >
              Dismiss
            </button>
          </div>
        )}

        {(callError || serverCheckError) && (
          <ErrorBanner
            title="LiveKit Voice Call Notice"
            message={callError || serverCheckError || ''}
            onDismiss={() => {
              onClearCallError();
              setServerCheckError(null);
            }}
          />
        )}
      </div>

      {/* Main Call Content: Either Active LiveKit Room OR Pre-Call / Incoming / Ended View */}
      {isLiveRoomActive && friend && liveKitTokenData ? (
        <LiveKitRoom
          serverUrl={liveKitTokenData.wsUrl}
          token={liveKitTokenData.token}
          connect={true}
          audio={true}
          video={false}
          onDisconnected={() => {
            onEndCall('room_disconnected');
          }}
          onError={(err) => {
            setServerCheckError(`LiveKit WebRTC Error: ${err.message}`);
          }}
          className="flex-1 flex flex-col justify-between"
        >
          <ActiveLiveKitSessionView
            currentUser={currentUser}
            friend={friend}
            callStatus={callStatus}
            roomName={liveKitTokenData.roomName}
            onEndCall={onEndCall}
          />
        </LiveKitRoom>
      ) : (
        <>
          <div className="relative z-10 my-auto py-8 flex flex-col items-center text-center space-y-5">
            <div className="relative flex items-center justify-center">
              <div
                aria-hidden="true"
                className={`w-36 h-36 rounded-full border flex items-center justify-center bg-[#18071E]/60 ${
                  callStatus === 'incoming' || callStatus === 'calling'
                    ? 'border-rose-400 animate-pulse shadow-[0_0_40px_rgba(225,29,72,0.45)]'
                    : 'border-rose-500/35 shadow-[0_0_28px_rgba(109,40,217,0.25)]'
                }`}
              >
                <LunarAvatar
                  name={displayTarget.displayName}
                  hue={displayTarget.avatarHue}
                  size="xl"
                />
              </div>
            </div>

            <div className="space-y-1.5 max-w-md">
              <h2 className="font-display text-2xl sm:text-3xl font-bold text-white">
                {displayTarget.displayName}
              </h2>
              <p className="text-xs text-[#CBD5E1]">
                <span>@{displayTarget.username}</span>
                <span className="mx-1.5 text-rose-400" aria-hidden="true">
                  ·
                </span>
                <span className="font-mono text-rose-300">
                  {displayTarget.friendCode}
                </span>
              </p>

              <p className="text-sm font-medium text-rose-200 pt-2">
                {!friend
                  ? 'Select an Accepted Friend to Start a Voice Call'
                  : callStatus === 'incoming'
                  ? 'Incoming Friend Voice Call...'
                  : callStatus === 'connecting'
                  ? 'Verifying Friendship & Requesting LiveKit Token...'
                  : callStatus === 'rejected'
                  ? 'Call Declined by Friend'
                  : callStatus === 'ended'
                  ? 'Voice Call Ended'
                  : 'Ready for Private Friend-Only Voice Call'}
              </p>

              <p className="text-xs text-[#A39BB5]">
                {!friend
                  ? 'Only accepted friends in public.friendships (user1, user2) can call each other.'
                  : 'End-to-end authenticated via Supabase JWT + short-lived server-generated LiveKit token.'}
              </p>
            </div>
          </div>

          {/* Bottom Controls for Idle / Incoming / Connecting States */}
          <div className="relative z-10 pt-4 border-t border-[#2D142C] flex flex-col items-center gap-3">
            {callStatus === 'incoming' && incomingSignal ? (
              <div className="flex flex-wrap items-center justify-center gap-4">
                <MoonButton
                  type="button"
                  variant="danger"
                  onClick={() => onRejectIncomingCall(incomingSignal)}
                  className="min-h-[52px] px-6 rounded-2xl"
                  leftIcon={<PhoneOff className="w-5 h-5" />}
                >
                  Decline Call
                </MoonButton>
                <MoonButton
                  type="button"
                  variant="primary"
                  onClick={() => onAcceptIncomingCall(incomingSignal)}
                  className="min-h-[52px] px-6 rounded-2xl"
                  leftIcon={<PhoneIncoming className="w-5 h-5" />}
                >
                  Accept Voice Call
                </MoonButton>
              </div>
            ) : (
              <div className="flex flex-wrap items-center justify-center gap-3">
                {friend && (
                  <MoonButton
                    type="button"
                    variant="primary"
                    size="lg"
                    isLoading={callStatus === 'connecting'}
                    onClick={() => onStartOutgoingCall(friend)}
                    className="min-h-[52px] px-7 rounded-2xl"
                    leftIcon={
                      callStatus === 'connecting' ? undefined : (
                        <PhoneCall className="w-5 h-5" />
                      )
                    }
                  >
                    {callStatus === 'connecting'
                      ? 'Connecting LiveKit...'
                      : `Call ${friend.displayName}`}
                  </MoonButton>
                )}

                <MoonButton
                  type="button"
                  variant="secondary"
                  onClick={onReturnToChat}
                  className="min-h-[52px] px-5 rounded-2xl"
                  leftIcon={<Phone className="w-4 h-4 text-rose-300" />}
                >
                  Return to Chat
                </MoonButton>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
};
