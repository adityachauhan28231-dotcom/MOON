import React, { useState } from 'react';
import { Check, Clock, RefreshCw, UserPlus, X } from 'lucide-react';
import { FriendRequest } from '../../types/moon';
import {
  ErrorBanner,
  LoadingListSkeleton,
  LunarAvatar,
  MoonButton,
} from '../ui/ReusablePrimitives';

interface FriendRequestsScreenProps {
  requests: FriendRequest[];
  isLoading: boolean;
  errorMessage: string | null;
  onRefreshRequests: () => Promise<void>;
  onRespondToRequest: (
    request: FriendRequest,
    action: 'accept' | 'reject'
  ) => Promise<void>;
  onNavigateAddFriend: () => void;
}

export const FriendRequestsScreen: React.FC<FriendRequestsScreenProps> = ({
  requests,
  isLoading,
  errorMessage,
  onRefreshRequests,
  onRespondToRequest,
  onNavigateAddFriend,
}) => {
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [processingAction, setProcessingAction] = useState<
    'accept' | 'reject' | null
  >(null);
  const [actionError, setActionError] = useState<string | null>(null);
  const [tab, setTab] = useState<'incoming' | 'outgoing'>('incoming');

  const incomingRequests = requests.filter(
    (r) => r.direction === 'incoming' && r.status === 'pending'
  );
  const outgoingRequests = requests.filter(
    (r) => r.direction === 'outgoing' && r.status === 'pending'
  );

  const handleAction = async (
    request: FriendRequest,
    action: 'accept' | 'reject'
  ) => {
    setActionError(null);
    setProcessingId(request.id);
    setProcessingAction(action);
    try {
      await onRespondToRequest(request, action);
    } catch (err) {
      setActionError(
        err instanceof Error
          ? err.message
          : 'Failed to update friend request.'
      );
    } finally {
      setProcessingId(null);
      setProcessingAction(null);
    }
  };

  return (
    <div className="space-y-5 pb-8">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-xl sm:text-2xl font-bold text-white drop-shadow-[0_2px_10px_rgba(0,0,0,0.85)]">
            Friend Requests
          </h2>
          <p className="text-xs text-[#CBD5E1] mt-0.5">
            <span>{incomingRequests.length} incoming</span>
            <span className="mx-1.5 text-rose-400" aria-hidden="true">
              ·
            </span>
            <span>{outgoingRequests.length} outgoing</span>
            <span className="mx-1.5 text-rose-400" aria-hidden="true">
              ·
            </span>
            <span>Synced with public.friend_requests</span>
          </p>
        </div>

        <div className="flex items-center gap-2">
          <MoonButton
            type="button"
            variant="secondary"
            isLoading={isLoading}
            onClick={onRefreshRequests}
            leftIcon={<RefreshCw className="w-4 h-4 text-rose-300" />}
          >
            Sync
          </MoonButton>
          <MoonButton
            type="button"
            variant="secondary"
            onClick={onNavigateAddFriend}
            leftIcon={<UserPlus className="w-4 h-4 text-rose-300" />}
          >
            Add by Code
          </MoonButton>
        </div>
      </div>

      {/* Interactive Segmented Tab Control */}
      <div className="flex items-center gap-1 p-1 rounded-xl bg-[#07030C]/90 backdrop-blur-md border border-[#2D142C] w-fit">
        <button
          type="button"
          onClick={() => setTab('incoming')}
          className={`min-h-[40px] px-4 py-1.5 text-xs font-medium rounded-lg transition-all whitespace-nowrap shrink-0 cursor-pointer ${
            tab === 'incoming'
              ? 'bg-gradient-to-r from-[#6D28D9] to-[#9F1239] text-white shadow-[0_0_14px_rgba(225,29,72,0.3)]'
              : 'text-[#A39BB5] hover:text-white'
          }`}
        >
          Incoming ({incomingRequests.length})
        </button>
        <button
          type="button"
          onClick={() => setTab('outgoing')}
          className={`min-h-[40px] px-4 py-1.5 text-xs font-medium rounded-lg transition-all whitespace-nowrap shrink-0 cursor-pointer ${
            tab === 'outgoing'
              ? 'bg-gradient-to-r from-[#6D28D9] to-[#9F1239] text-white shadow-[0_0_14px_rgba(225,29,72,0.3)]'
              : 'text-[#A39BB5] hover:text-white'
          }`}
        >
          Outgoing ({outgoingRequests.length})
        </button>
      </div>

      {(errorMessage || actionError) && (
        <ErrorBanner
          title="Friend Requests Error"
          message={actionError || errorMessage || ''}
          onRetry={onRefreshRequests}
          onDismiss={() => setActionError(null)}
        />
      )}

      {isLoading ? (
        <LoadingListSkeleton
          rows={2}
          label="Loading public.friend_requests..."
        />
      ) : tab === 'incoming' ? (
        incomingRequests.length === 0 ? (
          <div className="rounded-3xl bg-black/55 border border-rose-500/30 p-8 text-center space-y-2 shadow-[0_18px_45px_rgba(0,0,0,0.85)]">
            <p className="font-display text-base font-semibold text-white">
              No pending incoming requests
            </p>
            <p className="text-xs text-[#E2E8F0] max-w-xs mx-auto">
              Share your unique friend code from your Profile so friends can connect with you.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {incomingRequests.map((req) => {
              const isBusy = processingId === req.id;

              return (
                <div
                  key={req.id}
                  className="rounded-3xl bg-black/60 border border-rose-500/30 p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-[0_18px_45px_rgba(0,0,0,0.85)]"
                >
                  <div className="flex items-start gap-3.5 min-w-0">
                    <LunarAvatar
                      name={req.fromUser.displayName}
                      hue={req.fromUser.avatarHue}
                      size="md"
                    />
                    <div className="min-w-0 space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <h3 className="font-display text-base font-semibold text-white">
                          {req.fromUser.displayName}
                        </h3>
                        <span className="text-xs text-[#CBD5E1]">
                          @{req.fromUser.username}
                        </span>
                        <span
                          className="text-xs text-rose-400"
                          aria-hidden="true"
                        >
                          ·
                        </span>
                        <span className="text-xs font-mono text-rose-300">
                          {req.fromUser.friendCode}
                        </span>
                      </div>

                      {req.note && (
                        <p className="text-xs text-[#E2E8F0] leading-relaxed">
                          “{req.note}”
                        </p>
                      )}

                      <p className="text-xs text-[#CBD5E1]">
                        <span>{req.fromUser.bio}</span>
                        <span className="mx-1.5" aria-hidden="true">
                          ·
                        </span>
                        <span>Received {req.createdAtText}</span>
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2.5 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-[#2D142C]">
                    <MoonButton
                      type="button"
                      variant="primary"
                      isLoading={isBusy && processingAction === 'accept'}
                      disabled={isBusy}
                      onClick={() => handleAction(req, 'accept')}
                      leftIcon={<Check className="w-4 h-4" />}
                    >
                      Accept
                    </MoonButton>
                    <MoonButton
                      type="button"
                      variant="secondary"
                      isLoading={isBusy && processingAction === 'reject'}
                      disabled={isBusy}
                      onClick={() => handleAction(req, 'reject')}
                      leftIcon={<X className="w-4 h-4 text-rose-300" />}
                    >
                      Decline
                    </MoonButton>
                  </div>
                </div>
              );
            })}
          </div>
        )
      ) : outgoingRequests.length === 0 ? (
        <div className="rounded-3xl bg-black/55 border border-rose-500/30 p-8 text-center space-y-3 shadow-[0_18px_45px_rgba(0,0,0,0.85)]">
          <p className="font-display text-base font-semibold text-white">
            No outgoing friend requests
          </p>
          <p className="text-xs text-[#E2E8F0] max-w-xs mx-auto">
            Enter a friend’s MOON-XXXX-XX code to send a connection request.
          </p>
          <div className="pt-1">
            <MoonButton
              type="button"
              variant="secondary"
              onClick={onNavigateAddFriend}
              leftIcon={<UserPlus className="w-4 h-4 text-rose-300" />}
            >
              Add Friend by Code
            </MoonButton>
          </div>
        </div>
      ) : (
        <div className="space-y-3">
          {outgoingRequests.map((req) => {
            const isBusy = processingId === req.id;

            return (
              <div
                key={req.id}
                className="rounded-3xl bg-black/60 border border-rose-500/30 p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-[0_18px_45px_rgba(0,0,0,0.85)]"
              >
                <div className="flex items-start gap-3.5 min-w-0">
                  <LunarAvatar
                    name={req.fromUser.displayName}
                    hue={req.fromUser.avatarHue}
                    size="md"
                  />
                  <div className="min-w-0 space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="font-display text-base font-semibold text-white">
                        {req.fromUser.displayName}
                      </h3>
                      <span className="text-xs text-[#CBD5E1]">
                        @{req.fromUser.username}
                      </span>
                      <span
                        className="text-xs text-rose-400"
                        aria-hidden="true"
                      >
                        ·
                      </span>
                      <span className="text-xs font-mono text-rose-300">
                        {req.fromUser.friendCode}
                      </span>
                    </div>
                    <p className="text-xs text-[#CBD5E1] flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-rose-300" />
                      <span>Awaiting response · Sent {req.createdAtText}</span>
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <MoonButton
                    type="button"
                    variant="secondary"
                    isLoading={isBusy}
                    onClick={() => handleAction(req, 'reject')}
                    leftIcon={<X className="w-4 h-4 text-rose-300" />}
                  >
                    Cancel Request
                  </MoonButton>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
