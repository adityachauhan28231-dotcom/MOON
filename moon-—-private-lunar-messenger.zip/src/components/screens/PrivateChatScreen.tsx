import React, { useEffect, useRef, useState } from 'react';
import {
  AlertCircle,
  ArrowLeft,
  Check,
  CheckCheck,
  Copy,
  Film,
  Image as ImageIcon,
  ImagePlus,
  Loader2,
  Lock,
  MapPin,
  Maximize2,
  Pause,
  Phone,
  Play,
  RefreshCw,
  Send,
  ShieldCheck,
  UserPlus,
  X,
} from 'lucide-react';
import {
  ChatLocationAttachment,
  ChatMediaAttachment,
  ChatMediaKind,
  ChatMessage,
  FriendContact,
  UserProfile,
} from '../../types/moon';
import {
  formatFileSize,
  PREPARED_CHAT_MEDIA_STORAGE_SQL,
  resolveChatMediaSignedUrl,
  validateChatMediaFile,
} from '../../services/supabaseAdapter';
import {
  LunarLocationChatCard,
  LunarLocationPickerModal,
  LunarLocationViewerModal,
} from '../ui/LunarLocationShared';
import {
  ErrorBanner,
  LunarAvatar,
  MoonButton,
} from '../ui/ReusablePrimitives';

interface PrivateChatScreenProps {
  currentUser: UserProfile;
  friend: FriendContact | null;
  messages: ChatMessage[];
  isLoadingMessages: boolean;
  messageError: string | null;
  onSendMessage: (friendId: string, text: string) => Promise<void>;
  onSendMediaMessage: (params: {
    friendId: string;
    file: File;
    caption?: string;
    onProgress?: (percent: number, stageLabel: string) => void;
  }) => Promise<void>;
  onSendLocationMessage: (params: {
    friendId: string;
    location: Omit<ChatLocationAttachment, 'version'>;
  }) => Promise<void>;
  onRetryMessage: (
    friendId: string,
    messageId: string,
    text: string
  ) => Promise<void>;
  onOpenVoiceCallUI: (friendId: string) => void;
  onNavigateAddFriend: () => void;
  onBackMobile?: () => void;
}

interface LightboxMediaState {
  kind: ChatMediaKind;
  url: string;
  fileName: string;
  fileSize: number;
  caption?: string;
}

function formatDurationSeconds(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds <= 0) return '';
  const totalSec = Math.max(1, Math.round(seconds));
  const mins = Math.floor(totalSec / 60);
  const secs = totalSec % 60;
  return `${mins}:${String(secs).padStart(2, '0')}`;
}

/**
 * Generates a client-side JPEG thumbnail frame and duration from a selected local video file
 * so Android & desktop users immediately see a crisp video thumbnail in the staging drawer.
 */
function extractVideoThumbnailAndDuration(objectUrl: string): Promise<{
  thumbnailDataUrl: string | null;
  durationText: string;
}> {
  return new Promise((resolve) => {
    const video = document.createElement('video');
    let settled = false;

    const finish = (thumbnailDataUrl: string | null, durationSec: number) => {
      if (settled) return;
      settled = true;
      video.removeAttribute('src');
      video.load();
      resolve({
        thumbnailDataUrl,
        durationText: formatDurationSeconds(durationSec),
      });
    };

    const timeoutId = window.setTimeout(() => {
      finish(null, video.duration || 0);
    }, 3500);

    video.preload = 'metadata';
    video.muted = true;
    video.playsInline = true;

    video.onloadedmetadata = () => {
      const targetTime =
        Number.isFinite(video.duration) && video.duration > 0.4
          ? Math.min(0.25, video.duration / 4)
          : 0.1;
      try {
        video.currentTime = targetTime;
      } catch {
        window.clearTimeout(timeoutId);
        finish(null, video.duration || 0);
      }
    };

    video.onseeked = () => {
      window.clearTimeout(timeoutId);
      try {
        const width = video.videoWidth || 320;
        const height = video.videoHeight || 180;
        const maxDim = 240;
        const scale = Math.min(1, maxDim / Math.max(width, height));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(width * scale));
        canvas.height = Math.max(1, Math.round(height * scale));
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.78);
          finish(dataUrl, video.duration || 0);
          return;
        }
      } catch {
        // Fallback if canvas capture is restricted
      }
      finish(null, video.duration || 0);
    };

    video.onerror = () => {
      window.clearTimeout(timeoutId);
      finish(null, 0);
    };

    video.src = objectUrl;
  });
}

const PrivateMediaBubbleContent: React.FC<{
  media: ChatMediaAttachment;
  onOpenLightbox: (item: LightboxMediaState) => void;
}> = ({ media, onOpenLightbox }) => {
  const [signedUrl, setSignedUrl] = useState<string | null>(
    media.signedUrl || null
  );
  const [isLoadingUrl, setIsLoadingUrl] = useState<boolean>(!media.signedUrl);
  const [urlError, setUrlError] = useState<string | null>(null);
  const [reloadTick, setReloadTick] = useState(0);
  const [isVideoPlaying, setIsVideoPlaying] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    let isMounted = true;
    if (media.signedUrl && reloadTick === 0) {
      setSignedUrl(media.signedUrl);
      setIsLoadingUrl(false);
      return;
    }

    setIsLoadingUrl(true);
    setUrlError(null);

    resolveChatMediaSignedUrl(media.storagePath)
      .then((url) => {
        if (isMounted) {
          setSignedUrl(url);
          setIsLoadingUrl(false);
        }
      })
      .catch((err) => {
        if (isMounted) {
          setUrlError(
            err instanceof Error
              ? err.message
              : 'Could not load private media.'
          );
          setIsLoadingUrl(false);
        }
      });

    return () => {
      isMounted = false;
    };
  }, [media.storagePath, media.signedUrl, reloadTick]);

  const handleTogglePlayPause = () => {
    const vid = videoRef.current;
    if (!vid) return;
    if (vid.paused || vid.ended) {
      vid.play().catch(() => {});
    } else {
      vid.pause();
    }
  };

  const handleOpenVideoFullScreen = () => {
    const vid = videoRef.current;
    if (vid && !vid.paused) {
      vid.pause();
    }
    if (signedUrl) {
      onOpenLightbox({
        kind: 'video',
        url: signedUrl,
        fileName: media.fileName,
        fileSize: media.fileSize,
        caption: media.caption,
      });
    }
  };

  return (
    <div className="space-y-2">
      <div className="relative rounded-xl overflow-hidden bg-black/80 border border-rose-500/30">
        {isLoadingUrl ? (
          <div className="w-60 sm:w-72 h-44 flex flex-col items-center justify-center gap-2 p-4 text-xs text-rose-200/90">
            <Loader2 className="w-5 h-5 animate-spin text-rose-400" />
            <span>Decrypting private {media.kind} link...</span>
          </div>
        ) : urlError || !signedUrl ? (
          <div className="w-60 sm:w-72 p-4 flex flex-col items-center justify-center text-center gap-2 text-xs text-rose-200">
            <AlertCircle className="w-5 h-5 text-rose-400" />
            <p className="leading-relaxed">
              {urlError || 'Private media link expired or unavailable.'}
            </p>
            <button
              type="button"
              onClick={() => setReloadTick((n) => n + 1)}
              className="mt-1 px-3 py-1.5 rounded-lg bg-[#1A0B26] hover:bg-[#271038] border border-rose-500/40 text-xs font-medium text-white inline-flex items-center gap-1.5 cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Retry Loading Media</span>
            </button>
          </div>
        ) : media.kind === 'image' ? (
          <div className="group relative">
            <button
              type="button"
              onClick={() =>
                onOpenLightbox({
                  kind: 'image',
                  url: signedUrl,
                  fileName: media.fileName,
                  fileSize: media.fileSize,
                  caption: media.caption,
                })
              }
              className="block w-full text-left cursor-pointer focus:outline-none"
              title="Tap to view full screen"
            >
              <img
                src={signedUrl}
                alt={media.caption || media.fileName}
                loading="lazy"
                className="max-h-72 w-full object-cover sm:max-w-[320px] rounded-t-xl transition-transform duration-200 group-hover:scale-[1.01]"
              />
            </button>
            <button
              type="button"
              onClick={() =>
                onOpenLightbox({
                  kind: 'image',
                  url: signedUrl,
                  fileName: media.fileName,
                  fileSize: media.fileSize,
                  caption: media.caption,
                })
              }
              aria-label="View full screen photo"
              className="absolute top-2 right-2 min-h-[34px] min-w-[34px] px-2 rounded-lg bg-black/75 hover:bg-black/90 border border-rose-500/40 text-white flex items-center justify-center gap-1 text-[11px] shadow-[0_4px_12px_rgba(0,0,0,0.85)] cursor-pointer"
            >
              <Maximize2 className="w-3.5 h-3.5 text-rose-300" />
              <span className="hidden sm:inline">Full</span>
            </button>
          </div>
        ) : (
          <div className="relative w-full max-w-[320px] bg-black group">
            <video
              ref={videoRef}
              src={`${signedUrl}#t=0.1`}
              controls
              playsInline
              preload="metadata"
              onPlay={() => setIsVideoPlaying(true)}
              onPause={() => setIsVideoPlaying(false)}
              onEnded={() => setIsVideoPlaying(false)}
              className="max-h-72 w-full rounded-t-xl bg-black"
            />

            {/* Top Action Bar for Video: Play/Pause Toggle + Full Screen Viewer */}
            <div className="absolute top-2 left-2 right-2 flex items-center justify-between gap-2 pointer-events-none">
              <button
                type="button"
                onClick={handleTogglePlayPause}
                aria-label={isVideoPlaying ? 'Pause video' : 'Play video'}
                className="pointer-events-auto min-h-[32px] px-2.5 rounded-lg bg-black/75 hover:bg-black/90 border border-rose-500/40 text-white inline-flex items-center gap-1.5 text-[11px] font-medium shadow-[0_4px_12px_rgba(0,0,0,0.85)] cursor-pointer"
              >
                {isVideoPlaying ? (
                  <>
                    <Pause className="w-3.5 h-3.5 text-rose-300" />
                    <span>Pause</span>
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5 text-rose-300 fill-rose-300" />
                    <span>Play</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={handleOpenVideoFullScreen}
                aria-label="Open full screen video player"
                className="pointer-events-auto min-h-[32px] px-2.5 rounded-lg bg-black/75 hover:bg-black/90 border border-rose-500/40 text-white inline-flex items-center gap-1 text-[11px] font-medium shadow-[0_4px_12px_rgba(0,0,0,0.85)] cursor-pointer"
              >
                <Maximize2 className="w-3.5 h-3.5 text-rose-300" />
                <span>Full</span>
              </button>
            </div>
          </div>
        )}

        {/* Metadata Footer Inside Media Frame */}
        <div className="px-2.5 py-1.5 bg-black/85 border-t border-white/10 flex items-center justify-between gap-2 text-[10px] text-[#CBD5E1]">
          <span className="inline-flex items-center gap-1 truncate">
            <Lock className="w-3 h-3 text-rose-400 shrink-0" />
            <span className="uppercase font-semibold text-rose-300 shrink-0">
              {media.kind === 'video' ? 'Video' : 'Photo'}
            </span>
            <span aria-hidden="true">·</span>
            <span className="truncate">{media.fileName}</span>
          </span>
          {media.fileSize > 0 && (
            <span className="font-mono text-rose-200/90 shrink-0">
              {formatFileSize(media.fileSize)}
            </span>
          )}
        </div>
      </div>

      {/* Optional Caption Below Media */}
      {media.caption && (
        <p className="whitespace-pre-wrap break-words text-sm leading-relaxed px-0.5">
          {media.caption}
        </p>
      )}
    </div>
  );
};

export const PrivateChatScreen: React.FC<PrivateChatScreenProps> = ({
  currentUser,
  friend,
  messages,
  isLoadingMessages,
  messageError,
  onSendMessage,
  onSendMediaMessage,
  onSendLocationMessage,
  onRetryMessage,
  onOpenVoiceCallUI,
  onNavigateAddFriend,
  onBackMobile,
}) => {
  const [draft, setDraft] = useState('');
  const [isSending, setIsSending] = useState(false);

  // Staged Photo/Video Attachment State
  const [stagedFile, setStagedFile] = useState<File | null>(null);
  const [stagedKind, setStagedKind] = useState<ChatMediaKind>('image');
  const [stagedPreviewUrl, setStagedPreviewUrl] = useState<string | null>(null);
  const [stagedVideoThumbUrl, setStagedVideoThumbUrl] = useState<string | null>(
    null
  );
  const [stagedVideoDuration, setStagedVideoDuration] = useState<string>('');
  const [attachmentError, setAttachmentError] = useState<string | null>(null);
  const [uploadProgress, setUploadProgress] = useState<{
    percent: number;
    label: string;
  } | null>(null);
  const [copiedStorageSql, setCopiedStorageSql] = useState(false);

  // Full-Screen Image & Video Lightbox State
  const [lightboxMedia, setLightboxMedia] =
    useState<LightboxMediaState | null>(null);

  // Location Picker & Full-Screen Map Viewer State
  const [isLocationModalOpen, setIsLocationModalOpen] =
    useState<boolean>(false);
  const [expandedLocation, setExpandedLocation] =
    useState<ChatLocationAttachment | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length, friend?.id]);

  // Clean up object URL when stagedFile changes or component unmounts
  useEffect(() => {
    return () => {
      if (stagedPreviewUrl) {
        URL.revokeObjectURL(stagedPreviewUrl);
      }
    };
  }, [stagedPreviewUrl]);

  // Clear staged attachment when switching friends
  useEffect(() => {
    if (stagedPreviewUrl) {
      URL.revokeObjectURL(stagedPreviewUrl);
    }
    setStagedFile(null);
    setStagedPreviewUrl(null);
    setStagedVideoThumbUrl(null);
    setStagedVideoDuration('');
    setAttachmentError(null);
    setUploadProgress(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [friend?.id]);

  // Close lightbox on Escape key
  useEffect(() => {
    if (!lightboxMedia) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setLightboxMedia(null);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [lightboxMedia]);

  const clearStagedAttachment = () => {
    if (stagedPreviewUrl) {
      URL.revokeObjectURL(stagedPreviewUrl);
    }
    setStagedFile(null);
    setStagedPreviewUrl(null);
    setStagedVideoThumbUrl(null);
    setStagedVideoDuration('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleFileSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setAttachmentError(null);
    try {
      const { kind } = validateChatMediaFile(file);
      if (stagedPreviewUrl) {
        URL.revokeObjectURL(stagedPreviewUrl);
      }
      const objectUrl = URL.createObjectURL(file);
      setStagedFile(file);
      setStagedKind(kind);
      setStagedPreviewUrl(objectUrl);
      setStagedVideoThumbUrl(null);
      setStagedVideoDuration('');

      if (kind === 'video') {
        const { thumbnailDataUrl, durationText } =
          await extractVideoThumbnailAndDuration(objectUrl);
        setStagedVideoThumbUrl(thumbnailDataUrl);
        setStagedVideoDuration(durationText);
      }
    } catch (err) {
      clearStagedAttachment();
      setAttachmentError(
        err instanceof Error
          ? err.message
          : 'Invalid photo or video file selected.'
      );
    }
  };

  const handleCopyStorageSql = async () => {
    try {
      await navigator.clipboard.writeText(PREPARED_CHAT_MEDIA_STORAGE_SQL);
      setCopiedStorageSql(true);
      setTimeout(() => setCopiedStorageSql(false), 2500);
    } catch {
      // Ignore clipboard permission errors
    }
  };

  // Empty state if user has no accepted friends yet
  if (!friend) {
    return (
      <div className="flex flex-col items-center justify-center text-center h-full min-h-[540px] lg:h-[calc(100vh-5.5rem)] rounded-3xl bg-black/50 border border-rose-500/30 p-6 space-y-4 shadow-[0_24px_65px_rgba(0,0,0,0.85)]">
        <div className="w-14 h-14 rounded-2xl bg-[#160A24]/90 border border-rose-500/40 flex items-center justify-center shadow-[0_0_24px_rgba(225,29,72,0.32)]">
          <ShieldCheck className="w-7 h-7 text-rose-300" />
        </div>
        <div className="space-y-1.5 max-w-sm rounded-2xl bg-black/65 px-4 py-3 border border-white/5">
          <h2 className="font-display text-xl font-bold text-white drop-shadow-[0_2px_8px_rgba(0,0,0,0.95)]">
            Friend-Only Private Messaging
          </h2>
          <p className="text-xs text-[#E2E8F0] leading-relaxed">
            Supabase Row Level Security (
            <code className="font-mono text-rose-300">public.are_friends</code>)
            restricts messaging and media sharing exclusively to accepted
            friends. Add a friend using their{' '}
            <span className="font-mono text-rose-300">MOON-XXXX-XX</span> code
            to start chatting in real time.
          </p>
        </div>
        <MoonButton
          type="button"
          variant="primary"
          onClick={onNavigateAddFriend}
          leftIcon={<UserPlus className="w-4 h-4" />}
        >
          Add Friend by Code
        </MoonButton>
      </div>
    );
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSending) return;

    const trimmedCaption = draft.trim();

    // Case 1: Sending a staged photo or video (with optional caption)
    if (stagedFile) {
      setIsSending(true);
      setAttachmentError(null);
      setUploadProgress({
        percent: 0,
        label: 'Starting private media upload (0%)...',
      });

      try {
        await onSendMediaMessage({
          friendId: friend.id,
          file: stagedFile,
          caption: trimmedCaption || undefined,
          onProgress: (percent, label) => {
            setUploadProgress({ percent, label });
          },
        });
        setDraft('');
        clearStagedAttachment();
      } catch (err) {
        setAttachmentError(
          err instanceof Error
            ? err.message
            : 'Failed to upload and send media.'
        );
      } finally {
        setIsSending(false);
        setUploadProgress(null);
      }
      return;
    }

    // Case 2: Sending a standard plain-text message
    if (!trimmedCaption) return;

    setDraft('');
    setIsSending(true);
    try {
      await onSendMessage(friend.id, trimmedCaption);
    } finally {
      setIsSending(false);
    }
  };

  const quickReplies = [
    'Connected via MOON friend code!',
    'Testing Supabase Realtime messaging.',
    'Are you free for a quick sync tonight?',
  ];

  const CombinedError = attachmentError || messageError;
  const needsStorageBucketSql = Boolean(
    CombinedError &&
      (CombinedError.toLowerCase().includes('chat-media') ||
        CombinedError.toLowerCase().includes('bucket') ||
        CombinedError.toLowerCase().includes('storage'))
  );

  return (
    <div className="flex flex-col h-full min-h-[540px] lg:h-[calc(100vh-5.5rem)] rounded-3xl bg-black/40 border border-rose-500/30 overflow-hidden shadow-[0_24px_65px_rgba(0,0,0,0.88),0_0_32px_rgba(153,27,27,0.18)]">
      {/* Interactive Location & Destination Picker Modal */}
      <LunarLocationPickerModal
        isOpen={isLocationModalOpen}
        friendDisplayName={friend.displayName}
        onClose={() => setIsLocationModalOpen(false)}
        onConfirmSendLocation={async (loc) => {
          await onSendLocationMessage({
            friendId: friend.id,
            location: loc,
          });
        }}
      />

      {/* Interactive Expanded Map Viewer Modal for Shared Locations */}
      <LunarLocationViewerModal
        location={expandedLocation}
        onClose={() => setExpandedLocation(null)}
      />

      {/* Full-Screen Image & Video Lightbox Viewer */}
      {lightboxMedia && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Full screen media viewer"
          onClick={() => setLightboxMedia(null)}
          className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex flex-col items-center justify-between p-4 sm:p-6 animate-fade-in"
        >
          {/* Top Lightbox Bar */}
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-5xl flex items-center justify-between gap-4 px-4 py-2.5 rounded-2xl bg-[#09030F]/90 border border-rose-500/35"
          >
            <div className="min-w-0 flex items-center gap-2 text-xs text-[#E2E8F0]">
              <Lock className="w-3.5 h-3.5 text-rose-400 shrink-0" />
              <span className="uppercase text-[10px] font-semibold px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-200 border border-rose-500/30 shrink-0">
                {lightboxMedia.kind === 'video' ? 'Video' : 'Photo'}
              </span>
              <span className="font-medium text-white truncate">
                {lightboxMedia.fileName}
              </span>
              {lightboxMedia.fileSize > 0 && (
                <span className="font-mono text-rose-300 shrink-0">
                  ({formatFileSize(lightboxMedia.fileSize)})
                </span>
              )}
            </div>
            <button
              type="button"
              onClick={() => setLightboxMedia(null)}
              aria-label="Close full screen viewer"
              className="min-h-[38px] px-3 rounded-xl bg-[#1A0B26] hover:bg-rose-600 text-white border border-rose-500/40 inline-flex items-center gap-1.5 text-xs font-medium transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
              <span>Close</span>
            </button>
          </div>

          {/* Center Full-Screen Photo or Video Player */}
          <div
            onClick={(e) => e.stopPropagation()}
            className="flex-1 flex items-center justify-center my-3 max-h-[78vh] w-full overflow-hidden"
          >
            {lightboxMedia.kind === 'video' ? (
              <video
                src={lightboxMedia.url}
                controls
                autoPlay
                playsInline
                className="max-h-[76vh] max-w-full rounded-2xl border border-rose-500/30 bg-black shadow-[0_0_50px_rgba(225,29,72,0.28)]"
              />
            ) : (
              <img
                src={lightboxMedia.url}
                alt={lightboxMedia.caption || lightboxMedia.fileName}
                className="max-h-[76vh] max-w-full object-contain rounded-2xl border border-rose-500/30 shadow-[0_0_50px_rgba(225,29,72,0.28)]"
              />
            )}
          </div>

          {/* Bottom Caption Bar */}
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-2xl text-center"
          >
            {lightboxMedia.caption ? (
              <p className="inline-block px-4 py-2 rounded-xl bg-[#09030F]/90 border border-rose-500/30 text-sm text-white">
                {lightboxMedia.caption}
              </p>
            ) : (
              <p className="text-[11px] text-[#CBD5E1]">
                Private Friend-Only Media · Tap outside or press Esc to close
              </p>
            )}
          </div>
        </div>
      )}

      {/* Compact Android Mobile Top App Bar (56px height) */}
      <div className="h-14 px-3.5 sm:px-5 bg-[#08030E]/85 backdrop-blur-sm border-b border-[#351635] flex items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-2.5 min-w-0">
          {onBackMobile && (
            <button
              type="button"
              onClick={onBackMobile}
              aria-label="Back to friends list"
              className="lg:hidden min-h-[44px] min-w-[44px] -ml-1 rounded-xl hover:bg-[#1A0B26] flex items-center justify-center text-[#F8FAFC] cursor-pointer"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}

          <LunarAvatar
            name={friend.displayName}
            hue={friend.avatarHue}
            size="sm"
          />

          <div className="min-w-0">
            <h2 className="font-display text-sm sm:text-base font-semibold text-white truncate drop-shadow-[0_1px_6px_rgba(0,0,0,0.9)]">
              {friend.displayName}
            </h2>
            <div className="flex items-center gap-1.5 text-[11px] text-[#E2E8F0] truncate">
              <span>@{friend.username}</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono text-rose-300">
                {friend.friendCode}
              </span>
              <span className="hidden sm:inline" aria-hidden="true">
                ·
              </span>
              <span className="hidden sm:inline">Realtime RLS Thread</span>
            </div>
          </div>
        </div>

        {/* Right contextual action: Open LiveKit Voice Call Screen */}
        <button
          type="button"
          onClick={() => onOpenVoiceCallUI(friend.id)}
          className="min-h-[44px] px-3.5 rounded-xl bg-[#160A24]/90 hover:bg-gradient-to-r hover:from-[#6D28D9] hover:to-[#9F1239] text-rose-200 hover:text-white border border-rose-500/40 inline-flex items-center gap-2 text-xs font-medium transition-all shadow-[0_0_16px_rgba(225,29,72,0.25)] shrink-0 cursor-pointer"
        >
          <Phone className="w-4 h-4" />
          <span>Voice Call</span>
        </button>
      </div>

      {/* Scrollable 1-to-1 Message History with Dark Translucent Overlay so Giant Blood Moon Stays Visible & Text Stays Readable */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4 bg-gradient-to-b from-black/35 via-black/50 to-black/70">
        <div className="text-center py-1.5">
          <p className="inline-block px-3 py-1 rounded-xl bg-black/65 border border-rose-500/20 text-xs text-[#E2E8F0] shadow-[0_4px_12px_rgba(0,0,0,0.75)]">
            <span>Friend-only RLS verified thread with </span>
            <span className="text-white font-semibold">
              {friend.displayName}
            </span>
            <span className="mx-1.5 text-rose-400" aria-hidden="true">
              ·
            </span>
            <span className="font-mono text-rose-300">
              {friend.friendCode}
            </span>
          </p>
        </div>

        {CombinedError && (
          <div className="space-y-2">
            <ErrorBanner
              title="Message / Media Sync Notice"
              message={CombinedError}
            />
            {needsStorageBucketSql && (
              <div className="rounded-2xl bg-black/80 border border-rose-500/40 p-3.5 flex flex-wrap items-center justify-between gap-3 text-xs text-[#E2E8F0]">
                <span>
                  Run the private{' '}
                  <code className="font-mono text-rose-300">chat-media</code>{' '}
                  Storage bucket & friend-only RLS SQL in Supabase SQL Editor:
                </span>
                <button
                  type="button"
                  onClick={handleCopyStorageSql}
                  className="px-3 py-1.5 rounded-xl bg-[#1A0B26] hover:bg-[#271038] border border-rose-500/40 text-white font-medium inline-flex items-center gap-1.5 cursor-pointer"
                >
                  {copiedStorageSql ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Copied Storage SQL!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-rose-300" />
                      <span>Copy Private Storage SQL</span>
                    </>
                  )}
                </button>
              </div>
            )}
          </div>
        )}

        {isLoadingMessages ? (
          <div className="py-12 flex items-center justify-center gap-2 text-xs text-rose-200">
            <Loader2 className="w-4 h-4 animate-spin text-rose-400" />
            <span className="drop-shadow-[0_2px_6px_rgba(0,0,0,0.95)]">
              Loading messages from public.messages...
            </span>
          </div>
        ) : messages.length === 0 ? (
          <div className="py-10 text-center">
            <div className="inline-block max-w-sm rounded-2xl bg-black/65 border border-rose-500/25 px-5 py-4 space-y-1.5 shadow-[0_12px_30px_rgba(0,0,0,0.85)]">
              <p className="text-sm font-semibold text-white">
                No messages in this conversation yet
              </p>
              <p className="text-xs text-[#CBD5E1]">
                Send a text message or share a private photo/video below via{' '}
                <code className="font-mono text-rose-300">public.messages</code>{' '}
                and{' '}
                <code className="font-mono text-rose-300">chat-media</code>.
              </p>
            </div>
          </div>
        ) : (
          messages.map((msg) => {
            const isMe =
              msg.senderId === 'me' || msg.senderId === currentUser.id;

            return (
              <div
                key={msg.id}
                className={`flex flex-col ${
                  isMe ? 'items-end' : 'items-start'
                }`}
              >
                <div
                  className={`max-w-[85%] sm:max-w-[74%] rounded-2xl ${
                    msg.media || msg.location ? 'p-2.5' : 'px-4 py-2.5'
                  } text-sm leading-relaxed ${
                    isMe
                      ? msg.deliveryState === 'failed'
                        ? 'bg-[#2B0C18]/95 border border-rose-500/55 text-rose-100 rounded-br-md shadow-[0_6px_20px_rgba(0,0,0,0.85)]'
                        : 'bg-gradient-to-br from-[#6D28D9]/95 via-[#5B21B6]/95 to-[#9F1239]/95 text-[#F8FAFC] border border-rose-400/40 rounded-br-md shadow-[0_6px_22px_rgba(190,18,60,0.35),0_4px_14px_rgba(0,0,0,0.85)]'
                      : 'bg-[#09030F]/88 text-[#F8FAFC] border border-rose-500/30 rounded-bl-md shadow-[0_6px_20px_rgba(0,0,0,0.85)]'
                  }`}
                >
                  {msg.media ? (
                    <PrivateMediaBubbleContent
                      media={msg.media}
                      onOpenLightbox={(item) => setLightboxMedia(item)}
                    />
                  ) : msg.location ? (
                    <LunarLocationChatCard
                      location={msg.location}
                      onExpandInteractiveMap={(loc) => setExpandedLocation(loc)}
                    />
                  ) : (
                    <p className="whitespace-pre-wrap break-words">
                      {msg.text}
                    </p>
                  )}
                </div>

                {/* Unboxed Message Timestamp & Delivery State with High-Contrast Drop Shadow */}
                <div className="flex items-center gap-1.5 mt-1 px-1.5 py-0.5 rounded bg-black/55 text-[11px] text-[#E2E8F0]">
                  <span className="font-mono">{msg.timestampText}</span>
                  {isMe && (
                    <>
                      <span aria-hidden="true">·</span>
                      {msg.deliveryState === 'sending' && (
                        <span className="inline-flex items-center gap-1 text-rose-300">
                          <Loader2 className="w-3 h-3 animate-spin" />
                          <span>Sending...</span>
                        </span>
                      )}
                      {msg.deliveryState === 'delivered' && (
                        <span className="inline-flex items-center gap-1 text-rose-200">
                          <CheckCheck className="w-3.5 h-3.5 text-rose-400" />
                          <span>Delivered</span>
                        </span>
                      )}
                      {msg.deliveryState === 'failed' && !msg.media && (
                        <button
                          type="button"
                          onClick={() =>
                            onRetryMessage(friend.id, msg.id, msg.text)
                          }
                          className="inline-flex items-center gap-1 text-rose-300 hover:text-rose-200 font-medium underline underline-offset-2 cursor-pointer"
                        >
                          <AlertCircle className="w-3 h-3" />
                          <span>Failed — Tap to retry</span>
                          <RefreshCw className="w-3 h-3 ml-0.5" />
                        </button>
                      )}
                    </>
                  )}
                </div>
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Staged Media Preview (Thumbnail + File Size) & 0%–100% Upload Progress Drawer */}
      {stagedFile && stagedPreviewUrl && (
        <div className="px-4 py-3 bg-[#09030F]/95 border-t border-rose-500/35 space-y-2.5 shrink-0">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              {stagedKind === 'image' ? (
                <img
                  src={stagedPreviewUrl}
                  alt="Selected photo thumbnail"
                  className="w-16 h-16 rounded-xl object-cover border border-rose-500/45 shrink-0 bg-black"
                />
              ) : (
                <div className="relative w-16 h-16 rounded-xl overflow-hidden border border-rose-500/45 shrink-0 bg-black flex items-center justify-center">
                  {stagedVideoThumbUrl ? (
                    <img
                      src={stagedVideoThumbUrl}
                      alt="Selected video thumbnail"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <video
                      src={`${stagedPreviewUrl}#t=0.1`}
                      preload="metadata"
                      muted
                      playsInline
                      className="w-full h-full object-cover"
                    />
                  )}
                  <div className="absolute inset-0 bg-black/35 flex items-center justify-center">
                    <div className="w-6 h-6 rounded-full bg-rose-600/90 border border-white/40 flex items-center justify-center shadow-md">
                      <Play className="w-3 h-3 text-white fill-white ml-0.5" />
                    </div>
                  </div>
                  {stagedVideoDuration && (
                    <span className="absolute bottom-0.5 right-1 px-1 rounded bg-black/80 font-mono text-[9px] text-white">
                      {stagedVideoDuration}
                    </span>
                  )}
                </div>
              )}

              <div className="min-w-0 space-y-0.5">
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-rose-500/20 border border-rose-500/40 text-[10px] font-semibold uppercase tracking-wider text-rose-200">
                    {stagedKind === 'video' ? (
                      <>
                        <Film className="w-3 h-3" />
                        <span>Private Video</span>
                      </>
                    ) : (
                      <>
                        <ImageIcon className="w-3 h-3" />
                        <span>Private Photo</span>
                      </>
                    )}
                  </span>
                  <span className="px-2 py-0.5 rounded-md bg-black/70 border border-white/10 font-mono text-xs text-rose-300 font-semibold">
                    {formatFileSize(stagedFile.size)}
                  </span>
                </div>
                <p className="text-xs text-white font-medium truncate">
                  {stagedFile.name}
                </p>
                <p className="text-[11px] text-[#CBD5E1] truncate">
                  Private <code className="font-mono text-rose-300">chat-media</code> bucket · Friend-only Signed URL
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={clearStagedAttachment}
              disabled={isSending}
              aria-label="Remove selected media"
              className="min-h-[38px] min-w-[38px] rounded-xl bg-[#160A24] hover:bg-rose-950/80 border border-rose-500/35 text-rose-200 hover:text-white flex items-center justify-center transition-colors disabled:opacity-50 cursor-pointer shrink-0"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {uploadProgress && (
            <div className="space-y-1">
              <div className="flex items-center justify-between text-[11px] text-rose-200">
                <span className="inline-flex items-center gap-1.5">
                  <Loader2 className="w-3.5 h-3.5 animate-spin text-rose-400" />
                  <span>{uploadProgress.label}</span>
                </span>
                <span className="font-mono font-semibold text-white">
                  {uploadProgress.percent}%
                </span>
              </div>
              <div className="w-full h-2 rounded-full bg-black/80 overflow-hidden border border-rose-500/35">
                <div
                  className="h-full bg-gradient-to-r from-[#6D28D9] via-[#E11D48] to-[#FB7185] transition-all duration-150"
                  style={{ width: `${uploadProgress.percent}%` }}
                />
              </div>
            </div>
          )}
        </div>
      )}

      {/* Quick Reply Suggestions */}
      {!stagedFile && (
        <div className="px-4 py-2 bg-[#06020A]/95 border-t border-[#261128] flex items-center gap-1.5 overflow-x-auto">
          {quickReplies.map((reply) => (
            <button
              key={reply}
              type="button"
              onClick={() => setDraft(reply)}
              className="min-h-[34px] px-2.5 py-1 rounded-lg bg-[#13081E] hover:bg-[#1F0E30] border border-[#351635] text-xs text-[#E2E8F0] hover:text-white whitespace-nowrap shrink-0 transition-colors cursor-pointer"
            >
              {reply}
            </button>
          ))}
        </div>
      )}

      {/* Bottom Message & Private Media Composer */}
      <form
        onSubmit={handleSubmit}
        className="p-3 sm:p-3.5 bg-[#08030E]/95 border-t border-[#2D142C] flex items-center gap-2 sm:gap-2.5 shrink-0"
      >
        <input
          ref={fileInputRef}
          type="file"
          accept="image/jpeg,image/png,image/webp,image/gif,video/mp4,video/webm,video/quicktime,video/3gpp,.mp4,.webm,.mov,.m4v,.3gp,.jpg,.jpeg,.png,.webp,.gif"
          onChange={handleFileSelected}
          className="hidden"
        />

        <button
          type="button"
          onClick={() => {
            setAttachmentError(null);
            fileInputRef.current?.click();
          }}
          disabled={isSending}
          aria-label="Attach private photo or video"
          title="Attach Private Photo (up to 15 MB) or Video MP4/WebM/MOV (up to 50 MB)"
          className={`min-h-[46px] min-w-[44px] px-2.5 rounded-2xl border flex items-center justify-center gap-1.5 text-xs font-medium transition-all shrink-0 cursor-pointer disabled:opacity-50 ${
            stagedFile
              ? 'bg-gradient-to-r from-[#6D28D9]/40 to-[#9F1239]/40 border-rose-400/60 text-white shadow-[0_0_14px_rgba(225,29,72,0.3)]'
              : 'bg-[#12071D] hover:bg-[#1C0B2B] border-rose-500/35 text-rose-200 hover:text-white'
          }`}
        >
          <ImagePlus className="w-4 h-4 text-rose-300" />
          <span className="hidden sm:inline">Media</span>
        </button>

        <button
          type="button"
          onClick={() => {
            setAttachmentError(null);
            setIsLocationModalOpen(true);
          }}
          disabled={isSending}
          aria-label="Share GPS Location or Map Destination"
          title="Share Current GPS Location or Search Destination on Map"
          className="min-h-[46px] min-w-[44px] px-2.5 rounded-2xl bg-[#12071D] hover:bg-[#1C0B2B] border border-rose-500/35 text-rose-200 hover:text-white flex items-center justify-center gap-1.5 text-xs font-medium transition-all shrink-0 cursor-pointer disabled:opacity-50"
        >
          <MapPin className="w-4 h-4 text-rose-300" />
          <span className="hidden sm:inline">Location</span>
        </button>

        <input
          type="text"
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder={
            stagedFile
              ? `Add a caption for ${friend.displayName} (optional)...`
              : `Message ${friend.displayName}...`
          }
          className="flex-1 min-h-[46px] px-4 py-2.5 rounded-2xl bg-[#040208] border border-[#351635] focus:border-rose-500/80 text-sm text-[#F8FAFC] placeholder-[#7E7291] focus:outline-none focus:ring-2 focus:ring-rose-500/20"
        />
        <MoonButton
          type="submit"
          variant="primary"
          disabled={!draft.trim() && !stagedFile}
          isLoading={isSending}
          aria-label={stagedFile ? 'Send media message' : 'Send message'}
          className="rounded-2xl min-w-[48px] min-h-[46px]"
          leftIcon={<Send className="w-4 h-4" />}
        >
          {stagedFile ? 'Send Media' : 'Send'}
        </MoonButton>
      </form>
    </div>
  );
};
