import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Inbox,
  RefreshCw,
  Search,
  Send,
  ShieldCheck,
  UserCheck,
  UserPlus,
} from 'lucide-react';
import {
  FriendCodeSearchResult,
  FriendRequest,
  FriendSystemDiagnosticReport,
  UserProfile,
} from '../../types/moon';
import {
  runFriendSystemDiagnostics,
  searchUserByFriendCodeSupabase,
  sendFriendRequestByCodeSupabase,
} from '../../services/supabaseAdapter';
import {
  CopyFeedbackButton,
  ErrorBanner,
  LunarAvatar,
  MoonButton,
  MoonInput,
} from '../ui/ReusablePrimitives';

interface AddFriendScreenProps {
  currentUser: UserProfile;
  onRequestCreated: (newRequest: FriendRequest) => void;
  onNavigateRequests: () => void;
  onNavigateFriends: () => void;
}

export const AddFriendScreen: React.FC<AddFriendScreenProps> = ({
  currentUser,
  onRequestCreated,
  onNavigateRequests,
  onNavigateFriends,
}) => {
  const [codeInput, setCodeInput] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [searchResult, setSearchResult] =
    useState<FriendCodeSearchResult | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [sentConfirmation, setSentConfirmation] = useState<{
    displayName: string;
    friendCode: string;
    username: string;
  } | null>(null);

  const [diagnosticReport, setDiagnosticReport] =
    useState<FriendSystemDiagnosticReport | null>(null);
  const [isRunningDiagnostics, setIsRunningDiagnostics] = useState(false);

  const handleRunDiagnostics = async () => {
    setIsRunningDiagnostics(true);
    try {
      const report = await runFriendSystemDiagnostics(currentUser);
      setDiagnosticReport(report);
    } finally {
      setIsRunningDiagnostics(false);
    }
  };

  useEffect(() => {
    handleRunDiagnostics();
  }, [currentUser.id]);

  // Step 1: Search for a user by their exact friend_code
  const handleSearchByCode = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMessage(null);
    setSentConfirmation(null);
    setSearchResult(null);

    const trimmed = codeInput.trim();
    if (!trimmed) {
      setErrorMessage('Please enter a friend_code to search.');
      return;
    }

    setIsSearching(true);
    try {
      const result = await searchUserByFriendCodeSupabase({
        currentUser,
        friendCodeInput: trimmed,
      });
      setSearchResult(result);
    } catch (err) {
      setErrorMessage(
        err instanceof Error
          ? err.message
          : 'Could not find a user with that friend code.'
      );
    } finally {
      setIsSearching(false);
    }
  };

  // Step 2: Send friend request to the searched user (or directly by code)
  const handleSendRequest = async (targetCode?: string) => {
    const codeToUse = (targetCode || codeInput).trim();
    if (!codeToUse) {
      setErrorMessage('Please enter a friend_code first.');
      return;
    }

    setErrorMessage(null);
    setSentConfirmation(null);
    setIsSending(true);
    try {
      const { request, targetProfile } = await sendFriendRequestByCodeSupabase({
        currentUser,
        friendCodeInput: codeToUse,
      });

      onRequestCreated(request);
      setSentConfirmation(targetProfile);
      setSearchResult((prev) =>
        prev
          ? {
              ...prev,
              relationshipStatus: 'pending_outgoing',
              existingRequestId: request.id,
            }
          : null
      );
      setCodeInput('');
    } catch (err) {
      setErrorMessage(
        err instanceof Error
          ? err.message
          : 'Could not send friend request.'
      );
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="space-y-6 pb-8">
      <div>
        <h2 className="font-display text-xl sm:text-2xl font-bold text-white drop-shadow-[0_2px_10px_rgba(0,0,0,0.85)]">
          Search &amp; Add Friend by Code
        </h2>
        <p className="text-xs text-[#CBD5E1] mt-0.5">
          Search <code className="font-mono text-rose-300">public.profiles</code> using an exact <code className="font-mono text-rose-300">friend_code</code> and send a friend request.
        </p>
      </div>

      {/* Current User's Own Unique friend_code Banner */}
      <div className="rounded-2xl bg-black/55 border border-rose-500/30 p-4 flex flex-wrap items-center justify-between gap-3 shadow-[0_14px_35px_rgba(0,0,0,0.85)]">
        <div>
          <p className="text-xs text-[#CBD5E1]">
            Your Unique <code className="font-mono text-rose-300">friend_code</code>
          </p>
          <p className="font-mono text-lg font-semibold text-rose-200 tracking-wider mt-0.5 select-all drop-shadow-[0_0_10px_rgba(225,29,72,0.35)]">
            {currentUser.friendCode}
          </p>
        </div>
        <CopyFeedbackButton
          value={currentUser.friendCode}
          label="Copy My Code"
        />
      </div>

      {errorMessage && (
        <ErrorBanner
          title="Friend Code Lookup / Request Notice"
          message={errorMessage}
          onDismiss={() => setErrorMessage(null)}
        />
      )}

      {sentConfirmation && (
        <div className="rounded-2xl bg-[#140820]/90 border border-rose-400/40 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-[0_12px_30px_rgba(0,0,0,0.8)]">
          <div className="flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-white">
                Friend request sent to {sentConfirmation.displayName} (@
                {sentConfirmation.username})
              </p>
              <p className="text-xs text-[#CBD5E1] mt-0.5">
                Code{' '}
                <span className="font-mono text-rose-300">
                  {sentConfirmation.friendCode}
                </span>{' '}
                · Saved in <code className="font-mono text-rose-200">public.friend_requests</code>.
              </p>
            </div>
          </div>
          <MoonButton
            type="button"
            variant="secondary"
            onClick={onNavigateRequests}
          >
            View Outgoing Requests
          </MoonButton>
        </div>
      )}

      {/* Search & Send Form */}
      <form
        onSubmit={handleSearchByCode}
        className="rounded-3xl bg-black/55 border border-rose-500/30 p-5 sm:p-6 space-y-5 shadow-[0_22px_55px_rgba(0,0,0,0.88)]"
      >
        <MoonInput
          label="Enter Exact Friend Code"
          mono
          value={codeInput}
          onChange={(e) => {
            setCodeInput(e.target.value.toUpperCase());
            if (searchResult) setSearchResult(null);
          }}
          placeholder="MOON-XXXX-XX"
          hint="Enter another user's exact friend_code to search their profile."
          rightSlot={<Search className="w-4 h-4 text-rose-400 mr-2.5" />}
        />

        <div className="flex flex-wrap items-center justify-end gap-2.5">
          <MoonButton
            type="submit"
            variant="secondary"
            isLoading={isSearching}
            leftIcon={<Search className="w-4 h-4 text-rose-300" />}
          >
            Search User
          </MoonButton>
          <MoonButton
            type="button"
            variant="primary"
            isLoading={isSending}
            onClick={() => handleSendRequest()}
            leftIcon={<Send className="w-4 h-4" />}
          >
            Send Friend Request
          </MoonButton>
        </div>

        {/* Search Result Preview Card */}
        {searchResult && (
          <div className="pt-4 border-t border-[#2D142C]">
            <div className="rounded-2xl bg-black/75 border border-rose-500/35 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3.5 min-w-0">
                <LunarAvatar
                  name={searchResult.profile.displayName}
                  hue={searchResult.profile.avatarHue}
                  size="md"
                />
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="font-display text-base font-semibold text-white truncate">
                      {searchResult.profile.displayName}
                    </h3>
                    <span className="text-xs text-[#CBD5E1]">
                      @{searchResult.profile.username}
                    </span>
                  </div>
                  <p className="text-xs text-[#CBD5E1] mt-0.5">
                    <span>Exact Code: </span>
                    <span className="font-mono text-rose-300 font-medium">
                      {searchResult.profile.friendCode}
                    </span>
                  </p>
                  <p className="text-xs text-[#948CA8] truncate mt-0.5">
                    {searchResult.profile.bio}
                  </p>
                </div>
              </div>

              {/* Contextual Action Based on Relationship Status */}
              <div className="shrink-0">
                {searchResult.relationshipStatus === 'none' && (
                  <MoonButton
                    type="button"
                    variant="primary"
                    isLoading={isSending}
                    onClick={() =>
                      handleSendRequest(searchResult.profile.friendCode)
                    }
                    leftIcon={<UserPlus className="w-4 h-4" />}
                  >
                    Send Request
                  </MoonButton>
                )}

                {searchResult.relationshipStatus === 'self' && (
                  <span className="text-xs font-medium text-amber-300">
                    Your own profile (cannot add yourself)
                  </span>
                )}

                {searchResult.relationshipStatus === 'friends' && (
                  <MoonButton
                    type="button"
                    variant="secondary"
                    onClick={onNavigateFriends}
                    leftIcon={<UserCheck className="w-4 h-4 text-rose-300" />}
                  >
                    Already Friends · View
                  </MoonButton>
                )}

                {searchResult.relationshipStatus === 'pending_outgoing' && (
                  <MoonButton
                    type="button"
                    variant="secondary"
                    onClick={onNavigateRequests}
                    leftIcon={<Inbox className="w-4 h-4 text-rose-300" />}
                  >
                    Request Pending · View
                  </MoonButton>
                )}

                {searchResult.relationshipStatus === 'pending_incoming' && (
                  <MoonButton
                    type="button"
                    variant="primary"
                    onClick={onNavigateRequests}
                    leftIcon={<Inbox className="w-4 h-4" />}
                  >
                    Respond to Their Request
                  </MoonButton>
                )}
              </div>
            </div>
          </div>
        )}
      </form>

      {/* Live Friend System & RLS Verification Report (Requirement 10) */}
      <div className="rounded-3xl bg-black/55 border border-rose-500/30 p-5 space-y-4 shadow-[0_22px_55px_rgba(0,0,0,0.88)]">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-5 h-5 text-rose-300 shrink-0" />
            <div>
              <h3 className="font-display text-sm font-semibold text-white">
                Friend System Schema &amp; RLS Verification
              </h3>
              <p className="text-xs text-[#CBD5E1]">
                Tests your existing Supabase tables (<code className="font-mono text-rose-300">profiles</code>, <code className="font-mono text-rose-300">friend_requests</code>, <code className="font-mono text-rose-300">friendships</code>) and reports any missing columns or policies.
              </p>
            </div>
          </div>

          <MoonButton
            type="button"
            variant="secondary"
            isLoading={isRunningDiagnostics}
            onClick={handleRunDiagnostics}
            leftIcon={<RefreshCw className="w-4 h-4 text-rose-300" />}
          >
            Re-Test Flow
          </MoonButton>
        </div>

        {diagnosticReport && (
          <div className="space-y-3 pt-2 border-t border-[#2D142C]">
            {diagnosticReport.checks.map((item) => (
              <div
                key={item.id}
                className="rounded-2xl bg-[#040208]/95 border border-[#2D142C] p-3.5 space-y-2"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    {item.status === 'pass' ? (
                      <CheckCircle2 className="w-4 h-4 text-rose-400 shrink-0" />
                    ) : (
                      <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                    )}
                    <span className="text-xs font-semibold text-white">
                      {item.title}
                    </span>
                  </div>
                  <span className="text-[11px] font-mono text-[#A39BB5]">
                    {item.status.toUpperCase()}
                  </span>
                </div>

                <p className="text-xs text-[#CBD5E1] leading-relaxed pl-6">
                  {item.detail}
                </p>

                {item.sqlFix && (
                  <div className="pl-6 pt-1 space-y-1.5">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[11px] text-rose-300">
                        Recommended SQL if needed:
                      </span>
                      <CopyFeedbackButton
                        value={item.sqlFix}
                        label="Copy SQL"
                      />
                    </div>
                    <pre className="p-2.5 rounded-xl bg-black/90 border border-[#2D142C] text-[11px] font-mono text-rose-200 overflow-x-auto">
                      {item.sqlFix}
                    </pre>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
