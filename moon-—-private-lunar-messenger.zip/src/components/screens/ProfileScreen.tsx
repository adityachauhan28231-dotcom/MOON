import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Bookmark,
  Camera,
  Check,
  Code2,
  Copy,
  Database,
  Edit3,
  ExternalLink,
  Eye,
  Film,
  Globe,
  Grid,
  Heart,
  Lock,
  LogOut,
  MessageSquare,
  Play,
  Plus,
  RefreshCw,
  Save,
  Settings,
  Share2,
  ShieldCheck,
  Sparkles,
  Trash2,
  UserCheck,
  UserPlus,
  Users,
  X,
} from 'lucide-react';
import {
  AppScreen,
  FriendContact,
  FriendRequest,
  SupabaseReadinessStatus,
  UserProfile,
} from '../../types/moon';
import {
  generateFriendCode,
  getSupabaseReadinessStatus,
  PREPARED_SUPABASE_SQL_SCHEMA,
  updateUserProfileSupabase,
  verifySupabaseDatabaseConnection,
} from '../../services/supabaseAdapter';
import {
  CopyFeedbackButton,
  ErrorBanner,
  LunarAvatar,
  MoonButton,
  MoonInput,
} from '../ui/ReusablePrimitives';
import {
  CUSTOM_REELS_STORAGE_KEY,
  deduplicateReelsList,
  LIKED_REEL_ITEMS_STORAGE_KEY,
  LIKED_REELS_STORAGE_KEY,
  loadReelListFromStorage,
  MoonReelItem,
  parsePublicReelUrl,
  SAVED_REEL_ITEMS_STORAGE_KEY,
  saveReelListToStorage,
  VERIFIED_PUBLIC_REELS_CATALOG,
} from './MoonReelsScreen';

interface ProfileScreenProps {
  user: UserProfile;
  friends?: FriendContact[];
  friendRequests?: FriendRequest[];
  onUpdateUser: (updated: UserProfile) => void;
  onSignOut: () => void;
  onOpenReelInPlayer?: (embedCode: string) => void;
  onNavigateScreen?: (screen: AppScreen) => void;
  onSelectFriendChat?: (friendId: string) => void;
}

type ProfileTabId = 'liked' | 'saved' | 'settings';
type ConnectionsModalTab = 'friends' | 'followers' | 'following' | null;

interface MoonPrivacySettings {
  privateAccountRls: boolean;
  showOnlineStatus: boolean;
  readReceipts: boolean;
  allowReelShares: boolean;
  indiaFirstFeed: boolean;
}

const PROFILE_COVER_STORAGE_KEY = 'moon_profile_cover_theme_v1';
const PROFILE_PRIVACY_STORAGE_KEY = 'moon_profile_privacy_settings_v1';
const getAvatarPhotoStorageKey = (userId: string) =>
  `moon_profile_custom_avatar_v1_${userId}`;

const DEFAULT_PRIVACY_SETTINGS: MoonPrivacySettings = {
  privateAccountRls: true,
  showOnlineStatus: true,
  readReceipts: true,
  allowReelShares: true,
  indiaFirstFeed: true,
};

const COVER_THEMES: Array<{
  id: string;
  label: string;
  gradientClass: string;
  accentLabel: string;
}> = [
  {
    id: 'crimson-eclipse',
    label: 'Crimson Eclipse',
    accentLabel: 'AMOLED Black • Crimson • Violet',
    gradientClass:
      'bg-gradient-to-br from-[#05010A] via-[#4C0519] to-[#2E1065]',
  },
  {
    id: 'royal-violet',
    label: 'Violet Nebula',
    accentLabel: 'Obsidian • Royal Purple • Rose',
    gradientClass:
      'bg-gradient-to-br from-[#030106] via-[#3B0764] to-[#881337]',
  },
  {
    id: 'blood-moon',
    label: 'Blood Moon',
    accentLabel: 'Deep Black • Ruby Red • Plum',
    gradientClass:
      'bg-gradient-to-br from-[#090206] via-[#7F1D1D] to-[#1E0536]',
  },
  {
    id: 'obsidian-night',
    label: 'Obsidian AMOLED',
    accentLabel: 'Pure AMOLED Black • Subtle Rose Glow',
    gradientClass:
      'bg-gradient-to-br from-[#000000] via-[#190722] to-[#31081F]',
  },
];

const AVATAR_HUE_PRESETS = [345, 272, 320, 290, 15, 250];

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  user,
  friends = [],
  friendRequests = [],
  onUpdateUser,
  onSignOut,
  onOpenReelInPlayer,
  onNavigateScreen,
  onSelectFriendChat,
}) => {
  const [activeTab, setActiveTab] = useState<ProfileTabId>('liked');
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [isQuickEditingBio, setIsQuickEditingBio] = useState(false);
  const [connectionsModalTab, setConnectionsModalTab] =
    useState<ConnectionsModalTab>(null);

  // Editable Profile Fields
  const [username, setUsername] = useState(user.username);
  const [displayName, setDisplayName] = useState(user.displayName);
  const [bio, setBio] = useState(user.bio);
  const [avatarHue, setAvatarHue] = useState<number>(user.avatarHue || 345);
  const [customAvatarDataUrl, setCustomAvatarDataUrl] = useState<string | null>(
    () => {
      try {
        return localStorage.getItem(getAvatarPhotoStorageKey(user.id));
      } catch {
        return null;
      }
    }
  );
  const avatarFileInputRef = useRef<HTMLInputElement | null>(null);

  const [coverThemeId, setCoverThemeId] = useState<string>(() => {
    try {
      return (
        localStorage.getItem(PROFILE_COVER_STORAGE_KEY) || 'crimson-eclipse'
      );
    } catch {
      return 'crimson-eclipse';
    }
  });

  // Privacy Settings State
  const [privacySettings, setPrivacySettings] = useState<MoonPrivacySettings>(
    () => {
      try {
        const raw = localStorage.getItem(PROFILE_PRIVACY_STORAGE_KEY);
        if (!raw) return DEFAULT_PRIVACY_SETTINGS;
        return { ...DEFAULT_PRIVACY_SETTINGS, ...JSON.parse(raw) };
      } catch {
        return DEFAULT_PRIVACY_SETTINGS;
      }
    }
  );

  const [isSaving, setIsSaving] = useState(false);
  const [isSavingQuickBio, setIsSavingQuickBio] = useState(false);
  const [isRegeneratingCode, setIsRegeneratingCode] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [shareFeedback, setShareFeedback] = useState<string | null>(null);
  const [copiedCodeQuick, setCopiedCodeQuick] = useState(false);

  // Profile Video Collections (Synced with MoonReelsScreen via localStorage)
  const [likedReels, setLikedReels] = useState<MoonReelItem[]>([]);
  const [savedReels, setSavedReels] = useState<MoonReelItem[]>([]);
  const [newProfileReelUrl, setNewProfileReelUrl] = useState('');
  const [isAddingReelLink, setIsAddingReelLink] = useState(false);
  const [reelLinkFeedback, setReelLinkFeedback] = useState<string | null>(null);

  // Privacy & Settings States
  const [showSqlSchema, setShowSqlSchema] = useState(false);
  const [supabaseStatus, setSupabaseStatus] = useState<SupabaseReadinessStatus>(
    () => getSupabaseReadinessStatus()
  );
  const [isVerifyingDb, setIsVerifyingDb] = useState(false);

  // Sync local form fields when `user` prop updates
  useEffect(() => {
    setUsername(user.username);
    setDisplayName(user.displayName);
    setBio(user.bio);
    setAvatarHue(user.avatarHue || 345);
    try {
      setCustomAvatarDataUrl(
        localStorage.getItem(getAvatarPhotoStorageKey(user.id))
      );
    } catch {
      // Ignore
    }
  }, [user]);

  // Load Liked & Saved Reels from localStorage
  const refreshProfileReels = () => {
    const storedLikedItems = loadReelListFromStorage(
      LIKED_REEL_ITEMS_STORAGE_KEY
    );
    let likedMap: Record<string, boolean> = {};
    try {
      const raw = localStorage.getItem(LIKED_REELS_STORAGE_KEY);
      if (raw) likedMap = JSON.parse(raw);
    } catch {
      // Ignore
    }

    const catalogLiked = VERIFIED_PUBLIC_REELS_CATALOG.filter(
      (item) => likedMap[item.id]
    );
    const combinedLiked = deduplicateReelsList([
      ...storedLikedItems,
      ...catalogLiked,
    ]);
    setLikedReels(combinedLiked);

    const storedSaved = loadReelListFromStorage(SAVED_REEL_ITEMS_STORAGE_KEY);
    const storedCustom = loadReelListFromStorage(CUSTOM_REELS_STORAGE_KEY);
    setSavedReels(deduplicateReelsList([...storedSaved, ...storedCustom]));
  };

  useEffect(() => {
    refreshProfileReels();
  }, [activeTab]);

  const handleVerifyDb = async () => {
    setIsVerifyingDb(true);
    try {
      const status = await verifySupabaseDatabaseConnection();
      setSupabaseStatus(status);
    } finally {
      setIsVerifyingDb(false);
    }
  };

  useEffect(() => {
    void handleVerifyDb();
  }, []);

  const selectedCoverTheme = useMemo(
    () =>
      COVER_THEMES.find((t) => t.id === coverThemeId) || COVER_THEMES[0],
    [coverThemeId]
  );

  // Real statistics from user's MOON account & reels activity
  const incomingRequests = useMemo(
    () =>
      friendRequests.filter(
        (r) => r.direction === 'incoming' && r.status === 'pending'
      ),
    [friendRequests]
  );
  const outgoingRequests = useMemo(
    () =>
      friendRequests.filter(
        (r) => r.direction === 'outgoing' && r.status === 'pending'
      ),
    [friendRequests]
  );
  const followersCount = friends.length + incomingRequests.length;
  const followingCount = friends.length + outgoingRequests.length;

  const handleTogglePrivacySetting = (key: keyof MoonPrivacySettings) => {
    if (key === 'privateAccountRls') {
      // Friend-only RLS is always enforced at the database level
      return;
    }
    setPrivacySettings((prev) => {
      const next = { ...prev, [key]: !prev[key] };
      try {
        localStorage.setItem(PROFILE_PRIVACY_STORAGE_KEY, JSON.stringify(next));
      } catch {
        // Ignore
      }
      return next;
    });
  };

  const handleAvatarPhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setErrorMessage('Please select a valid image file for your profile photo.');
      return;
    }
    if (file.size > 4 * 1024 * 1024) {
      setErrorMessage('Profile photo must be smaller than 4 MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const result = typeof reader.result === 'string' ? reader.result : null;
      if (result) {
        setCustomAvatarDataUrl(result);
        try {
          localStorage.setItem(getAvatarPhotoStorageKey(user.id), result);
        } catch {
          // Ignore storage quota errors
        }
      }
    };
    reader.readAsDataURL(file);
  };

  const handleClearCustomAvatar = () => {
    setCustomAvatarDataUrl(null);
    try {
      localStorage.removeItem(getAvatarPhotoStorageKey(user.id));
    } catch {
      // Ignore
    }
  };

  const handleCycleCoverTheme = () => {
    const currentIndex = COVER_THEMES.findIndex((t) => t.id === coverThemeId);
    const nextTheme =
      COVER_THEMES[(currentIndex + 1) % COVER_THEMES.length] || COVER_THEMES[0];
    setCoverThemeId(nextTheme.id);
    try {
      localStorage.setItem(PROFILE_COVER_STORAGE_KEY, nextTheme.id);
    } catch {
      // Ignore
    }
  };

  const handleSaveQuickBio = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setIsSavingQuickBio(true);
    try {
      const updated = await updateUserProfileSupabase(user.id, {
        bio: bio.trim(),
      });
      onUpdateUser(updated);
      setIsQuickEditingBio(false);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 2500);
    } catch (err) {
      setErrorMessage(
        err instanceof Error ? err.message : 'Failed to update bio.'
      );
    } finally {
      setIsSavingQuickBio(false);
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSaveSuccess(false);

    const cleanUsername = username
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9_]/g, '');
    if (cleanUsername.length < 3) {
      setErrorMessage(
        'Username must be at least 3 characters using lowercase letters, numbers, or underscores.'
      );
      return;
    }

    if (!displayName.trim()) {
      setErrorMessage('Display name cannot be empty.');
      return;
    }

    setIsSaving(true);
    try {
      try {
        localStorage.setItem(PROFILE_COVER_STORAGE_KEY, coverThemeId);
      } catch {
        // Ignore
      }

      const updated = await updateUserProfileSupabase(user.id, {
        username: cleanUsername,
        displayName: displayName.trim(),
        bio: bio.trim(),
        avatarHue,
      });
      onUpdateUser(updated);
      setUsername(updated.username);
      setSaveSuccess(true);
      setIsEditingProfile(false);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err) {
      setErrorMessage(
        err instanceof Error ? err.message : 'Failed to update profile.'
      );
    } finally {
      setIsSaving(false);
    }
  };

  const handleRegenerateCode = async () => {
    setErrorMessage(null);
    setIsRegeneratingCode(true);
    try {
      const nextCode = generateFriendCode();
      const updated = await updateUserProfileSupabase(user.id, {
        friendCode: nextCode,
      });
      onUpdateUser(updated);
      setShareFeedback(`New MOON Friend Code generated: ${nextCode}`);
      setTimeout(() => setShareFeedback(null), 3000);
    } catch (err) {
      setErrorMessage(
        err instanceof Error ? err.message : 'Failed to regenerate friend code.'
      );
    } finally {
      setIsRegeneratingCode(false);
    }
  };

  const handleShareProfile = async () => {
    const shareText = `🌙 Connect with me on MOON — Private Lunar Messenger!\nDisplay Name: ${user.displayName} (@${user.username})\nMOON Friend Code: ${user.friendCode}`;
    try {
      if (typeof navigator !== 'undefined' && navigator.share) {
        await navigator.share({
          title: `${user.displayName} (@${user.username}) on MOON`,
          text: shareText,
          url: window.location.origin,
        });
        setShareFeedback('Profile shared successfully!');
      } else {
        await navigator.clipboard.writeText(shareText);
        setShareFeedback('Instagram-style MOON Profile invite copied!');
      }
    } catch {
      try {
        await navigator.clipboard.writeText(shareText);
        setShareFeedback('Profile invite copied to clipboard!');
      } catch {
        setShareFeedback(`Share your MOON Friend Code: ${user.friendCode}`);
      }
    }
    setTimeout(() => setShareFeedback(null), 2800);
  };

  const handleQuickCopyFriendCode = async () => {
    try {
      await navigator.clipboard.writeText(user.friendCode);
      setCopiedCodeQuick(true);
      setShareFeedback(`Copied MOON Friend Code: ${user.friendCode}`);
      setTimeout(() => {
        setCopiedCodeQuick(false);
        setShareFeedback(null);
      }, 2200);
    } catch {
      setShareFeedback(`MOON Friend Code: ${user.friendCode}`);
      setTimeout(() => setShareFeedback(null), 2200);
    }
  };

  const handleSavePublicReelLinkToProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setReelLinkFeedback(null);
    const parsed = parsePublicReelUrl(newProfileReelUrl);
    if (!parsed) {
      setReelLinkFeedback(
        'Paste a valid public YouTube Shorts (youtube.com/shorts/...) or Instagram Reel (instagram.com/reel/SHORTCODE/) link.'
      );
      return;
    }

    setIsAddingReelLink(true);
    let title =
      parsed.source === 'youtube'
        ? `YouTube Short (${parsed.embedCode})`
        : `Instagram Reel (${parsed.embedCode})`;
    let channelName =
      parsed.source === 'youtube' ? 'YouTube Creator' : 'Instagram Creator';
    let thumbnailUrl =
      parsed.source === 'youtube'
        ? `https://i.ytimg.com/vi/${parsed.embedCode}/hqdefault.jpg`
        : undefined;

    if (parsed.source === 'youtube') {
      try {
        const res = await fetch(
          `https://www.youtube.com/oembed?url=${encodeURIComponent(
            `https://www.youtube.com/watch?v=${parsed.embedCode}`
          )}&format=json`
        );
        if (res.ok) {
          const data = (await res.json()) as {
            title?: string;
            author_name?: string;
            thumbnail_url?: string;
          };
          if (data.title) title = data.title;
          if (data.author_name) channelName = data.author_name;
          if (data.thumbnail_url) thumbnailUrl = data.thumbnail_url;
        }
      } catch {
        // Proceed
      }
    }

    const newItem: MoonReelItem = {
      id: `profile-saved-${parsed.source}-${parsed.embedCode}-${Date.now()}`,
      source: parsed.source,
      embedCode: parsed.embedCode,
      title,
      channelName,
      channelHandle: `@${channelName.replace(/\s+/g, '').toLowerCase()}`,
      category:
        parsed.source === 'youtube' ? 'Saved YouTube Short' : 'Saved IG Reel',
      region: /[\u0900-\u097F]/.test(title) ? 'IN' : 'IN',
      originalUrl: parsed.canonicalUrl,
      thumbnailUrl,
      baseLikes: 1,
      isUserAdded: true,
    };

    const nextSaved = deduplicateReelsList([newItem, ...savedReels]);
    setSavedReels(nextSaved);
    saveReelListToStorage(SAVED_REEL_ITEMS_STORAGE_KEY, nextSaved);
    saveReelListToStorage(CUSTOM_REELS_STORAGE_KEY, [
      newItem,
      ...loadReelListFromStorage(CUSTOM_REELS_STORAGE_KEY),
    ]);
    setNewProfileReelUrl('');
    setIsAddingReelLink(false);
    setReelLinkFeedback(`Saved "${title}" to your Saved Reels grid!`);
  };

  const handleRemoveSavedReel = (embedCode: string) => {
    const next = savedReels.filter(
      (r) => r.embedCode.toLowerCase() !== embedCode.toLowerCase()
    );
    setSavedReels(next);
    saveReelListToStorage(SAVED_REEL_ITEMS_STORAGE_KEY, next);
  };

  const handleUnlikeReelFromProfile = (reel: MoonReelItem) => {
    const nextLikedList = likedReels.filter(
      (r) => r.embedCode.toLowerCase() !== reel.embedCode.toLowerCase()
    );
    setLikedReels(nextLikedList);
    saveReelListToStorage(LIKED_REEL_ITEMS_STORAGE_KEY, nextLikedList);

    try {
      const raw = localStorage.getItem(LIKED_REELS_STORAGE_KEY);
      if (raw) {
        const likedMap = JSON.parse(raw) as Record<string, boolean>;
        delete likedMap[reel.id];
        localStorage.setItem(LIKED_REELS_STORAGE_KEY, JSON.stringify(likedMap));
      }
    } catch {
      // Ignore
    }
  };

  // Displayed grid items for the active video tab (3-column Instagram grid)
  const displayedGridReels = useMemo(() => {
    if (activeTab === 'liked') {
      return likedReels.length > 0
        ? likedReels
        : VERIFIED_PUBLIC_REELS_CATALOG.slice(0, 6);
    }
    if (activeTab === 'saved') {
      return savedReels.length > 0
        ? savedReels
        : VERIFIED_PUBLIC_REELS_CATALOG.filter(
            (r) => r.source === 'instagram'
          ).slice(0, 6);
    }
    return [];
  }, [activeTab, likedReels, savedReels]);

  return (
    <div className="space-y-5 pb-12">
      {/* Hidden file input for optional custom circular profile photo */}
      <input
        ref={avatarFileInputRef}
        type="file"
        accept="image/*"
        onChange={handleAvatarPhotoChange}
        className="hidden"
      />

      {errorMessage && (
        <ErrorBanner
          title="Profile Update Error"
          message={errorMessage}
          onDismiss={() => setErrorMessage(null)}
        />
      )}

      {/* INSTAGRAM-STYLE PROFILE CONTAINER WITH AMOLED BLACK, RED & PURPLE COVER */}
      <div className="rounded-3xl bg-[#05010A]/95 border border-[#3B1738] overflow-hidden shadow-[0_24px_60px_rgba(0,0,0,0.95)]">
        {/* 2. COVER BACKGROUND WITH PREMIUM AMOLED BLACK, RED & PURPLE DESIGN */}
        <div
          className={`relative h-32 sm:h-40 w-full ${selectedCoverTheme.gradientClass} border-b border-rose-500/30 flex flex-col justify-between p-3.5 sm:p-5 overflow-hidden`}
        >
          {/* Layered AMOLED Lunar Eclipse Glows */}
          <div className="absolute -top-12 -right-10 w-52 h-52 rounded-full bg-rose-600/25 blur-3xl pointer-events-none" />
          <div className="absolute -bottom-14 left-1/4 w-60 h-40 rounded-full bg-violet-600/25 blur-3xl pointer-events-none" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_30%,rgba(225,29,72,0.22),transparent_55%),radial-gradient(circle_at_85%_70%,rgba(109,40,217,0.28),transparent_60%)] pointer-events-none" />

          {/* Top Bar inside Cover: Username Handle Pill + Cover Switcher + 8. Settings Icon + Sign Out */}
          <div className="relative z-10 flex items-center justify-between gap-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-black/75 backdrop-blur-md border border-rose-500/35 text-xs font-mono text-white shadow-lg">
              <Lock className="w-3 h-3 text-rose-400" />
              <span className="font-semibold">@{user.username}</span>
              <ShieldCheck className="w-3.5 h-3.5 text-rose-400" />
            </div>

            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={handleCycleCoverTheme}
                className="h-9 px-2.5 rounded-full bg-black/70 hover:bg-black/90 backdrop-blur-md border border-white/15 text-[11px] font-medium text-rose-200 inline-flex items-center gap-1.5 cursor-pointer transition-all active:scale-95"
                title="Switch AMOLED Cover Theme"
              >
                <Sparkles className="w-3.5 h-3.5 text-rose-400" />
                <span className="hidden sm:inline">
                  {selectedCoverTheme.label}
                </span>
              </button>

              {/* 8. SETTINGS ICON */}
              <button
                type="button"
                onClick={() =>
                  setActiveTab((prev) =>
                    prev === 'settings' ? 'liked' : 'settings'
                  )
                }
                className={`w-9 h-9 rounded-full backdrop-blur-md border flex items-center justify-center cursor-pointer transition-all active:scale-95 ${
                  activeTab === 'settings'
                    ? 'bg-gradient-to-r from-[#6D28D9] to-[#E11D48] border-rose-300 text-white shadow-[0_0_16px_rgba(225,29,72,0.6)]'
                    : 'bg-black/70 hover:bg-black/90 border-white/15 text-white'
                }`}
                aria-label="Profile Settings and Privacy"
                title="Settings & Privacy"
              >
                <Settings className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={onSignOut}
                className="w-9 h-9 rounded-full bg-black/70 hover:bg-rose-950/90 backdrop-blur-md border border-white/15 text-rose-300 flex items-center justify-center cursor-pointer transition-all active:scale-95"
                aria-label="Sign Out"
                title="Sign Out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Subtle bottom-right cover theme badge */}
          <div className="relative z-10 hidden sm:flex justify-end">
            <span className="px-2.5 py-0.5 rounded-full bg-black/60 backdrop-blur-md border border-white/10 text-[10px] text-[#CBD5E1]">
              {selectedCoverTheme.accentLabel}
            </span>
          </div>
        </div>

        {/* INSTAGRAM PROFILE HEADER BODY */}
        <div className="px-4 sm:px-6 pb-5">
          {/* ROW 1: 1. CIRCULAR PROFILE PHOTO WITH GRADIENT BORDER + 6. FRIENDS, FOLLOWERS & FOLLOWING COUNTERS */}
          <div className="flex items-end justify-between gap-3 sm:gap-6 -mt-11 sm:-mt-14 mb-4">
            {/* 1. Circular Profile Photo with Instagram-style Multi-Stop Gradient Ring */}
            <div className="relative shrink-0 group">
              <div className="p-[3px] rounded-full bg-gradient-to-tr from-[#F59E0B] via-[#E11D48] to-[#7C3AED] shadow-[0_0_30px_rgba(225,29,72,0.55)]">
                <div className="p-1 rounded-full bg-[#05010A]">
                  {customAvatarDataUrl ? (
                    <div className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-full overflow-hidden bg-black">
                      <img
                        src={customAvatarDataUrl}
                        alt={user.displayName}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  ) : (
                    <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full flex items-center justify-center overflow-hidden">
                      <LunarAvatar
                        name={user.displayName}
                        hue={avatarHue}
                        size="lg"
                        presence={
                          privacySettings.showOnlineStatus ? 'online' : 'offline'
                        }
                      />
                    </div>
                  )}
                </div>
              </div>

              {/* Camera button overlay on circular avatar */}
              <button
                type="button"
                onClick={() => avatarFileInputRef.current?.click()}
                className="absolute bottom-0.5 right-0.5 w-7 h-7 rounded-full bg-gradient-to-r from-[#6D28D9] to-[#E11D48] border-2 border-[#05010A] text-white flex items-center justify-center shadow-lg cursor-pointer hover:scale-105 active:scale-95 transition-transform"
                aria-label="Change Circular Profile Photo"
                title="Change Profile Photo"
              >
                <Camera className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* 6. Friends, Followers, and Following Counters (Instagram Layout) */}
            <div className="flex-1 grid grid-cols-3 gap-1.5 sm:gap-3 pt-12 sm:pt-14 text-center">
              <button
                type="button"
                onClick={() => setConnectionsModalTab('friends')}
                className="py-2 px-1.5 rounded-2xl bg-[#0B0414]/90 hover:bg-[#150826] border border-[#2D142C] hover:border-rose-500/40 transition-all cursor-pointer active:scale-95"
              >
                <p className="text-base sm:text-lg font-bold text-white leading-tight">
                  {friends.length}
                </p>
                <p className="text-[11px] sm:text-xs font-medium text-[#C8C2D8]">
                  Friends
                </p>
              </button>

              <button
                type="button"
                onClick={() => setConnectionsModalTab('followers')}
                className="py-2 px-1.5 rounded-2xl bg-[#0B0414]/90 hover:bg-[#150826] border border-[#2D142C] hover:border-rose-500/40 transition-all cursor-pointer active:scale-95"
              >
                <p className="text-base sm:text-lg font-bold text-white leading-tight">
                  {followersCount}
                </p>
                <p className="text-[11px] sm:text-xs font-medium text-[#C8C2D8]">
                  Followers
                </p>
              </button>

              <button
                type="button"
                onClick={() => setConnectionsModalTab('following')}
                className="py-2 px-1.5 rounded-2xl bg-[#0B0414]/90 hover:bg-[#150826] border border-[#2D142C] hover:border-rose-500/40 transition-all cursor-pointer active:scale-95"
              >
                <p className="text-base sm:text-lg font-bold text-white leading-tight">
                  {followingCount}
                </p>
                <p className="text-[11px] sm:text-xs font-medium text-[#C8C2D8]">
                  Following
                </p>
              </button>
            </div>
          </div>

          {/* ROW 2: 3. DISPLAY NAME AND USERNAME + 4. EDITABLE BIO + 12. FRIEND CODE */}
          <div className="space-y-2.5 mb-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <h2 className="font-display text-lg sm:text-xl font-bold text-white tracking-tight">
                    {user.displayName}
                  </h2>
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-rose-950/85 border border-rose-500/40 text-[10px] font-semibold text-rose-200">
                    <Sparkles className="w-2.5 h-2.5 text-rose-400" />
                    {user.isGuest ? 'Lunar Guest' : 'Verified Lunar Profile'}
                  </span>
                </div>
                <p className="text-xs sm:text-sm font-mono text-rose-300/95 mt-0.5">
                  @{user.username}
                </p>
              </div>

              {/* Activity & Reels Summary Pill */}
              <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-xl bg-[#0E0518] border border-[#2D142C] text-[11px] text-[#C8C2D8]">
                <Heart className="w-3 h-3 text-rose-400" />
                <span>{likedReels.length} Liked</span>
                <span className="text-white/30">•</span>
                <Bookmark className="w-3 h-3 text-violet-400" />
                <span>{savedReels.length} Saved</span>
              </div>
            </div>

            {/* 4. Editable Bio (with inline quick-edit button) */}
            {isQuickEditingBio ? (
              <form
                onSubmit={handleSaveQuickBio}
                className="p-3 rounded-2xl bg-[#0A0312] border border-rose-500/40 space-y-2"
              >
                <label className="block text-[11px] font-semibold uppercase tracking-wider text-rose-300">
                  Edit Profile Bio
                </label>
                <textarea
                  rows={2}
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  placeholder="Write your Instagram-style MOON bio..."
                  className="w-full rounded-xl bg-black border border-[#2D142C] focus:border-rose-500 px-3 py-2 text-xs sm:text-sm text-white placeholder:text-[#736B85] focus:outline-none"
                />
                <div className="flex items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setBio(user.bio);
                      setIsQuickEditingBio(false);
                    }}
                    className="px-3 py-1.5 rounded-xl bg-white/10 text-xs text-white cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSavingQuickBio}
                    className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-[#6D28D9] to-[#E11D48] text-xs font-semibold text-white inline-flex items-center gap-1 cursor-pointer disabled:opacity-50"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>{isSavingQuickBio ? 'Saving...' : 'Save Bio'}</span>
                  </button>
                </div>
              </form>
            ) : (
              <div className="group flex items-start justify-between gap-2 rounded-2xl bg-[#0A0312]/70 border border-[#241024] px-3.5 py-2.5">
                <p className="text-xs sm:text-sm text-[#E2E8F0] leading-relaxed whitespace-pre-line flex-1">
                  {user.bio ||
                    '🌙 Exploring India-First MOON Reels & private lunar messaging.'}
                </p>
                <button
                  type="button"
                  onClick={() => setIsQuickEditingBio(true)}
                  className="px-2 py-1 rounded-lg bg-white/5 hover:bg-rose-950/80 border border-white/10 text-[10px] font-medium text-rose-200 inline-flex items-center gap-1 shrink-0 cursor-pointer transition-colors"
                  title="Quick Edit Bio"
                >
                  <Edit3 className="w-3 h-3 text-rose-400" />
                  <span>Edit Bio</span>
                </button>
              </div>
            )}

            {/* 12. MOON Friend Code Pill & Quick Copy */}
            <div className="pt-0.5 flex flex-wrap items-center justify-between gap-2 p-2.5 rounded-2xl bg-gradient-to-r from-[#0D0418] via-[#17061C] to-[#0D0418] border border-rose-500/35">
              <div className="flex items-center gap-2 min-w-0">
                <span className="px-2 py-0.5 rounded-md bg-rose-950/90 border border-rose-500/40 text-[10px] font-bold uppercase tracking-wider text-rose-200">
                  MOON Code
                </span>
                <span className="font-mono text-xs sm:text-sm font-bold text-white select-all truncate">
                  {user.friendCode}
                </span>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={handleQuickCopyFriendCode}
                  className="px-2.5 py-1 rounded-xl bg-rose-600/90 hover:bg-rose-600 text-white text-[11px] font-semibold inline-flex items-center gap-1 cursor-pointer active:scale-95 transition-all"
                  title="Copy MOON Friend Code"
                >
                  {copiedCodeQuick ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-200" />
                      <span>Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy Code</span>
                    </>
                  )}
                </button>

                {onNavigateScreen && (
                  <button
                    type="button"
                    onClick={() => onNavigateScreen('add-friend')}
                    className="px-2.5 py-1 rounded-xl bg-[#1A0926] hover:bg-[#270D38] border border-violet-500/40 text-violet-200 text-[11px] font-semibold inline-flex items-center gap-1 cursor-pointer active:scale-95 transition-all"
                    title="Add a Friend by MOON Code"
                  >
                    <UserPlus className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Add Friend</span>
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* ROW 3: INSTAGRAM ACTION BUTTONS (5. Edit Profile • 7. Share Profile • 12. Copy MOON Friend Code) */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {/* 5. Edit Profile Button */}
            <button
              type="button"
              onClick={() => setIsEditingProfile((prev) => !prev)}
              className={`min-h-[42px] px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-all active:scale-98 ${
                isEditingProfile
                  ? 'bg-rose-600 text-white shadow-[0_0_16px_rgba(225,29,72,0.45)]'
                  : 'bg-gradient-to-r from-[#6D28D9] to-[#E11D48] text-white shadow-[0_0_16px_rgba(225,29,72,0.35)] hover:brightness-110'
              }`}
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>{isEditingProfile ? 'Close Editor' : 'Edit Profile'}</span>
            </button>

            {/* 7. Share Profile Button */}
            <button
              type="button"
              onClick={handleShareProfile}
              className="min-h-[42px] px-3.5 py-2 rounded-xl bg-[#14071E] hover:bg-[#1E0B2D] border border-[#3B1738] text-xs font-semibold text-white flex items-center justify-center gap-1.5 cursor-pointer transition-all active:scale-98"
            >
              <Share2 className="w-3.5 h-3.5 text-violet-300" />
              <span>Share Profile</span>
            </button>

            {/* 12. Copy MOON Friend Code Button */}
            <button
              type="button"
              onClick={handleQuickCopyFriendCode}
              className="col-span-2 sm:col-span-1 min-h-[42px] px-3.5 py-2 rounded-xl bg-[#14071E] hover:bg-[#1E0B2D] border border-rose-500/40 text-xs font-semibold text-rose-200 flex items-center justify-center gap-1.5 cursor-pointer transition-all active:scale-98"
            >
              {copiedCodeQuick ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-300">
                    Friend Code Copied!
                  </span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-rose-400" />
                  <span>Copy MOON Friend Code</span>
                </>
              )}
            </button>
          </div>

          {(shareFeedback || saveSuccess) && (
            <div className="mt-3 px-3.5 py-2 rounded-xl bg-emerald-950/85 border border-emerald-500/40 text-xs text-emerald-200 flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>
                {shareFeedback ||
                  'Profile changes saved to Supabase public.profiles!'}
              </span>
            </div>
          )}

          {/* EXPANDABLE EDIT PROFILE DRAWER */}
          {isEditingProfile && (
            <form
              onSubmit={handleSaveProfile}
              className="mt-5 pt-5 border-t border-[#2D142C] space-y-4 animate-[devilScreenFadeIn_180ms_ease-out]"
            >
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold uppercase tracking-wider text-rose-300 flex items-center gap-1.5">
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>Edit Instagram-Style MOON Profile</span>
                </h3>
                <button
                  type="button"
                  onClick={() => setIsEditingProfile(false)}
                  className="text-xs text-[#A39BB5] hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
              </div>

              {/* Circular Profile Photo Customization */}
              <div className="p-3 rounded-2xl bg-[#090312] border border-[#2D142C] flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="p-0.5 rounded-full bg-gradient-to-tr from-[#F59E0B] via-[#E11D48] to-[#7C3AED]">
                    {customAvatarDataUrl ? (
                      <img
                        src={customAvatarDataUrl}
                        alt={displayName}
                        className="w-12 h-12 rounded-full object-cover bg-black"
                      />
                    ) : (
                      <LunarAvatar
                        name={displayName || user.displayName}
                        hue={avatarHue}
                        size="md"
                      />
                    )}
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-white">
                      Circular Profile Photo &amp; Gradient Ring
                    </p>
                    <p className="text-[11px] text-[#8E8AA6]">
                      Upload a custom photo or pick a Lunar Aura color below.
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => avatarFileInputRef.current?.click()}
                    className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-[#6D28D9] to-[#E11D48] text-white text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    <Camera className="w-3.5 h-3.5" />
                    <span>Upload Photo</span>
                  </button>
                  {customAvatarDataUrl && (
                    <button
                      type="button"
                      onClick={handleClearCustomAvatar}
                      className="px-2.5 py-1.5 rounded-xl bg-white/10 hover:bg-rose-950/80 text-xs text-rose-200 cursor-pointer"
                    >
                      Use Lunar Avatar
                    </button>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <MoonInput
                  label="Username (@handle)"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="luna_wanderer"
                  hint="3–24 chars: lowercase letters, digits, underscores."
                />
                <MoonInput
                  label="Display Name"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  placeholder="Luna Wanderer"
                  hint="Shown on your profile, chats, and voice calls."
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-medium text-[#CBD5E1]">
                  Bio
                </label>
                <textarea
                  rows={3}
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  placeholder="🇮🇳 India-First Reels • Night owl architect & lunar minimalist."
                  className="w-full rounded-2xl bg-[#040107] border border-[#2D142C] focus:border-rose-500 px-3.5 py-2.5 text-xs sm:text-sm text-white placeholder:text-[#645C75] focus:outline-none"
                />
              </div>

              {/* Avatar Color Hue & Cover Banner Theme Pickers */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div className="space-y-1.5">
                  <span className="block text-xs font-medium text-[#CBD5E1]">
                    Avatar Aura Ring Color
                  </span>
                  <div className="flex items-center gap-2">
                    {AVATAR_HUE_PRESETS.map((hueVal) => (
                      <button
                        key={hueVal}
                        type="button"
                        onClick={() => setAvatarHue(hueVal)}
                        className={`w-8 h-8 rounded-full border-2 cursor-pointer transition-transform ${
                          avatarHue === hueVal
                            ? 'scale-110 border-white shadow-[0_0_12px_rgba(255,255,255,0.6)]'
                            : 'border-white/20 opacity-80'
                        }`}
                        style={{
                          background: `radial-gradient(circle at 30% 30%, hsl(${hueVal}, 82%, 60%), hsl(${hueVal}, 75%, 24%))`,
                        }}
                        aria-label={`Select avatar hue ${hueVal}`}
                      />
                    ))}
                  </div>
                </div>

                <div className="space-y-1.5">
                  <span className="block text-xs font-medium text-[#CBD5E1]">
                    AMOLED Cover Background Theme
                  </span>
                  <div className="grid grid-cols-2 gap-1.5">
                    {COVER_THEMES.map((theme) => (
                      <button
                        key={theme.id}
                        type="button"
                        onClick={() => setCoverThemeId(theme.id)}
                        className={`px-2.5 py-1.5 rounded-xl border text-[11px] font-medium text-left truncate cursor-pointer ${
                          coverThemeId === theme.id
                            ? 'border-rose-400 bg-rose-950/60 text-white'
                            : 'border-[#2D142C] bg-[#040107] text-[#A39BB5]'
                        }`}
                      >
                        {theme.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <MoonButton
                  type="button"
                  variant="secondary"
                  onClick={() => setIsEditingProfile(false)}
                >
                  Cancel
                </MoonButton>
                <MoonButton
                  type="submit"
                  variant="primary"
                  isLoading={isSaving}
                  leftIcon={<Save className="w-4 h-4" />}
                >
                  Save Profile
                </MoonButton>
              </div>
            </form>
          )}
        </div>

        {/* 10. LIKED REELS, SAVED REELS & 11. PRIVACY SETTINGS TABS BAR */}
        <div className="grid grid-cols-3 border-t border-[#2D142C] bg-[#040107]/95">
          <button
            type="button"
            onClick={() => setActiveTab('liked')}
            className={`min-h-[48px] flex items-center justify-center gap-1.5 text-xs font-semibold border-b-2 transition-all cursor-pointer ${
              activeTab === 'liked'
                ? 'border-rose-500 text-white bg-rose-950/25'
                : 'border-transparent text-[#8E8AA6] hover:text-white'
            }`}
          >
            <Grid className="w-4 h-4 text-rose-400" />
            <span>Liked Reels ({likedReels.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('saved')}
            className={`min-h-[48px] flex items-center justify-center gap-1.5 text-xs font-semibold border-b-2 transition-all cursor-pointer ${
              activeTab === 'saved'
                ? 'border-rose-500 text-white bg-rose-950/25'
                : 'border-transparent text-[#8E8AA6] hover:text-white'
            }`}
          >
            <Bookmark className="w-4 h-4 text-violet-400" />
            <span>Saved Reels ({savedReels.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('settings')}
            className={`min-h-[48px] flex items-center justify-center gap-1.5 text-xs font-semibold border-b-2 transition-all cursor-pointer ${
              activeTab === 'settings'
                ? 'border-rose-500 text-white bg-rose-950/25'
                : 'border-transparent text-[#8E8AA6] hover:text-white'
            }`}
          >
            <Settings className="w-4 h-4 text-rose-300" />
            <span>Settings</span>
          </button>
        </div>

        {/* TAB CONTENT SECTION */}
        <div className="p-3 sm:p-5 bg-[#030106]">
          {activeTab === 'liked' || activeTab === 'saved' ? (
            <div className="space-y-3.5">
              {/* Save Public Video Link Bar on Saved Tab */}
              {activeTab === 'saved' && (
                <form
                  onSubmit={handleSavePublicReelLinkToProfile}
                  className="p-3 rounded-2xl bg-[#08030F] border border-[#2D142C] space-y-2"
                >
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={newProfileReelUrl}
                      onChange={(e) => {
                        setNewProfileReelUrl(e.target.value);
                        if (reelLinkFeedback) setReelLinkFeedback(null);
                      }}
                      placeholder="Paste public YouTube Short or Instagram Reel link to save..."
                      className="flex-1 h-9 px-3 rounded-xl bg-black border border-[#2D142C] focus:border-rose-500 text-xs text-white placeholder:text-[#736B85] focus:outline-none"
                    />
                    <button
                      type="submit"
                      disabled={!newProfileReelUrl.trim() || isAddingReelLink}
                      className="h-9 px-3.5 rounded-xl bg-gradient-to-r from-[#6D28D9] to-[#E11D48] text-white text-xs font-semibold inline-flex items-center gap-1 disabled:opacity-45 cursor-pointer shrink-0"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>{isAddingReelLink ? 'Saving...' : 'Save Reel'}</span>
                    </button>
                  </div>
                  {reelLinkFeedback && (
                    <p className="text-[11px] text-rose-200 px-1">
                      {reelLinkFeedback}
                    </p>
                  )}
                </form>
              )}

              {activeTab === 'liked' && likedReels.length === 0 && (
                <div className="px-3 py-2 rounded-xl bg-[#0E0518] border border-[#2D142C] flex items-center justify-between gap-2 text-xs text-[#C8C2D8]">
                  <span>
                    Tap <Heart className="w-3.5 h-3.5 inline text-rose-400" /> on
                    any video in MOON Reels to add it to your Liked Reels grid.
                    Showing featured India-First Reels below:
                  </span>
                  {onNavigateScreen && (
                    <button
                      type="button"
                      onClick={() => onNavigateScreen('reels')}
                      className="px-2.5 py-1 rounded-lg bg-gradient-to-r from-[#6D28D9] to-[#E11D48] text-white text-[11px] font-semibold shrink-0 cursor-pointer"
                    >
                      Watch Reels
                    </button>
                  )}
                </div>
              )}

              {activeTab === 'saved' && savedReels.length === 0 && (
                <div className="px-3 py-2 rounded-xl bg-[#0E0518] border border-[#2D142C] flex items-center justify-between gap-2 text-xs text-[#C8C2D8]">
                  <span>
                    Tap{' '}
                    <Bookmark className="w-3.5 h-3.5 inline text-violet-400" />{' '}
                    on any Reel or paste a link above to build your Saved
                    collection. Showing featured Instagram Reels below:
                  </span>
                  {onNavigateScreen && (
                    <button
                      type="button"
                      onClick={() => onNavigateScreen('reels')}
                      className="px-2.5 py-1 rounded-lg bg-gradient-to-r from-[#6D28D9] to-[#C026D3] text-white text-[11px] font-semibold shrink-0 cursor-pointer"
                    >
                      Explore IG
                    </button>
                  )}
                </div>
              )}

              {/* 9. PROFILE CONTENT GRID WITH 3 COLUMNS (MOBILE & DESKTOP) */}
              <div className="grid grid-cols-3 gap-1.5 sm:gap-2.5">
                {displayedGridReels.map((item) => {
                  const thumb =
                    item.thumbnailUrl ||
                    (item.source === 'youtube'
                      ? `https://i.ytimg.com/vi/${item.embedCode}/hqdefault.jpg`
                      : undefined);
                  const isUserSavedItem =
                    activeTab === 'saved' &&
                    savedReels.some(
                      (r) =>
                        r.embedCode.toLowerCase() ===
                        item.embedCode.toLowerCase()
                    );
                  const isUserLikedItem =
                    activeTab === 'liked' &&
                    likedReels.some(
                      (r) =>
                        r.embedCode.toLowerCase() ===
                        item.embedCode.toLowerCase()
                    );

                  return (
                    <div
                      key={`${activeTab}-${item.source}-${item.embedCode}`}
                      className="group relative aspect-[9/16] rounded-xl sm:rounded-2xl overflow-hidden bg-[#0D0417] border border-[#2D142C] hover:border-rose-500/70 transition-all shadow-lg flex flex-col justify-between"
                    >
                      {thumb ? (
                        <img
                          src={thumb}
                          alt={item.title}
                          loading="lazy"
                          className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      ) : (
                        <div className="absolute inset-0 bg-gradient-to-br from-[#3B0764] via-[#4C0519] to-[#05010A] flex flex-col items-center justify-center p-2 text-center">
                          <Film className="w-6 h-6 sm:w-8 sm:h-8 text-fuchsia-300/80 mb-1" />
                          <span className="text-[9px] font-mono text-fuchsia-200/80 uppercase">
                            IG Reel
                          </span>
                        </div>
                      )}

                      <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/25 to-black/65 pointer-events-none" />

                      {/* Top Badges inside 3-Column Cell */}
                      <div className="relative z-10 p-1.5 sm:p-2 flex items-center justify-between gap-1">
                        <span
                          className={`px-1.5 py-0.5 rounded text-[8px] sm:text-[9px] font-bold uppercase tracking-tight border ${
                            item.source === 'instagram'
                              ? 'bg-fuchsia-950/85 border-fuchsia-400/40 text-fuchsia-200'
                              : 'bg-rose-950/85 border-rose-400/40 text-rose-200'
                          }`}
                        >
                          {item.source === 'youtube' ? 'YT' : 'IG'}
                        </span>

                        {isUserSavedItem && (
                          <button
                            type="button"
                            onClick={() => handleRemoveSavedReel(item.embedCode)}
                            className="w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-black/80 hover:bg-rose-600 text-white flex items-center justify-center cursor-pointer"
                            title="Remove from Saved Reels"
                          >
                            <Trash2 className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                          </button>
                        )}

                        {isUserLikedItem && (
                          <button
                            type="button"
                            onClick={() => handleUnlikeReelFromProfile(item)}
                            className="w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-rose-600/90 hover:bg-black/80 text-white flex items-center justify-center cursor-pointer"
                            title="Unlike Reel"
                          >
                            <Heart className="w-2.5 h-2.5 sm:w-3 sm:h-3 fill-current" />
                          </button>
                        )}
                      </div>

                      {/* Center Play Button */}
                      <button
                        type="button"
                        onClick={() => {
                          if (onOpenReelInPlayer) {
                            onOpenReelInPlayer(item.embedCode);
                          } else if (onNavigateScreen) {
                            onNavigateScreen('reels');
                          }
                        }}
                        className="relative z-10 m-auto w-9 h-9 sm:w-11 sm:h-11 rounded-full bg-black/75 group-hover:bg-gradient-to-r group-hover:from-[#6D28D9] group-hover:to-[#E11D48] border border-white/25 text-white flex items-center justify-center shadow-xl transition-all cursor-pointer active:scale-90"
                        aria-label={`Play ${item.title} in MOON Reels`}
                      >
                        <Play className="w-3.5 h-3.5 sm:w-4 sm:h-4 fill-current ml-0.5" />
                      </button>

                      {/* Bottom Metadata Overlay */}
                      <div className="relative z-10 p-1.5 sm:p-2.5 space-y-0.5">
                        <p className="text-[10px] sm:text-[11px] font-semibold text-white line-clamp-1 sm:line-clamp-2 leading-tight">
                          {item.title}
                        </p>
                        <div className="flex items-center justify-between gap-1 text-[9px] sm:text-[10px] text-[#CBD5E1]">
                          <span className="inline-flex items-center gap-0.5 truncate">
                            <Heart className="w-2.5 h-2.5 text-rose-400 fill-current shrink-0" />
                            <span>{item.baseLikes}</span>
                          </span>
                          <a
                            href={item.originalUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-rose-300 hover:text-white shrink-0"
                            title="Open original video link"
                          >
                            <ExternalLink className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                          </a>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            /* 11. PRIVACY SETTINGS, APP CREATOR, ABOUT APP & SUPABASE RLS INSPECTOR */
            <div className="space-y-4">
              {/* Global App Creator Banner in Settings */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-[#0B0318] via-[#1E0836] to-[#2A0621] border border-fuchsia-500/45 shadow-[0_0_24px_rgba(192,38,211,0.22)] flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-black/80 border border-fuchsia-400/50 flex items-center justify-center shadow-[0_0_16px_rgba(236,72,153,0.4)] shrink-0">
                    <Sparkles className="w-5 h-5 text-fuchsia-300" />
                  </div>
                  <div>
                    <p className="text-xs sm:text-sm font-bold text-white tracking-wide">
                      App Creator — Aditya Chauhan
                    </p>
                    <p className="text-[11px] text-fuchsia-200/90 mt-0.5">
                      Founder &amp; Creator: Aditya Chauhan • MOON Private Lunar Messenger
                    </p>
                  </div>
                </div>
                <span className="px-2.5 py-1 rounded-full bg-fuchsia-950/90 border border-fuchsia-400/45 text-[10px] font-bold uppercase tracking-wider text-fuchsia-200">
                  Official Creator
                </span>
              </div>

              {/* Interactive Privacy Controls Card */}
              <div className="p-4 rounded-2xl bg-[#08030F] border border-[#2D142C] space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-rose-300 flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5" />
                    <span>Privacy &amp; Security Settings</span>
                  </h3>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-950/90 border border-emerald-500/40 text-[10px] font-semibold text-emerald-200">
                    Protected
                  </span>
                </div>

                <div className="space-y-2.5 text-xs">
                  {/* Friend-Only Private Messaging (RLS Enforced) */}
                  <div className="flex items-center justify-between gap-3 p-3 rounded-xl bg-black/60 border border-[#241023]">
                    <div className="flex items-start gap-2.5">
                      <UserCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <div>
                        <p className="font-semibold text-white">
                          Friend-Only Private Messaging &amp; Voice Calls
                        </p>
                        <p className="text-[11px] text-[#8E8AA6]">
                          Only accepted friends in Supabase{' '}
                          <span className="font-mono text-rose-200">
                            public.friendships
                          </span>{' '}
                          can message, share locations, or call you.
                        </p>
                      </div>
                    </div>
                    <span className="px-2.5 py-1 rounded-full bg-emerald-950 border border-emerald-500/40 text-[10px] font-semibold text-emerald-200 shrink-0">
                      RLS Enforced
                    </span>
                  </div>

                  {/* Online Presence Toggle */}
                  <div className="flex items-center justify-between gap-3 p-3 rounded-xl bg-black/60 border border-[#241023]">
                    <div className="flex items-start gap-2.5">
                      <Eye className="w-4 h-4 text-violet-400 shrink-0 mt-0.5" />
                      <div>
                        <p className="font-semibold text-white">
                          Activity &amp; Online Presence Status
                        </p>
                        <p className="text-[11px] text-[#8E8AA6]">
                          Show the green active ring on your circular profile
                          avatar when online.
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() =>
                        handleTogglePrivacySetting('showOnlineStatus')
                      }
                      className={`px-3 py-1 rounded-full text-[11px] font-semibold border cursor-pointer transition-colors shrink-0 ${
                        privacySettings.showOnlineStatus
                          ? 'bg-emerald-950/90 border-emerald-500/40 text-emerald-200'
                          : 'bg-white/5 border-white/15 text-[#8E8AA6]'
                      }`}
                    >
                      {privacySettings.showOnlineStatus ? 'Active' : 'Hidden'}
                    </button>
                  </div>

                  {/* Read Receipts Toggle */}
                  <div className="flex items-center justify-between gap-3 p-3 rounded-xl bg-black/60 border border-[#241023]">
                    <div className="flex items-start gap-2.5">
                      <MessageSquare className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                      <div>
                        <p className="font-semibold text-white">
                          Private Chat Read Receipts
                        </p>
                        <p className="text-[11px] text-[#8E8AA6]">
                          Allow accepted friends to see when you have viewed
                          their messages.
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleTogglePrivacySetting('readReceipts')}
                      className={`px-3 py-1 rounded-full text-[11px] font-semibold border cursor-pointer transition-colors shrink-0 ${
                        privacySettings.readReceipts
                          ? 'bg-rose-950/90 border-rose-500/40 text-rose-200'
                          : 'bg-white/5 border-white/15 text-[#8E8AA6]'
                      }`}
                    >
                      {privacySettings.readReceipts ? 'Enabled' : 'Disabled'}
                    </button>
                  </div>

                  {/* India-First Reels Feed Preference */}
                  <div className="flex items-center justify-between gap-3 p-3 rounded-xl bg-black/60 border border-[#241023]">
                    <div className="flex items-start gap-2.5">
                      <Globe className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                      <div>
                        <p className="font-semibold text-white">
                          MOON Reels India-First Priority
                        </p>
                        <p className="text-[11px] text-[#8E8AA6]">
                          Prioritizes 80% Indian Reels (Hindi, Bhojpuri, Comedy,
                          Bollywood, Gaming) &amp; 20% Global.
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() =>
                        handleTogglePrivacySetting('indiaFirstFeed')
                      }
                      className={`px-3 py-1 rounded-full text-[11px] font-semibold border cursor-pointer transition-colors shrink-0 ${
                        privacySettings.indiaFirstFeed
                          ? 'bg-rose-950/90 border-rose-500/40 text-rose-200'
                          : 'bg-white/5 border-white/15 text-[#8E8AA6]'
                      }`}
                    >
                      {privacySettings.indiaFirstFeed
                        ? '🇮🇳 80% India'
                        : 'Global Mix'}
                    </button>
                  </div>

                  {/* Rotate Unique Friend Code */}
                  <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-xl bg-black/60 border border-[#241023]">
                    <div>
                      <p className="font-semibold text-white">
                        Rotate Unique MOON Friend Code ({user.friendCode})
                      </p>
                      <p className="text-[11px] text-[#8E8AA6]">
                        Generate a new Friend Code to prevent unwanted friend
                        requests.
                      </p>
                    </div>
                    <MoonButton
                      type="button"
                      variant="secondary"
                      isLoading={isRegeneratingCode}
                      onClick={handleRegenerateCode}
                      leftIcon={
                        <RefreshCw className="w-3.5 h-3.5 text-rose-300" />
                      }
                    >
                      Regenerate Code
                    </MoonButton>
                  </div>
                </div>
              </div>

              {/* Supabase Live Connection & RLS Inspector */}
              <div className="p-4 rounded-2xl bg-[#08030F] border border-[#2D142C] space-y-3">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="flex items-start gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-[#160A24] border border-rose-500/30 flex items-center justify-center shrink-0">
                      <Database className="w-4 h-4 text-rose-300" />
                    </div>
                    <div>
                      <h3 className="text-sm font-semibold text-white">
                        Supabase Database &amp; RLS Verification
                      </h3>
                      <p className="text-[11px] text-[#CBD5E1]">
                        {supabaseStatus.modeLabel}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <MoonButton
                      type="button"
                      variant="secondary"
                      isLoading={isVerifyingDb}
                      onClick={handleVerifyDb}
                      leftIcon={
                        <RefreshCw className="w-3.5 h-3.5 text-rose-300" />
                      }
                    >
                      Verify
                    </MoonButton>
                    <MoonButton
                      type="button"
                      variant="secondary"
                      onClick={() => setShowSqlSchema((prev) => !prev)}
                      leftIcon={<Code2 className="w-3.5 h-3.5 text-rose-300" />}
                    >
                      {showSqlSchema ? 'Hide SQL' : 'RLS SQL'}
                    </MoonButton>
                  </div>
                </div>

                <div className="text-xs text-[#CBD5E1] space-y-1.5 pt-2 border-t border-[#241023]">
                  <p className="flex items-center gap-2 text-rose-200 font-medium">
                    <ShieldCheck className="w-4 h-4 text-rose-400 shrink-0" />
                    <span>{supabaseStatus.securityNote}</span>
                  </p>
                  <p className="text-[11px] text-[#A39BB5]">
                    Connected tables:{' '}
                    <span className="font-mono text-white">
                      {supabaseStatus.tablesPrepared.join(' · ')}
                    </span>
                  </p>
                </div>

                {showSqlSchema && (
                  <div className="space-y-2 pt-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] text-[#A39BB5]">
                        PostgreSQL DDL &amp; Row Level Security Policies:
                      </span>
                      <CopyFeedbackButton
                        value={PREPARED_SUPABASE_SQL_SCHEMA}
                        label="Copy SQL Script"
                      />
                    </div>
                    <pre className="p-3 rounded-xl bg-black/90 border border-[#2D142C] text-[11px] font-mono text-rose-200 overflow-x-auto leading-relaxed max-h-64">
                      {PREPARED_SUPABASE_SQL_SCHEMA}
                    </pre>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* GLOBAL ABOUT APP SECTION — ALWAYS VISIBLE TO ALL USERS */}
      <div className="rounded-3xl bg-gradient-to-br from-[#07020F]/95 via-[#120522]/95 to-[#1F061E]/95 border border-fuchsia-500/40 p-4 sm:p-5 shadow-[0_18px_45px_rgba(0,0,0,0.9),0_0_24px_rgba(168,85,247,0.2)] space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#2D142C] pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#1A062E] border border-fuchsia-500/45 flex items-center justify-center shadow-[0_0_14px_rgba(217,70,239,0.35)]">
              <Sparkles className="w-4 h-4 text-fuchsia-300" />
            </div>
            <div>
              <h3 className="text-xs sm:text-sm font-bold uppercase tracking-wider text-white">
                About App • MOON
              </h3>
              <p className="text-[11px] text-fuchsia-200/90">
                MOON — Private Lunar Messenger (AMOLED Edition)
              </p>
            </div>
          </div>
          <span className="px-2.5 py-1 rounded-full bg-[#1C0730] border border-fuchsia-400/45 text-[10px] font-bold text-fuchsia-200 shadow-[0_0_12px_rgba(192,38,211,0.3)]">
            MOON • Aditya Chauhan
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
          <div className="p-3 rounded-2xl bg-black/65 border border-fuchsia-500/30 space-y-1">
            <p className="text-[10px] font-bold uppercase tracking-wider text-fuchsia-300">
              About App
            </p>
            <p className="font-bold text-white text-xs sm:text-sm">
              Founder &amp; Creator: Aditya Chauhan
            </p>
            <p className="text-[11px] text-[#C8C2D8]">
              Created by Aditya Chauhan • Global India-First News, Traders Hub, Reels &amp; Private Lunar Messaging.
            </p>
          </div>

          <div className="p-3 rounded-2xl bg-black/65 border border-rose-500/30 space-y-1">
            <p className="text-[10px] font-bold uppercase tracking-wider text-rose-300">
              Settings &amp; Attribution
            </p>
            <p className="font-bold text-white text-xs sm:text-sm">
              App Creator — Aditya Chauhan
            </p>
            <p className="text-[11px] text-[#C8C2D8]">
              Secured with Supabase Auth, Friend-Only Row Level Security (RLS), and LiveKit Voice Calling.
            </p>
          </div>
        </div>
      </div>

      {/* INSTAGRAM-STYLE FRIENDS / FOLLOWERS / FOLLOWING CONNECTIONS MODAL */}
      {connectionsModalTab && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Profile Connections"
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4"
        >
          <div className="w-full max-w-md rounded-3xl bg-[#07030D] border border-[#3B1738] shadow-[0_24px_60px_rgba(0,0,0,0.95)] overflow-hidden">
            <div className="px-4 py-3.5 border-b border-[#2D142C] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-rose-400" />
                <h3 className="text-sm font-bold text-white capitalize">
                  @{user.username} • {connectionsModalTab}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setConnectionsModalTab(null)}
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center cursor-pointer"
                aria-label="Close modal"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Sub-tabs */}
            <div className="grid grid-cols-3 border-b border-[#2D142C] bg-[#040107]">
              {(['friends', 'followers', 'following'] as const).map((tab) => (
                <button
                  key={tab}
                  type="button"
                  onClick={() => setConnectionsModalTab(tab)}
                  className={`py-2.5 text-xs font-semibold capitalize border-b-2 cursor-pointer ${
                    connectionsModalTab === tab
                      ? 'border-rose-500 text-white bg-rose-950/20'
                      : 'border-transparent text-[#8E8AA6] hover:text-white'
                  }`}
                >
                  {tab === 'friends'
                    ? `Friends (${friends.length})`
                    : tab === 'followers'
                    ? `Followers (${followersCount})`
                    : `Following (${followingCount})`}
                </button>
              ))}
            </div>

            <div className="p-4 max-h-80 overflow-y-auto space-y-2.5">
              {friends.length === 0 &&
              incomingRequests.length === 0 &&
              outgoingRequests.length === 0 ? (
                <div className="py-8 text-center space-y-2">
                  <Users className="w-8 h-8 text-rose-400/60 mx-auto" />
                  <p className="text-xs font-semibold text-white">
                    No connections yet
                  </p>
                  <p className="text-[11px] text-[#8E8AA6]">
                    Share your MOON Friend Code ({user.friendCode}) to connect
                    with friends.
                  </p>
                </div>
              ) : (
                <>
                  {friends.map((friend) => (
                    <div
                      key={friend.id}
                      className="flex items-center justify-between gap-3 p-2.5 rounded-2xl bg-[#0D0517] border border-[#2D142C]"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <LunarAvatar
                          name={friend.displayName}
                          hue={friend.avatarHue}
                          size="sm"
                          presence={friend.presence}
                        />
                        <div className="min-w-0">
                          <p className="text-xs font-semibold text-white truncate">
                            {friend.displayName}
                          </p>
                          <p className="text-[11px] font-mono text-[#A39BB5] truncate">
                            @{friend.username}
                          </p>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => {
                          setConnectionsModalTab(null);
                          if (onSelectFriendChat) {
                            onSelectFriendChat(friend.id);
                          } else if (onNavigateScreen) {
                            onNavigateScreen('friends');
                          }
                        }}
                        className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-[#6D28D9] to-[#E11D48] text-white text-[11px] font-semibold cursor-pointer shrink-0"
                      >
                        Message
                      </button>
                    </div>
                  ))}

                  {connectionsModalTab === 'followers' &&
                    incomingRequests.map((req) => (
                      <div
                        key={req.id}
                        className="flex items-center justify-between gap-3 p-2.5 rounded-2xl bg-[#0D0517] border border-rose-500/35"
                      >
                        <div className="min-w-0">
                          <p className="text-xs font-semibold text-white truncate">
                            {req.fromUser.displayName}
                          </p>
                          <p className="text-[11px] font-mono text-rose-300 truncate">
                            @{req.fromUser.username} • Pending Follower
                          </p>
                        </div>
                        {onNavigateScreen && (
                          <button
                            type="button"
                            onClick={() => {
                              setConnectionsModalTab(null);
                              onNavigateScreen('requests');
                            }}
                            className="px-2.5 py-1 rounded-xl bg-rose-600 text-white text-[11px] font-semibold cursor-pointer"
                          >
                            Review
                          </button>
                        )}
                      </div>
                    ))}

                  {connectionsModalTab === 'following' &&
                    outgoingRequests.map((req) => (
                      <div
                        key={req.id}
                        className="flex items-center justify-between gap-3 p-2.5 rounded-2xl bg-[#0D0517] border border-violet-500/35"
                      >
                        <div className="min-w-0">
                          <p className="text-xs font-semibold text-white truncate">
                            {req.fromUser.displayName}
                          </p>
                          <p className="text-[11px] font-mono text-violet-300 truncate">
                            @{req.fromUser.username} • Requested
                          </p>
                        </div>
                        <span className="px-2.5 py-1 rounded-xl bg-white/10 text-[10px] text-[#C8C2D8]">
                          Pending
                        </span>
                      </div>
                    ))}
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
