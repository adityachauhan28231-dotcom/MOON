import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  Code2,
  Database,
  Eye,
  EyeOff,
  Lock,
  Mail,
  RefreshCw,
  Sparkles,
  User,
  UserCheck,
} from 'lucide-react';
import {
  AuthMode,
  SupabaseReadinessStatus,
  UserProfile,
} from '../../types/moon';
import {
  getSupabaseReadinessStatus,
  PREPARED_SUPABASE_SQL_SCHEMA,
  signInAsGuestSupabase,
  signInWithEmailSupabase,
  signUpWithEmailSupabase,
  verifySupabaseDatabaseConnection,
} from '../../services/supabaseAdapter';
import { MoonLogo } from '../ui/MoonLogo';
import {
  CopyFeedbackButton,
  ErrorBanner,
  MoonButton,
  MoonInput,
} from '../ui/ReusablePrimitives';
import { PWAInstallButton } from '../ui/PWAInstallButton';
import { DevilNightSkyBackground } from '../ui/DevilNightSkyBackground';

interface WelcomeAuthScreenProps {
  onAuthenticated: (profile: UserProfile) => void;
  initialError?: string | null;
}

export const WelcomeAuthScreen: React.FC<WelcomeAuthScreenProps> = ({
  onAuthenticated,
  initialError = null,
}) => {
  const [authMode, setAuthMode] = useState<AuthMode>('welcome');
  const [guestUsername, setGuestUsername] = useState('luna_wanderer');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [signupUsername, setSignupUsername] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const [isLoadingGuest, setIsLoadingGuest] = useState(false);
  const [isLoadingEmail, setIsLoadingEmail] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(initialError);
  const [infoNotice, setInfoNotice] = useState<string | null>(null);

  const [dbStatus, setDbStatus] = useState<SupabaseReadinessStatus>(() =>
    getSupabaseReadinessStatus()
  );
  const [isCheckingDb, setIsCheckingDb] = useState(false);
  const [showSqlModal, setShowSqlModal] = useState(false);

  const runConnectionCheck = async () => {
    setIsCheckingDb(true);
    try {
      const result = await verifySupabaseDatabaseConnection();
      setDbStatus(result);
    } finally {
      setIsCheckingDb(false);
    }
  };

  useEffect(() => {
    if (dbStatus.envConfigured) {
      runConnectionCheck();
    }
  }, [dbStatus.envConfigured]);

  const handleContinueAsGuest = async () => {
    setErrorMessage(null);
    setInfoNotice(null);
    setIsLoadingGuest(true);
    try {
      const profile = await signInAsGuestSupabase(guestUsername);
      onAuthenticated(profile);
    } catch (err) {
      setErrorMessage(
        err instanceof Error
          ? err.message
          : 'Could not sign in anonymously with Supabase.'
      );
    } finally {
      setIsLoadingGuest(false);
    }
  };

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setInfoNotice(null);

    const trimmedEmail = email.trim();
    if (!trimmedEmail || !trimmedEmail.includes('@')) {
      setErrorMessage(
        'Please enter a valid email address (for example, name@domain.com).'
      );
      return;
    }

    if (password.length < 6) {
      setErrorMessage('Password must be at least 6 characters long.');
      return;
    }

    if (authMode === 'signup') {
      const cleanHandle = signupUsername.trim().replace(/[^a-zA-Z0-9_]/g, '');
      if (cleanHandle.length < 3) {
        setErrorMessage(
          'Username must be at least 3 characters (letters, numbers, or underscores).'
        );
        return;
      }
    }

    setIsLoadingEmail(true);
    try {
      if (authMode === 'signup') {
        const { profile, confirmationRequired } = await signUpWithEmailSupabase({
          email: trimmedEmail,
          password,
          username: signupUsername,
        });
        if (confirmationRequired || !profile) {
          setInfoNotice(
            'Account created! Please check your email inbox to confirm your address, then switch to Email Login.'
          );
          setAuthMode('login');
        } else {
          onAuthenticated(profile);
        }
      } else {
        const profile = await signInWithEmailSupabase({
          email: trimmedEmail,
          password,
        });
        onAuthenticated(profile);
      }
    } catch (err) {
      setErrorMessage(
        err instanceof Error ? err.message : 'Authentication failed.'
      );
    } finally {
      setIsLoadingEmail(false);
    }
  };

  return (
    <div className="min-h-screen w-full bg-black text-[#F8FAFC] flex flex-col justify-between relative overflow-hidden">
      {/* Realistic Animated Devil Night Moon Atmospheric Sky */}
      <DevilNightSkyBackground />

      {/* Top Bar Contract: Brand wordmark — Screen mode links — Guest quick action */}
      <header className="relative z-10 w-full max-w-6xl mx-auto flex items-center justify-between gap-8 px-5 py-4 border-b border-[#2D142C]/80 bg-[#050208]/75 backdrop-blur-md">
        <MoonLogo size="sm" showWordmark headerCreatorBadge />

        <nav className="hidden sm:flex items-center gap-6 text-xs font-medium text-[#A39BB5]">
          <button
            type="button"
            onClick={() => {
              setAuthMode('welcome');
              setErrorMessage(null);
            }}
            className={`hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              authMode === 'welcome' ? 'text-rose-300' : ''
            }`}
          >
            Guest Access
          </button>
          <button
            type="button"
            onClick={() => {
              setAuthMode('login');
              setErrorMessage(null);
            }}
            className={`hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              authMode === 'login' ? 'text-rose-300' : ''
            }`}
          >
            Email Login
          </button>
          <button
            type="button"
            onClick={() => {
              setAuthMode('signup');
              setErrorMessage(null);
            }}
            className={`hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              authMode === 'signup' ? 'text-rose-300' : ''
            }`}
          >
            Create Account
          </button>
          <button
            type="button"
            onClick={() => setShowSqlModal((prev) => !prev)}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            RLS &amp; SQL Schema
          </button>
        </nav>

        <div className="flex items-center gap-2 shrink-0">
          <PWAInstallButton />
          <MoonButton
            type="button"
            variant="secondary"
            onClick={handleContinueAsGuest}
            isLoading={isLoadingGuest}
          >
            Continue as Guest
          </MoonButton>
        </div>
      </header>

      {/* Main Content Container */}
      <main className="relative z-10 flex-1 w-full max-w-6xl mx-auto px-5 py-8 md:py-12 flex items-center devil-screen-transition">
        <div className="w-full grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-start">
          {/* Left Column: MOON Brand Identity & Live Supabase Connection Status */}
          <div className="lg:col-span-6 space-y-6 text-center lg:text-left">
            <div className="inline-flex flex-col items-center lg:items-start gap-3">
              <div className="flex flex-col items-center lg:items-start gap-2.5">
                <div className="inline-flex items-center gap-4">
                  <MoonLogo size="xl" />
                  <div className="text-left">
                    <div className="font-display text-3xl sm:text-4xl font-extrabold tracking-[0.16em] bg-gradient-to-r from-[#F8FAFC] via-[#FECDD3] to-[#C4B5FD] bg-clip-text text-transparent">
                      MOON
                    </div>
                    <p className="text-xs font-medium text-[#C4B5FD] tracking-wide mt-0.5">
                      Private Lunar Messenger
                    </p>
                  </div>
                </div>
                <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-gradient-to-r from-[#1A0533]/95 via-[#3B0764]/85 to-[#4C0519]/90 border border-fuchsia-500/45 text-xs font-semibold text-fuchsia-200 shadow-[0_0_24px_rgba(192,38,211,0.35)]">
                  <Sparkles className="w-3.5 h-3.5 text-fuchsia-400 shrink-0" />
                  <span>Created by Aditya Chauhan</span>
                </div>
              </div>
              <div className="text-xs text-[#C4B5FD] tracking-wide">
                <span>MOON • Aditya Chauhan</span>
                <span className="mx-2 text-rose-400" aria-hidden="true">
                  ·
                </span>
                <span>Devil Blood Moon Edition</span>
                <span className="mx-2 text-rose-400" aria-hidden="true">
                  ·
                </span>
                <span>Friend-Only RLS</span>
              </div>
            </div>

            <h1
              className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-white leading-[1.12] drop-shadow-[0_4px_24px_rgba(0,0,0,0.9)]"
              style={{ textWrap: 'balance' }}
            >
              Quiet, direct one-to-one messaging built for the crimson night.
            </h1>

            <p className="text-sm sm:text-base text-[#CBD5E1] leading-relaxed max-w-xl mx-auto lg:mx-0">
              Connect exclusively through unique{' '}
              <span className="font-mono text-rose-300">MOON-XXXX-XX</span>{' '}
              friend codes. Powered by Supabase Anonymous Auth, Email Auth, Realtime Postgres channels, and strict friend-only Row Level Security.
            </p>

            {/* Live Supabase Environment & Schema Verification Card */}
            <div className="rounded-2xl bg-[#07030C]/85 backdrop-blur-md border border-[#2D142C] p-4 sm:p-5 text-left space-y-3 shadow-[0_18px_45px_rgba(0,0,0,0.85)]">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <Database className="w-4 h-4 text-rose-400 shrink-0" />
                  <span className="text-xs font-semibold text-white">
                    Supabase Project Connection Status
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={runConnectionCheck}
                    disabled={isCheckingDb}
                    className="min-h-[36px] px-2.5 py-1 rounded-lg bg-[#140A1D] hover:bg-[#1F102E] border border-[#3B1736] text-xs text-rose-200 inline-flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <RefreshCw
                      className={`w-3.5 h-3.5 ${
                        isCheckingDb ? 'animate-spin' : ''
                      }`}
                    />
                    <span>Test Connection</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowSqlModal((prev) => !prev)}
                    className="min-h-[36px] px-2.5 py-1 rounded-lg bg-[#140A1D] hover:bg-[#1F102E] border border-[#3B1736] text-xs text-[#E2E8F0] hover:text-white inline-flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Code2 className="w-3.5 h-3.5 text-rose-300" />
                    <span>{showSqlModal ? 'Hide SQL' : 'View RLS SQL'}</span>
                  </button>
                </div>
              </div>

              {!dbStatus.envConfigured ? (
                <div className="text-xs text-amber-200/90 space-y-1.5">
                  <p className="flex items-start gap-2 font-medium text-amber-200">
                    <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <span>
                      Action Required: Enter <code className="font-mono">VITE_SUPABASE_URL</code> and <code className="font-mono">VITE_SUPABASE_ANON_KEY</code> in AI Studio Environment Variables / Secrets.
                    </span>
                  </p>
                  <p className="text-[#9B97B2] pl-6">
                    No credentials are hardcoded. Never enter your <code className="font-mono">service_role</code> secret key.
                  </p>
                </div>
              ) : dbStatus.isConnected ? (
                <div className="space-y-1 text-xs">
                  <p className="text-rose-200 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-rose-400 shrink-0" />
                    <span>{dbStatus.modeLabel}</span>
                  </p>
                  {dbStatus.configuredUrl && (
                    <p className="text-[#A39BB5] pl-6">
                      Base URL: <code className="font-mono text-[#E2E8F0]">{dbStatus.configuredUrl}</code>
                    </p>
                  )}
                </div>
              ) : (
                <div className="text-xs text-amber-200 space-y-1">
                  <p className="font-medium">{dbStatus.modeLabel}</p>
                  {dbStatus.configuredUrl && (
                    <p className="text-[#A39BB5]">
                      Normalized Base URL: <code className="font-mono text-[#E2E8F0]">{dbStatus.configuredUrl}</code>
                    </p>
                  )}
                  <p className="text-[#A39BB5]">
                    Copy and run the MOON SQL Schema in your Supabase SQL Editor, and enable Anonymous Sign-Ins under Authentication &rarr; Providers &rarr; Anonymous.
                  </p>
                </div>
              )}

              {showSqlModal && (
                <div className="space-y-2 pt-2 border-t border-[#2D142C]">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs text-[#A39BB5]">
                      Run in Supabase SQL Editor:
                    </span>
                    <CopyFeedbackButton
                      value={PREPARED_SUPABASE_SQL_SCHEMA}
                      label="Copy Full SQL & RLS"
                    />
                  </div>
                  <pre className="max-h-56 overflow-y-auto p-3 rounded-xl bg-black/90 border border-[#2D142C] text-[11px] font-mono text-rose-200 leading-relaxed">
                    {PREPARED_SUPABASE_SQL_SCHEMA}
                  </pre>
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Interactive Welcome / Guest / Email Auth Card */}
          <div className="lg:col-span-6 w-full max-w-md mx-auto">
            <div className="rounded-3xl bg-[#07030C]/90 backdrop-blur-md border border-[#351635] p-6 sm:p-7 shadow-[0_24px_65px_rgba(0,0,0,0.9),0_0_35px_rgba(153,27,27,0.16)] space-y-6">
              {/* Global App Branding Header inside Login Card */}
              <div className="flex flex-col items-center text-center gap-1.5 pb-3 border-b border-[#2D142C]/80">
                <div className="inline-flex items-center gap-2.5">
                  <MoonLogo size="sm" />
                  <span className="font-display text-xl font-bold tracking-[0.16em] bg-gradient-to-r from-[#F8FAFC] via-[#FECDD3] to-[#C4B5FD] bg-clip-text text-transparent">
                    MOON
                  </span>
                </div>
                <span className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-[#160629] border border-fuchsia-500/35 text-[11px] font-semibold text-fuchsia-200 shadow-[0_0_14px_rgba(168,85,247,0.28)]">
                  <span>Created by Aditya Chauhan</span>
                </span>
              </div>

              {/* Interactive Segmented Mode Switcher */}
              <div
                role="tablist"
                aria-label="Authentication Mode"
                className="grid grid-cols-3 gap-1 p-1 rounded-2xl bg-[#030106] border border-[#2D142C]"
              >
                <button
                  type="button"
                  role="tab"
                  aria-selected={authMode === 'welcome'}
                  onClick={() => {
                    setAuthMode('welcome');
                    setErrorMessage(null);
                  }}
                  className={`min-h-[42px] px-3 py-2 text-xs font-medium rounded-xl transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                    authMode === 'welcome'
                      ? 'bg-gradient-to-r from-[#6D28D9] to-[#9F1239] text-white shadow-[0_0_16px_rgba(225,29,72,0.35)]'
                      : 'text-[#A39BB5] hover:text-white'
                  }`}
                >
                  Guest Access
                </button>
                <button
                  type="button"
                  role="tab"
                  aria-selected={authMode === 'login'}
                  onClick={() => {
                    setAuthMode('login');
                    setErrorMessage(null);
                  }}
                  className={`min-h-[42px] px-3 py-2 text-xs font-medium rounded-xl transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                    authMode === 'login'
                      ? 'bg-gradient-to-r from-[#6D28D9] to-[#9F1239] text-white shadow-[0_0_16px_rgba(225,29,72,0.35)]'
                      : 'text-[#A39BB5] hover:text-white'
                  }`}
                >
                  Email Login
                </button>
                <button
                  type="button"
                  role="tab"
                  aria-selected={authMode === 'signup'}
                  onClick={() => {
                    setAuthMode('signup');
                    setErrorMessage(null);
                  }}
                  className={`min-h-[42px] px-3 py-2 text-xs font-medium rounded-xl transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                    authMode === 'signup'
                      ? 'bg-gradient-to-r from-[#6D28D9] to-[#9F1239] text-white shadow-[0_0_16px_rgba(225,29,72,0.35)]'
                      : 'text-[#A39BB5] hover:text-white'
                  }`}
                >
                  Sign Up
                </button>
              </div>

              {errorMessage && (
                <ErrorBanner
                  title="Supabase Authentication Notice"
                  message={errorMessage}
                  onDismiss={() => setErrorMessage(null)}
                />
              )}

              {infoNotice && (
                <div className="p-4 rounded-2xl bg-[#160A24] border border-rose-500/35 text-xs text-rose-200 leading-relaxed">
                  {infoNotice}
                </div>
              )}

              {authMode === 'welcome' ? (
                /* SCREEN 1 & 2: Welcome + Continue as Guest (Supabase Anonymous Auth) */
                <div className="space-y-5">
                  <div className="space-y-1.5">
                    <h2 className="font-display text-xl font-semibold text-white">
                      Welcome to MOON
                    </h2>
                    <p className="text-xs text-[#CBD5E1] leading-relaxed">
                      Sign in with <span className="text-rose-200 font-medium">Supabase Anonymous Auth</span> to create a real guest profile and unique <span className="font-mono text-rose-300">MOON-XXXX-XX</span> friend code in your database.
                    </p>
                  </div>

                  <MoonInput
                    label="Preferred Guest Username"
                    value={guestUsername}
                    onChange={(e) => setGuestUsername(e.target.value)}
                    placeholder="luna_wanderer"
                    hint="Creates your row in public.profiles with a unique friend code."
                    rightSlot={
                      <UserCheck className="w-4 h-4 text-rose-400 mr-2" />
                    }
                  />

                  <div className="space-y-3 pt-1">
                    <MoonButton
                      type="button"
                      variant="primary"
                      size="lg"
                      fullWidth
                      isLoading={isLoadingGuest}
                      onClick={handleContinueAsGuest}
                      rightIcon={<ArrowRight className="w-4 h-4" />}
                    >
                      Continue as Guest
                    </MoonButton>

                    <div className="flex items-center justify-between gap-2 pt-2 border-t border-[#2D142C]">
                      <span className="text-xs text-[#948CA8]">
                        Have an email account?
                      </span>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => setAuthMode('login')}
                          className="min-h-[40px] px-2.5 text-xs font-medium text-rose-300 hover:text-rose-200 underline underline-offset-4 cursor-pointer"
                        >
                          Log in
                        </button>
                        <span className="text-[#49455E]" aria-hidden="true">
                          ·
                        </span>
                        <button
                          type="button"
                          onClick={() => setAuthMode('signup')}
                          className="min-h-[40px] px-2.5 text-xs font-medium text-rose-300 hover:text-rose-200 underline underline-offset-4 cursor-pointer"
                        >
                          Sign up
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                /* SCREEN 3: Email Login & Signup via Supabase Auth */
                <form
                  onSubmit={handleEmailSubmit}
                  className="space-y-4"
                  noValidate
                >
                  <div className="space-y-1">
                    <h2 className="font-display text-xl font-semibold text-white">
                      {authMode === 'login'
                        ? 'Sign in with Email'
                        : 'Create MOON Account'}
                    </h2>
                    <p className="text-xs text-[#CBD5E1]">
                      {authMode === 'login'
                        ? 'Authenticate with your Supabase email and password.'
                        : 'Register via Supabase Auth and reserve your unique friend code.'}
                    </p>
                  </div>

                  {authMode === 'signup' && (
                    <MoonInput
                      label="Username"
                      value={signupUsername}
                      onChange={(e) => setSignupUsername(e.target.value)}
                      placeholder="nyx_eclipse"
                      autoComplete="username"
                      rightSlot={
                        <User className="w-4 h-4 text-[#7E7291] mr-2" />
                      }
                    />
                  )}

                  <MoonInput
                    label="Email Address"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@example.com"
                    autoComplete="email"
                    rightSlot={<Mail className="w-4 h-4 text-[#7E7291] mr-2" />}
                  />

                  <MoonInput
                    label="Password"
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="At least 6 characters"
                    autoComplete={
                      authMode === 'login' ? 'current-password' : 'new-password'
                    }
                    rightSlot={
                      <button
                        type="button"
                        onClick={() => setShowPassword((prev) => !prev)}
                        aria-label={
                          showPassword ? 'Hide password' : 'Show password'
                        }
                        className="min-h-[40px] min-w-[40px] flex items-center justify-center text-[#A39BB5] hover:text-white cursor-pointer"
                      >
                        {showPassword ? (
                          <EyeOff className="w-4 h-4" />
                        ) : (
                          <Eye className="w-4 h-4" />
                        )}
                      </button>
                    }
                  />

                  <div className="space-y-2.5 pt-2">
                    <MoonButton
                      type="submit"
                      variant="primary"
                      size="lg"
                      fullWidth
                      isLoading={isLoadingEmail}
                      leftIcon={<Lock className="w-4 h-4" />}
                    >
                      {authMode === 'login'
                        ? 'Sign In with Email'
                        : 'Create Account'}
                    </MoonButton>

                    <MoonButton
                      type="button"
                      variant="secondary"
                      fullWidth
                      isLoading={isLoadingGuest}
                      onClick={handleContinueAsGuest}
                      leftIcon={
                        <Sparkles className="w-4 h-4 text-rose-300" />
                      }
                    >
                      Continue as Guest Instead
                    </MoonButton>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </main>

      <footer className="relative z-10 w-full max-w-6xl mx-auto px-5 py-4 border-t border-[#2D142C]/60 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-[#948CA8]">
        <span>
          MOON • Created by Aditya Chauhan · Devil Night Blood Moon AMOLED Edition
        </span>
        <span>
          {dbStatus.envConfigured
            ? dbStatus.modeLabel
            : 'Awaiting VITE_SUPABASE_URL & VITE_SUPABASE_ANON_KEY'}
        </span>
      </footer>
    </div>
  );
};
