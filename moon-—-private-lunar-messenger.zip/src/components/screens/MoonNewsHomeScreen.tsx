import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  Bell,
  Bookmark,
  Check,
  Copy,
  ExternalLink,
  Flame,
  Globe,
  Heart,
  Languages,
  Loader2,
  MessageCircle,
  Newspaper,
  RefreshCw,
  Search,
  Send,
  Share2,
  ShieldCheck,
  Sparkles,
  TrendingUp,
  X,
} from 'lucide-react';
import { FriendContact, UserProfile } from '../../types/moon';
import { MoonLogo } from '../ui/MoonLogo';
import { LunarAvatar } from '../ui/ReusablePrimitives';

export interface MoonNewsArticleItem {
  id: string;
  sourceId: string;
  sourceName: string;
  sourceHandle: string;
  sourceLogoBadge: string;
  sourceWebsite: string;
  headline: string;
  summary: string;
  hindiSummary: string;
  articleUrl: string;
  imageUrl?: string;
  publishedAtIso: string;
  publishedAtText: string;
  publishedDateIst?: string;
  isTodayIst?: boolean;
  isYesterdayIst?: boolean;
  dayBucket?: 'today' | 'previous';
  relativeTimeText?: string;
  countryCode: 'IN' | 'US' | 'GB' | 'CN' | 'RU' | 'JP' | 'GLOBAL';
  countryLabel: string;
  language: 'hi' | 'en';
  primaryCategory: string;
  categories: string[];
  isIndia: boolean;
  isBihar: boolean;
}

export type DateFilterMode = 'today' | 'previous' | 'all';

const getClientIstCalendarInfo = () => {
  const now = new Date();
  const ymd = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Kolkata',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(now);
  const readableEn = new Intl.DateTimeFormat('en-IN', {
    timeZone: 'Asia/Kolkata',
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  }).format(now);
  const readableHi = new Intl.DateTimeFormat('hi-IN', {
    timeZone: 'Asia/Kolkata',
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  }).format(now);
  const timeIst =
    now.toLocaleString('en-IN', {
      timeZone: 'Asia/Kolkata',
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    }) + ' IST';
  return { ymd, readableEn, readableHi, timeIst };
};

export interface NewsCommentItem {
  id: string;
  authorName: string;
  authorUsername: string;
  text: string;
  createdAtText: string;
}

interface MoonNewsHomeScreenProps {
  currentUser: UserProfile;
  friends: FriendContact[];
  onShareNewsToFriend: (friendId: string, messageText: string) => Promise<void>;
  onOpenChatWithFriend: (friendId: string) => void;
}

type NewsFilterId =
  | 'for_you'
  | 'india'
  | 'traders'
  | 'world'
  | 'bihar'
  | 'technology'
  | 'sports'
  | 'breaking'
  | 'politics'
  | 'science'
  | 'business'
  | 'entertainment'
  | 'saved';

type TradersSubTopicId =
  | 'all'
  | 'nifty_sensex'
  | 'gold_silver'
  | 'company_updates'
  | 'business'
  | 'trading_education'
  | 'international';

const TRADERS_SUB_TOPICS: Array<{
  id: TradersSubTopicId;
  label: string;
  hindiSub: string;
}> = [
  { id: 'all', label: 'All Traders News', hindiSub: 'सभी मार्केट ख़बरें' },
  {
    id: 'nifty_sensex',
    label: 'Nifty 50 & Sensex 🇮🇳',
    hindiSub: 'भारतीय शेयर बाजार',
  },
  {
    id: 'gold_silver',
    label: 'Gold & Silver 🪙',
    hindiSub: 'सोना और चांदी बाजार',
  },
  {
    id: 'company_updates',
    label: 'Company Updates 🏢',
    hindiSub: 'कंपनी और तिमाही नतीजे',
  },
  { id: 'business', label: 'Business News 💼', hindiSub: 'व्यापार और अर्थव्यवस्था' },
  {
    id: 'trading_education',
    label: 'Trading Education 📚',
    hindiSub: 'ट्रेडिंग और निवेश शिक्षा',
  },
  {
    id: 'international',
    label: 'International Markets 🌍',
    hindiSub: 'ग्लोबल मार्केट',
  },
];

type CountryFilterCode =
  | 'ALL'
  | 'IN'
  | 'US'
  | 'GB'
  | 'CN'
  | 'RU'
  | 'JP'
  | 'GLOBAL';

const LIKED_NEWS_STORAGE_KEY = 'moon_news_liked_ids_v1';
const SAVED_NEWS_ITEMS_STORAGE_KEY = 'moon_news_saved_items_v1';
const NEWS_COMMENTS_STORAGE_KEY = 'moon_news_comments_v1';

const PRIMARY_FEED_FILTERS: Array<{
  id: NewsFilterId;
  label: string;
  badge?: string;
}> = [
  { id: 'for_you', label: 'For You', badge: '60% 🇮🇳' },
  { id: 'india', label: 'India 🇮🇳' },
  { id: 'traders', label: 'Traders 📈', badge: 'Nifty • Gold' },
  { id: 'world', label: 'World 🌍' },
  { id: 'bihar', label: 'Bihar 🇮🇳' },
  { id: 'business', label: 'Business' },
  { id: 'technology', label: 'Technology' },
  { id: 'sports', label: 'Sports' },
  { id: 'breaking', label: 'Breaking News' },
  { id: 'politics', label: 'Politics' },
  { id: 'science', label: 'Science' },
  { id: 'entertainment', label: 'Entertainment' },
  { id: 'saved', label: 'Saved' },
];

const COUNTRY_STORY_FILTERS: Array<{
  code: CountryFilterCode;
  flag: string;
  name: string;
  subLabel: string;
}> = [
  { code: 'ALL', flag: '🌐', name: 'All World', subLabel: '60/40 Mix' },
  { code: 'IN', flag: '🇮🇳', name: 'India', subLabel: 'भारत • हिंदी' },
  { code: 'US', flag: '🇺🇸', name: 'USA', subLabel: 'America' },
  { code: 'GB', flag: '🇬🇧', name: 'UK', subLabel: 'Britain' },
  { code: 'CN', flag: '🇨🇳', name: 'China', subLabel: 'चीन' },
  { code: 'RU', flag: '🇷🇺', name: 'Russia', subLabel: 'रूस' },
  { code: 'JP', flag: '🇯🇵', name: 'Japan', subLabel: 'जापान' },
  { code: 'GLOBAL', flag: '🌍', name: 'Global', subLabel: 'Worldwide' },
];

const QUICK_SEARCH_TOPICS = [
  'बिहार (Bihar)',
  'भारत (India)',
  'Cricket',
  'ISRO',
  'AI & Tech',
  'USA',
  'Russia',
  'China',
  'Japan',
  'UK',
];

export const MoonNewsHomeScreen: React.FC<MoonNewsHomeScreenProps> = ({
  currentUser,
  friends,
  onShareNewsToFriend,
  onOpenChatWithFriend,
}) => {
  const initialIst = useMemo(() => getClientIstCalendarInfo(), []);
  const [activeFilter, setActiveFilter] = useState<NewsFilterId>('for_you');
  const [tradersSubTopic, setTradersSubTopic] =
    useState<TradersSubTopicId>('all');
  const [selectedCountry, setSelectedCountry] =
    useState<CountryFilterCode>('ALL');
  const [dateFilter, setDateFilter] = useState<DateFilterMode>('today');
  const [searchQuery, setSearchQuery] = useState('');
  const [appliedSearchQuery, setAppliedSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);

  const [articles, setArticles] = useState<MoonNewsArticleItem[]>([]);
  const [totalAvailable, setTotalAvailable] = useState(0);
  const [todayCount, setTodayCount] = useState(0);
  const [previousDaysCount, setPreviousDaysCount] = useState(0);
  const [todayIstDateKey, setTodayIstDateKey] = useState(initialIst.ymd);
  const [todayFormattedIst, setTodayFormattedIst] = useState(
    initialIst.readableEn
  );
  const [todayFormattedHindi, setTodayFormattedHindi] = useState(
    initialIst.readableHi
  );
  const [lastFetchedIstText, setLastFetchedIstText] = useState(
    initialIst.timeIst
  );
  const [hasMore, setHasMore] = useState(false);
  const [indiaRatioPercent, setIndiaRatioPercent] = useState(60);
  const [sourcesActiveCount, setSourcesActiveCount] = useState(18);

  const [isLoading, setIsLoading] = useState(true);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [feedError, setFeedError] = useState<string | null>(null);

  // Social interactions persisted in localStorage
  const [likedById, setLikedById] = useState<Record<string, boolean>>(() => {
    try {
      const raw = localStorage.getItem(LIKED_NEWS_STORAGE_KEY);
      return raw ? JSON.parse(raw) : {};
    } catch {
      return {};
    }
  });

  const [savedArticles, setSavedArticles] = useState<MoonNewsArticleItem[]>(
    () => {
      try {
        const raw = localStorage.getItem(SAVED_NEWS_ITEMS_STORAGE_KEY);
        return raw ? JSON.parse(raw) : [];
      } catch {
        return [];
      }
    }
  );

  const [commentsByArticleId, setCommentsByArticleId] = useState<
    Record<string, NewsCommentItem[]>
  >(() => {
    try {
      const raw = localStorage.getItem(NEWS_COMMENTS_STORAGE_KEY);
      return raw ? JSON.parse(raw) : {};
    } catch {
      return {};
    }
  });

  const [openCommentsPostId, setOpenCommentsPostId] = useState<string | null>(
    null
  );
  const [commentDraftById, setCommentDraftById] = useState<
    Record<string, string>
  >({});

  // Hindi translation state per article
  const [translatedHindiById, setTranslatedHindiById] = useState<
    Record<string, string>
  >({});
  const [translatingById, setTranslatingById] = useState<
    Record<string, boolean>
  >({});

  // Failed image fallback tracker so broken publisher image URLs fall back cleanly
  const [failedImageById, setFailedImageById] = useState<
    Record<string, boolean>
  >({});

  // Share with MOON Friends modal state
  const [sharingArticle, setSharingArticle] =
    useState<MoonNewsArticleItem | null>(null);
  const [sharingFriendId, setSharingFriendId] = useState<string | null>(null);
  const [sharedSuccessFriendId, setSharedSuccessFriendId] = useState<
    string | null
  >(null);
  const [shareError, setShareError] = useState<string | null>(null);
  const [copiedArticleId, setCopiedArticleId] = useState<string | null>(null);

  const loadMoreTriggerRef = useRef<HTMLDivElement | null>(null);
  const didInitialMountRefreshRef = useRef(false);

  const fetchNewsFeed = useCallback(
    async (params: {
      filter: NewsFilterId;
      tradersTopic?: TradersSubTopicId;
      country: CountryFilterCode;
      dateMode: DateFilterMode;
      query: string;
      offset: number;
      append: boolean;
      forceRefresh?: boolean;
    }) => {
      const currentIst = getClientIstCalendarInfo();
      setTodayIstDateKey(currentIst.ymd);
      setTodayFormattedIst(currentIst.readableEn);
      setTodayFormattedHindi(currentIst.readableHi);

      if (params.filter === 'saved') {
        setIsLoading(false);
        setIsLoadingMore(false);
        setIsRefreshing(false);
        setFeedError(null);
        return;
      }

      if (params.offset === 0) {
        if (params.forceRefresh) {
          setIsRefreshing(true);
        } else {
          setIsLoading(true);
        }
      } else {
        setIsLoadingMore(true);
      }
      setFeedError(null);

      try {
        const searchParams = new URLSearchParams({
          filter: params.filter,
          country: params.country,
          dateFilter: params.dateMode,
          offset: String(params.offset),
          limit: '12',
        });
        if (params.filter === 'traders' && params.tradersTopic) {
          searchParams.set('tradersTopic', params.tradersTopic);
        }
        if (params.query.trim()) {
          searchParams.set('q', params.query.trim());
        }
        if (params.forceRefresh) {
          searchParams.set('refresh', '1');
        }

        const res = await fetch(`/api/news/feed?${searchParams.toString()}`);
        if (!res.ok) {
          throw new Error(
            `News server returned status ${res.status}. Please retry.`
          );
        }

        const data = (await res.json()) as {
          items?: MoonNewsArticleItem[];
          totalCount?: number;
          todayCount?: number;
          previousDaysCount?: number;
          todayIstDateKey?: string;
          todayFormattedIst?: string;
          todayFormattedHindi?: string;
          fetchedAtIstText?: string;
          hasMore?: boolean;
          indiaRatioPercent?: number;
          sourcesActive?: number;
          error?: string;
        };

        if (data.error) {
          throw new Error(data.error);
        }

        const rawIncoming = Array.isArray(data.items) ? data.items : [];
        const seenIncoming = new Set<string>();
        const incoming = rawIncoming.filter((item) => {
          const key = `${item.id}|${item.articleUrl}`;
          if (seenIncoming.has(item.id) || seenIncoming.has(key)) return false;
          seenIncoming.add(item.id);
          seenIncoming.add(key);
          return true;
        });
        setArticles((prev) => {
          if (!params.append) return incoming;
          const existingIds = new Set(prev.map((a) => a.id));
          const existingUrls = new Set(prev.map((a) => a.articleUrl));
          return [
            ...prev,
            ...incoming.filter(
              (item) =>
                !existingIds.has(item.id) && !existingUrls.has(item.articleUrl)
            ),
          ];
        });
        setTotalAvailable(data.totalCount ?? incoming.length);
        if (typeof data.todayCount === 'number') {
          setTodayCount(data.todayCount);
        }
        if (typeof data.previousDaysCount === 'number') {
          setPreviousDaysCount(data.previousDaysCount);
        }
        if (data.todayIstDateKey) {
          setTodayIstDateKey(data.todayIstDateKey);
        }
        if (data.todayFormattedIst) {
          setTodayFormattedIst(data.todayFormattedIst);
        }
        if (data.todayFormattedHindi) {
          setTodayFormattedHindi(data.todayFormattedHindi);
        }
        setLastFetchedIstText(
          data.fetchedAtIstText || getClientIstCalendarInfo().timeIst
        );
        setHasMore(Boolean(data.hasMore));
        if (typeof data.indiaRatioPercent === 'number') {
          setIndiaRatioPercent(data.indiaRatioPercent);
        }
        if (typeof data.sourcesActive === 'number') {
          setSourcesActiveCount(data.sourcesActive);
        }
      } catch (err) {
        setFeedError(
          err instanceof Error
            ? err.message
            : 'Unable to load live RSS news right now. Please check your connection and retry.'
        );
      } finally {
        setIsLoading(false);
        setIsLoadingMore(false);
        setIsRefreshing(false);
      }
    },
    []
  );

  // Fetch fresh RSS news whenever the Home Feed opens (forceRefresh on first mount) or when filters change
  useEffect(() => {
    const isInitialOpen = !didInitialMountRefreshRef.current;
    didInitialMountRefreshRef.current = true;
    void fetchNewsFeed({
      filter: activeFilter,
      tradersTopic: tradersSubTopic,
      country: selectedCountry,
      dateMode: dateFilter,
      query: appliedSearchQuery,
      offset: 0,
      append: false,
      forceRefresh: isInitialOpen,
    });
  }, [
    activeFilter,
    tradersSubTopic,
    selectedCountry,
    dateFilter,
    appliedSearchQuery,
    fetchNewsFeed,
  ]);

  // Automatic periodic refresh every 5 minutes while Home Feed is open + when returning to app tab
  useEffect(() => {
    if (activeFilter === 'saved') return;

    const intervalId = window.setInterval(() => {
      void fetchNewsFeed({
        filter: activeFilter,
        tradersTopic: tradersSubTopic,
        country: selectedCountry,
        dateMode: dateFilter,
        query: appliedSearchQuery,
        offset: 0,
        append: false,
        forceRefresh: true,
      });
    }, 5 * 60 * 1000);

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        void fetchNewsFeed({
          filter: activeFilter,
          tradersTopic: tradersSubTopic,
          country: selectedCountry,
          dateMode: dateFilter,
          query: appliedSearchQuery,
          offset: 0,
          append: false,
          forceRefresh: true,
        });
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => {
      window.clearInterval(intervalId);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [
    activeFilter,
    tradersSubTopic,
    selectedCountry,
    dateFilter,
    appliedSearchQuery,
    fetchNewsFeed,
  ]);

  // Infinite scroll IntersectionObserver
  useEffect(() => {
    if (
      activeFilter === 'saved' ||
      !hasMore ||
      isLoading ||
      isLoadingMore ||
      Boolean(feedError)
    ) {
      return;
    }
    const target = loadMoreTriggerRef.current;
    if (!target || typeof IntersectionObserver === 'undefined') return;

    const observer = new IntersectionObserver(
      (entries) => {
        const first = entries[0];
        if (first?.isIntersecting && !isLoadingMore) {
          void fetchNewsFeed({
            filter: activeFilter,
            tradersTopic: tradersSubTopic,
            country: selectedCountry,
            dateMode: dateFilter,
            query: appliedSearchQuery,
            offset: articles.length,
            append: true,
          });
        }
      },
      { rootMargin: '260px' }
    );

    observer.observe(target);
    return () => observer.disconnect();
  }, [
    activeFilter,
    tradersSubTopic,
    selectedCountry,
    dateFilter,
    appliedSearchQuery,
    articles.length,
    hasMore,
    isLoading,
    isLoadingMore,
    feedError,
    fetchNewsFeed,
  ]);

  const handleToggleLike = (article: MoonNewsArticleItem) => {
    setLikedById((prev) => {
      const next = { ...prev, [article.id]: !prev[article.id] };
      try {
        localStorage.setItem(LIKED_NEWS_STORAGE_KEY, JSON.stringify(next));
      } catch {
        // Ignore
      }
      return next;
    });
  };

  const handleToggleSave = (article: MoonNewsArticleItem) => {
    setSavedArticles((prev) => {
      const exists = prev.some((a) => a.articleUrl === article.articleUrl);
      const next = exists
        ? prev.filter((a) => a.articleUrl !== article.articleUrl)
        : [article, ...prev];
      try {
        localStorage.setItem(SAVED_NEWS_ITEMS_STORAGE_KEY, JSON.stringify(next));
      } catch {
        // Ignore
      }
      return next;
    });
  };

  const handleAddComment = (articleId: string, e: React.FormEvent) => {
    e.preventDefault();
    const draft = (commentDraftById[articleId] || '').trim();
    if (!draft) return;

    const newComment: NewsCommentItem = {
      id: `comment-${Date.now()}`,
      authorName: currentUser.displayName,
      authorUsername: currentUser.username,
      text: draft,
      createdAtText: new Date().toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
      }),
    };

    setCommentsByArticleId((prev) => {
      const existing = prev[articleId] || [];
      const next = {
        ...prev,
        [articleId]: [...existing, newComment],
      };
      try {
        localStorage.setItem(NEWS_COMMENTS_STORAGE_KEY, JSON.stringify(next));
      } catch {
        // Ignore
      }
      return next;
    });

    setCommentDraftById((prev) => ({ ...prev, [articleId]: '' }));
  };

  const handleTranslateToSimpleHindi = async (article: MoonNewsArticleItem) => {
    if (translatingById[article.id]) return;
    setTranslatingById((prev) => ({ ...prev, [article.id]: true }));

    try {
      const textToTranslate = `${article.headline}. ${article.summary.slice(
        0,
        240
      )}`;
      const res = await fetch('/api/news/translate-hindi', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: textToTranslate }),
      });
      if (res.ok) {
        const data = (await res.json()) as { hindiText?: string };
        if (data.hindiText) {
          setTranslatedHindiById((prev) => ({
            ...prev,
            [article.id]: data.hindiText!,
          }));
        }
      }
    } catch {
      // Ignore translation error
    } finally {
      setTranslatingById((prev) => ({ ...prev, [article.id]: false }));
    }
  };

  const handleCopyArticleLink = async (article: MoonNewsArticleItem) => {
    try {
      await navigator.clipboard.writeText(article.articleUrl);
      setCopiedArticleId(article.id);
      setTimeout(() => setCopiedArticleId(null), 2200);
    } catch {
      // Ignore
    }
  };

  const handleShareArticleToFriend = async (
    friend: FriendContact,
    article: MoonNewsArticleItem
  ) => {
    setSharingFriendId(friend.id);
    setShareError(null);
    setSharedSuccessFriendId(null);

    const messageText = `📰 MOON GLOBAL NEWS (${article.countryLabel} • ${article.sourceName})\n${article.headline}\n🇮🇳 ${
      translatedHindiById[article.id] || article.hindiSummary
    }\n🔗 ${article.articleUrl}`;

    try {
      await onShareNewsToFriend(friend.id, messageText);
      setSharedSuccessFriendId(friend.id);
    } catch (err) {
      setShareError(
        err instanceof Error
          ? err.message
          : 'Failed to share news article with friend.'
      );
    } finally {
      setSharingFriendId(null);
    }
  };

  const displayedArticles = useMemo(() => {
    if (activeFilter === 'saved') {
      if (dateFilter === 'today') {
        return savedArticles.filter(
          (a) => a.isTodayIst || a.publishedDateIst === todayIstDateKey
        );
      }
      if (dateFilter === 'previous') {
        return savedArticles.filter(
          (a) => !a.isTodayIst && a.publishedDateIst !== todayIstDateKey
        );
      }
      return savedArticles;
    }
    return articles;
  }, [activeFilter, articles, dateFilter, savedArticles, todayIstDateKey]);

  const breakingNotificationItems = useMemo(() => {
    return articles.slice(0, 5);
  }, [articles]);

  return (
    <section
      aria-label="MOON Global News Instagram-Style Home Feed"
      className="w-full max-w-2xl mx-auto space-y-4 pb-16 select-none"
    >
      {/* 1. INSTAGRAM-STYLE HOME FEED TOP BAR (MOON Logo, News Notification Icon, Search Icon, Refresh News Button, AMOLED Theme) */}
      <div className="sticky top-14 z-20 rounded-3xl bg-[#05010A]/95 backdrop-blur-xl border border-[#3B1738] px-4 py-3 shadow-[0_14px_38px_rgba(0,0,0,0.92)] space-y-2.5">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5 min-w-0">
            <MoonLogo size="sm" showWordmark headerCreatorBadge />
            <span className="hidden sm:inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-gradient-to-r from-[#6D28D9]/40 to-[#E11D48]/40 border border-rose-500/40 text-[10px] font-bold uppercase tracking-wider text-rose-200">
              <Newspaper className="w-3 h-3 text-rose-400" />
              <span>Daily News Feed</span>
            </span>
          </div>

          {/* Top-Right Action Icons: Search, Notifications, Saved, Prominent Refresh News Button */}
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={() => setIsSearchOpen((prev) => !prev)}
              className={`w-9 h-9 rounded-full border flex items-center justify-center cursor-pointer transition-all active:scale-95 ${
                isSearchOpen || appliedSearchQuery
                  ? 'bg-gradient-to-r from-[#6D28D9] to-[#E11D48] border-rose-400 text-white shadow-[0_0_14px_rgba(225,29,72,0.5)]'
                  : 'bg-[#0E0518] hover:bg-[#19092A] border-[#2D142C] text-white'
              }`}
              aria-label="Search worldwide news"
              title="Search Worldwide News"
            >
              <Search className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={() => setIsNotificationsOpen((prev) => !prev)}
              className={`relative w-9 h-9 rounded-full border flex items-center justify-center cursor-pointer transition-all active:scale-95 ${
                isNotificationsOpen
                  ? 'bg-gradient-to-r from-[#6D28D9] to-[#E11D48] border-rose-400 text-white shadow-[0_0_14px_rgba(225,29,72,0.5)]'
                  : 'bg-[#0E0518] hover:bg-[#19092A] border-[#2D142C] text-white'
              }`}
              aria-label="Breaking News Notifications"
              title="Breaking News Notifications"
            >
              <Bell className="w-4 h-4" />
              {breakingNotificationItems.length > 0 && (
                <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-rose-600 text-[9px] font-bold text-white flex items-center justify-center border border-black">
                  {breakingNotificationItems.length}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={() =>
                setActiveFilter((prev) =>
                  prev === 'saved' ? 'for_you' : 'saved'
                )
              }
              className={`h-9 px-2.5 rounded-full border text-xs font-semibold inline-flex items-center gap-1 cursor-pointer transition-all active:scale-95 ${
                activeFilter === 'saved'
                  ? 'bg-violet-600 border-violet-300 text-white'
                  : 'bg-[#0E0518] hover:bg-[#19092A] border-[#2D142C] text-[#CBD5E1]'
              }`}
              aria-label="Saved News Posts"
              title="Saved / Bookmarked News"
            >
              <Bookmark className="w-3.5 h-3.5 text-violet-300" />
              <span className="text-[11px]">{savedArticles.length}</span>
            </button>

            <button
              type="button"
              disabled={isRefreshing || isLoading}
              onClick={() =>
                void fetchNewsFeed({
                  filter: activeFilter,
                  tradersTopic: tradersSubTopic,
                  country: selectedCountry,
                  dateMode: dateFilter,
                  query: appliedSearchQuery,
                  offset: 0,
                  append: false,
                  forceRefresh: true,
                })
              }
              className="h-9 px-3 rounded-full bg-gradient-to-r from-[#6D28D9] to-[#E11D48] hover:brightness-110 border border-rose-400/50 text-white text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer transition-all active:scale-95 disabled:opacity-50 shadow-[0_0_14px_rgba(225,29,72,0.4)]"
              aria-label="Refresh News"
              title="Fetch Fresh Live RSS News Now"
            >
              <RefreshCw
                className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`}
              />
              <span>{isRefreshing ? 'Refreshing...' : 'Refresh News'}</span>
            </button>
          </div>
        </div>

        {/* ASIA/KOLKATA DAILY DATE BAR + TODAY vs PREVIOUS DAYS FILTER */}
        <div className="p-2.5 rounded-2xl bg-[#090312] border border-[#2D142C] flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-1.5 text-[11px] font-semibold text-white">
              <span className="px-2 py-0.5 rounded-md bg-emerald-950/90 border border-emerald-500/40 text-emerald-300 text-[10px] font-bold">
                🇮🇳 Asia/Kolkata (IST)
              </span>
              <span className="text-rose-200">{todayFormattedHindi}</span>
              <span className="text-[#8E8AA6]">•</span>
              <span className="font-mono text-[#CBD5E1]">
                {todayFormattedIst} ({todayIstDateKey})
              </span>
            </div>
            <p className="text-[10px] text-[#8E8AA6] mt-0.5">
              Auto-updates on Home open • Last RSS sync: {lastFetchedIstText}
            </p>
          </div>

          {/* Today vs Previous Days Filter Toggle */}
          <div
            role="group"
            aria-label="Filter News by Publication Date (Asia/Kolkata)"
            className="flex items-center gap-1.5 shrink-0 overflow-x-auto no-scrollbar"
          >
            <button
              type="button"
              onClick={() => setDateFilter('today')}
              className={`px-3 py-1.5 rounded-xl text-[11px] font-bold whitespace-nowrap inline-flex items-center gap-1.5 cursor-pointer border transition-all ${
                dateFilter === 'today'
                  ? 'bg-emerald-600 text-white border-emerald-300 shadow-[0_0_12px_rgba(16,185,129,0.45)]'
                  : 'bg-[#0E0518] border-[#2D142C] text-emerald-300 hover:border-emerald-500/40'
              }`}
            >
              <span>🟢 Today (आज)</span>
              <span className="px-1.5 py-0.2 rounded-full bg-black/40 text-[10px]">
                {todayCount}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setDateFilter('previous')}
              className={`px-3 py-1.5 rounded-xl text-[11px] font-bold whitespace-nowrap inline-flex items-center gap-1.5 cursor-pointer border transition-all ${
                dateFilter === 'previous'
                  ? 'bg-amber-600 text-white border-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.45)]'
                  : 'bg-[#0E0518] border-[#2D142C] text-amber-200 hover:border-amber-500/40'
              }`}
            >
              <span>🕓 Previous Days</span>
              <span className="px-1.5 py-0.2 rounded-full bg-black/40 text-[10px]">
                {previousDaysCount}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setDateFilter('all')}
              className={`px-2.5 py-1.5 rounded-xl text-[11px] font-semibold whitespace-nowrap inline-flex items-center gap-1 cursor-pointer border transition-all ${
                dateFilter === 'all'
                  ? 'bg-gradient-to-r from-[#6D28D9] to-[#E11D48] text-white border-rose-400'
                  : 'bg-[#0E0518] border-[#2D142C] text-[#C8C2D8] hover:text-white'
              }`}
            >
              <span>All (Today First)</span>
            </button>
          </div>
        </div>

        {/* EXPANDABLE WORLDWIDE NEWS SEARCH BAR */}
        {isSearchOpen && (
          <div className="pt-2 border-t border-[#2D142C] space-y-2 animate-[devilScreenFadeIn_160ms_ease-out]">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                setAppliedSearchQuery(searchQuery.trim());
                if (activeFilter === 'saved') setActiveFilter('for_you');
              }}
              className="flex items-center gap-2"
            >
              <div className="relative flex-1 min-w-0">
                <Search className="w-3.5 h-3.5 text-[#8E8AA6] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search India, Bihar, World, USA, Russia, China, Tech, Sports..."
                  className="w-full h-9 pl-8 pr-8 rounded-xl bg-black border border-[#3B1738] focus:border-rose-500 text-xs text-white placeholder:text-[#736B85] focus:outline-none"
                />
                {(searchQuery || appliedSearchQuery) && (
                  <button
                    type="button"
                    onClick={() => {
                      setSearchQuery('');
                      setAppliedSearchQuery('');
                    }}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#8E8AA6] hover:text-white cursor-pointer"
                    aria-label="Clear search"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
              <button
                type="submit"
                className="h-9 px-3.5 rounded-xl bg-gradient-to-r from-[#6D28D9] to-[#E11D48] text-white text-xs font-semibold cursor-pointer shrink-0 active:scale-95"
              >
                Search
              </button>
            </form>

            {/* Quick Search Topic Chips */}
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
              {QUICK_SEARCH_TOPICS.map((topic) => {
                const cleanTopic = topic.replace(/\s*\([^)]*\)/, '');
                return (
                  <button
                    key={topic}
                    type="button"
                    onClick={() => {
                      setSearchQuery(cleanTopic);
                      setAppliedSearchQuery(cleanTopic);
                      if (activeFilter === 'saved') setActiveFilter('for_you');
                    }}
                    className="px-2.5 py-1 rounded-lg bg-[#12061C] hover:bg-rose-950/80 border border-rose-500/30 text-[10px] font-medium text-rose-200 whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    {topic}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* EXPANDABLE BREAKING NEWS NOTIFICATIONS DRAWER */}
        {isNotificationsOpen && (
          <div className="p-3 rounded-2xl bg-[#090312] border border-rose-500/40 space-y-2 animate-[devilScreenFadeIn_160ms_ease-out]">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold uppercase tracking-wider text-rose-300 flex items-center gap-1.5">
                <Flame className="w-3.5 h-3.5 text-rose-400" />
                <span>Live Breaking News Alerts ({todayFormattedIst})</span>
              </span>
              <button
                type="button"
                onClick={() => setIsNotificationsOpen(false)}
                className="text-xs text-[#A39BB5] hover:text-white cursor-pointer"
              >
                Close
              </button>
            </div>
            <div className="space-y-1.5 max-h-48 overflow-y-auto">
              {breakingNotificationItems.map((item, idx) => (
                <a
                  key={`notif-${item.id}-${idx}`}
                  href={item.articleUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block p-2 rounded-xl bg-black/75 hover:bg-[#160824] border border-[#2D142C] transition-colors"
                >
                  <div className="flex items-center justify-between gap-2 text-[10px] text-rose-300 mb-0.5">
                    <span className="font-semibold">
                      {item.countryLabel} • {item.sourceName}
                    </span>
                    <span className="text-[#8E8AA6]">{item.publishedAtText}</span>
                  </div>
                  <p className="text-xs font-medium text-white line-clamp-1">
                    {item.headline}
                  </p>
                </a>
              ))}
            </div>
          </div>
        )}

        {/* 3. INDIA-FIRST FEED FILTER PILLS (For You | India | World | Bihar | Technology | Sports | ...) */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
          {PRIMARY_FEED_FILTERS.map((tab) => {
            const isSelected = activeFilter === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveFilter(tab.id)}
                className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap shrink-0 transition-all cursor-pointer border inline-flex items-center gap-1.5 ${
                  isSelected
                    ? 'bg-gradient-to-r from-[#6D28D9] to-[#E11D48] text-white border-rose-400/60 shadow-[0_0_14px_rgba(225,29,72,0.45)]'
                    : 'bg-[#0B0414] border-[#2D142C] text-[#C8C2D8] hover:text-white hover:border-rose-500/40'
                }`}
              >
                <span>{tab.label}</span>
                {tab.badge && (
                  <span className="px-1.5 py-0.2 rounded-full bg-black/40 text-[9px] text-rose-200">
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. INSTAGRAM STORIES-STYLE WORLDWIDE COUNTRY SELECTOR RINGS */}
      <div className="rounded-3xl bg-[#05010A]/90 border border-[#2D142C] p-3.5 shadow-[0_12px_30px_rgba(0,0,0,0.85)]">
        <div className="flex items-center justify-between gap-2 mb-2.5 px-1">
          <div className="flex items-center gap-1.5 text-[11px] font-semibold text-rose-200">
            <Sparkles className="w-3.5 h-3.5 text-rose-400" />
            <span>
              India-First Global Feed ({indiaRatioPercent}% 🇮🇳 India •{' '}
              {100 - indiaRatioPercent}% 🌍 International)
            </span>
          </div>
          <span className="text-[10px] font-mono text-[#8E8AA6]">
            {sourcesActiveCount} Live RSS Feeds
          </span>
        </div>

        <div className="flex items-center gap-3 overflow-x-auto no-scrollbar py-1 px-0.5">
          {COUNTRY_STORY_FILTERS.map((c) => {
            const isSelected = selectedCountry === c.code;
            return (
              <button
                key={c.code}
                type="button"
                onClick={() => {
                  setSelectedCountry(c.code);
                  if (activeFilter === 'saved') {
                    setActiveFilter('for_you');
                  }
                }}
                className="flex flex-col items-center gap-1 shrink-0 cursor-pointer group"
              >
                <div
                  className={`p-[2.5px] rounded-full transition-all ${
                    isSelected
                      ? 'bg-gradient-to-tr from-[#F59E0B] via-[#E11D48] to-[#7C3AED] shadow-[0_0_18px_rgba(225,29,72,0.65)] scale-105'
                      : 'bg-gradient-to-tr from-[#3B1738] via-[#6D28D9]/50 to-[#E11D48]/50 opacity-85 group-hover:opacity-100'
                  }`}
                >
                  <div className="w-13 h-13 sm:w-14 sm:h-14 rounded-full bg-[#06020C] flex items-center justify-center text-xl sm:text-2xl border-2 border-black">
                    <span>{c.flag}</span>
                  </div>
                </div>
                <span
                  className={`text-[11px] font-semibold leading-tight ${
                    isSelected ? 'text-rose-300' : 'text-white'
                  }`}
                >
                  {c.name}
                </span>
                <span className="text-[9px] text-[#8E8AA6] -mt-0.5">
                  {c.subLabel}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 2B. TRADERS & BUSINESS NEWS HUB SECTION IN GLOBAL NEWS FEED */}
      <div className="rounded-3xl bg-gradient-to-br from-[#080212]/95 via-[#140526]/95 to-[#21061D]/95 border border-fuchsia-500/45 p-3.5 sm:p-4 shadow-[0_14px_36px_rgba(0,0,0,0.9),0_0_24px_rgba(192,38,211,0.2)] space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-[#1C0733] border border-fuchsia-400/50 flex items-center justify-center shadow-[0_0_16px_rgba(236,72,153,0.4)] shrink-0">
              <TrendingUp className="w-4 h-4 text-fuchsia-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xs sm:text-sm font-bold text-white tracking-wide">
                  TRADERS &amp; BUSINESS NEWS HUB 📈
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-fuchsia-950/90 border border-fuchsia-400/40 text-[9px] font-bold uppercase tracking-wider text-fuchsia-200">
                  Live RSS • Hindi + EN
                </span>
              </div>
              <p className="text-[11px] text-[#D8B4FE]">
                Indian Stock Market (Nifty 50 • Sensex) • Gold &amp; Silver (सोना-चांदी) • Company Updates • Trading Education • Global Markets
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              setActiveFilter((prev) =>
                prev === 'traders' ? 'for_you' : 'traders'
              );
              setSelectedCountry('ALL');
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all cursor-pointer shrink-0 ${
              activeFilter === 'traders'
                ? 'bg-gradient-to-r from-[#7E22CE] to-[#EC4899] text-white border-pink-300 shadow-[0_0_16px_rgba(236,72,153,0.5)]'
                : 'bg-[#120422] hover:bg-[#1E0836] border-fuchsia-500/45 text-fuchsia-200'
            }`}
          >
            {activeFilter === 'traders'
              ? 'Viewing Traders Feed ✓'
              : 'Open Traders Feed 📈'}
          </button>
        </div>

        {/* Sub-Topic Filter Pills for Traders Section */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
          {TRADERS_SUB_TOPICS.map((topic) => {
            const isSelected =
              activeFilter === 'traders' && tradersSubTopic === topic.id;
            return (
              <button
                key={topic.id}
                type="button"
                onClick={() => {
                  setActiveFilter('traders');
                  setTradersSubTopic(topic.id);
                  setSelectedCountry('ALL');
                }}
                className={`px-3 py-1.5 rounded-xl text-[11px] font-semibold whitespace-nowrap shrink-0 transition-all cursor-pointer border flex flex-col items-start ${
                  isSelected
                    ? 'bg-gradient-to-r from-[#7E22CE] to-[#DB2777] text-white border-pink-300 shadow-[0_0_14px_rgba(236,72,153,0.45)]'
                    : 'bg-black/65 hover:bg-[#1A072E] border-[#3B1738] text-[#E9D5FF]'
                }`}
              >
                <span>{topic.label}</span>
                <span className="text-[9px] text-fuchsia-200/80 font-normal">
                  {topic.hindiSub}
                </span>
              </button>
            );
          })}
        </div>

        <p className="text-[10px] text-[#C4B5FD] px-1">
          ℹ️ शैक्षिक और सूचनात्मक उद्देश्य के लिए प्रमाणित पब्लिक न्यूज़ स्रोतों से वास्तविक ख़बरें। कोई नकली लाइव कीमतें (No fake prices) या वित्तीय सलाह नहीं।
        </p>
      </div>

      {/* ACTIVE SEARCH FILTER BANNER */}
      {appliedSearchQuery && (
        <div className="px-4 py-2.5 rounded-2xl bg-[#12061D] border border-rose-500/40 flex items-center justify-between gap-2 text-xs text-rose-200">
          <span>
            Showing live worldwide RSS results for{' '}
            <strong className="text-white">&ldquo;{appliedSearchQuery}&rdquo;</strong>{' '}
            ({totalAvailable} found)
          </span>
          <button
            type="button"
            onClick={() => {
              setSearchQuery('');
              setAppliedSearchQuery('');
            }}
            className="px-2.5 py-1 rounded-lg bg-rose-600 text-white text-[11px] font-semibold cursor-pointer"
          >
            Clear Search
          </button>
        </div>
      )}

      {/* LOADING, ERROR & RETRY, OR INSTAGRAM NEWS POST CARDS */}
      {isLoading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((n) => (
            <div
              key={n}
              className="rounded-3xl bg-[#06020B]/95 border border-[#2D142C] p-4 space-y-3 animate-pulse"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-[#19092A]" />
                <div className="space-y-1.5 flex-1">
                  <div className="h-3 w-36 rounded bg-[#19092A]" />
                  <div className="h-2.5 w-24 rounded bg-[#12061D]" />
                </div>
              </div>
              <div className="w-full aspect-[16/10] rounded-2xl bg-[#12061D]" />
              <div className="h-4 w-5/6 rounded bg-[#19092A]" />
              <div className="h-3 w-2/3 rounded bg-[#12061D]" />
            </div>
          ))}
        </div>
      ) : feedError ? (
        <div className="rounded-3xl bg-[#08020F] border border-rose-500/45 p-6 text-center space-y-3 shadow-2xl">
          <div className="w-12 h-12 rounded-2xl bg-rose-950/80 border border-rose-500/40 flex items-center justify-center mx-auto">
            <AlertTriangle className="w-6 h-6 text-rose-400" />
          </div>
          <h2 className="text-base font-bold text-white">
            Unable to Load Live News Feed
          </h2>
          <p className="text-xs text-[#C8C2D8] max-w-md mx-auto leading-relaxed">
            {feedError}
          </p>
          <button
            type="button"
            onClick={() =>
              void fetchNewsFeed({
                filter: activeFilter,
                tradersTopic: tradersSubTopic,
                country: selectedCountry,
                dateMode: dateFilter,
                query: appliedSearchQuery,
                offset: 0,
                append: false,
                forceRefresh: true,
              })
            }
            className="min-h-[42px] px-5 py-2.5 rounded-2xl bg-gradient-to-r from-[#6D28D9] to-[#E11D48] text-white text-xs font-semibold inline-flex items-center gap-2 cursor-pointer shadow-[0_0_20px_rgba(225,29,72,0.45)]"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Retry Loading News</span>
          </button>
        </div>
      ) : displayedArticles.length === 0 ? (
        <div className="rounded-3xl bg-[#06020B]/95 border border-[#2D142C] p-8 text-center space-y-3">
          <Newspaper className="w-10 h-10 text-rose-400/70 mx-auto" />
          <h3 className="text-sm font-bold text-white">
            {activeFilter === 'saved'
              ? 'No Saved News Posts in This Date Filter'
              : dateFilter === 'today'
              ? `No New News Published Today (${todayFormattedIst} • IST) in This Filter Yet`
              : dateFilter === 'previous'
              ? 'No Previous Days News Found in Current RSS Window'
              : 'No Matching News Articles Found'}
          </h3>
          <p className="text-xs text-[#8E8AA6] max-w-md mx-auto leading-relaxed">
            {activeFilter === 'saved'
              ? 'Tap the Bookmark icon on any worldwide or India news post to save it here for offline reading.'
              : dateFilter === 'today'
              ? `We strictly check publication timestamps in Asia/Kolkata timezone (${todayIstDateKey}) and never show yesterday's news as today's news. You can refresh live RSS feeds now or view ${previousDaysCount} articles from previous days.`
              : 'Live RSS feeds primarily carry today’s fresh dispatches. Switch to Today (आज) or For You to browse live articles.'}
          </p>
          <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
            <button
              type="button"
              onClick={() =>
                void fetchNewsFeed({
                  filter: activeFilter,
                  tradersTopic: tradersSubTopic,
                  country: selectedCountry,
                  dateMode: dateFilter,
                  query: appliedSearchQuery,
                  offset: 0,
                  append: false,
                  forceRefresh: true,
                })
              }
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#6D28D9] to-[#E11D48] text-white text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Refresh Live RSS Now</span>
            </button>

            {dateFilter === 'today' && previousDaysCount > 0 && (
              <button
                type="button"
                onClick={() => setDateFilter('previous')}
                className="px-4 py-2 rounded-xl bg-amber-600/90 hover:bg-amber-600 text-white text-xs font-semibold cursor-pointer"
              >
                View Previous Days News ({previousDaysCount})
              </button>
            )}

            {dateFilter !== 'today' && todayCount > 0 && (
              <button
                type="button"
                onClick={() => setDateFilter('today')}
                className="px-4 py-2 rounded-xl bg-emerald-600/90 hover:bg-emerald-600 text-white text-xs font-semibold cursor-pointer"
              >
                View Today&apos;s News ({todayCount})
              </button>
            )}

            {(activeFilter !== 'for_you' ||
              selectedCountry !== 'ALL' ||
              appliedSearchQuery) && (
              <button
                type="button"
                onClick={() => {
                  setActiveFilter('for_you');
                  setSelectedCountry('ALL');
                  setDateFilter('today');
                  setSearchQuery('');
                  setAppliedSearchQuery('');
                }}
                className="px-4 py-2 rounded-xl bg-[#14071E] border border-[#3B1738] text-rose-200 text-xs font-semibold cursor-pointer"
              >
                Reset to Today&apos;s For You Feed
              </button>
            )}
          </div>
        </div>
      ) : (
        /* INSTAGRAM-STYLE INDIVIDUAL SOCIAL NEWS POSTS */
        <div className="space-y-5">
          {displayedArticles.map((article) => {
            const isLiked = Boolean(likedById[article.id]);
            const isSaved = savedArticles.some(
              (a) => a.articleUrl === article.articleUrl
            );
            const postComments = commentsByArticleId[article.id] || [];
            const isCommentsOpen = openCommentsPostId === article.id;
            const hasValidImage =
              Boolean(article.imageUrl) && !failedImageById[article.id];
            const displayedHindiSummary =
              translatedHindiById[article.id] || article.hindiSummary;
            const isArticleToday =
              article.isTodayIst ??
              article.publishedDateIst === todayIstDateKey;

            return (
              <article
                key={article.id}
                className="rounded-3xl bg-[#05010A]/95 border border-[#3B1738] overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.92)] transition-all hover:border-rose-500/45"
              >
                {/* POST HEADER: Circular Source Logo, Publisher Name, Country, IST Date & Day Badge */}
                <div className="px-4 py-3 flex items-center justify-between gap-3 border-b border-[#220D23]">
                  <div className="flex items-center gap-2.5 min-w-0">
                    {/* Instagram-style Gradient Ring around News Publisher Avatar */}
                    <div className="p-[2px] rounded-full bg-gradient-to-tr from-[#F59E0B] via-[#E11D48] to-[#7C3AED] shrink-0">
                      <div className="w-9 h-9 rounded-full bg-[#08020F] flex items-center justify-center text-[10px] font-extrabold tracking-tighter text-white border border-black">
                        {article.sourceLogoBadge.slice(0, 6)}
                      </div>
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <a
                          href={article.articleUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-xs sm:text-sm font-bold text-white hover:text-rose-300 truncate"
                        >
                          {article.sourceName}
                        </a>
                        <span
                          title="Verified Public News RSS Source"
                          className="inline-flex items-center shrink-0"
                        >
                          <ShieldCheck className="w-3.5 h-3.5 text-rose-400" />
                        </span>
                      </div>
                      <div className="flex flex-wrap items-center gap-1.5 text-[10px] text-[#A39BB5]">
                        <span className="font-mono">{article.sourceHandle}</span>
                        <span>•</span>
                        <span className="text-rose-200 font-semibold">
                          {article.countryLabel}
                        </span>
                        <span>•</span>
                        <span className="text-white font-medium">
                          {article.publishedAtText}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    {/* Explicit Today (IST) vs Previous Day Badge so yesterday's news is never disguised as today's */}
                    <span
                      className={`px-2 py-0.5 rounded-full text-[9px] font-bold border ${
                        isArticleToday
                          ? 'bg-emerald-950/90 border-emerald-400/50 text-emerald-300'
                          : 'bg-amber-950/90 border-amber-400/50 text-amber-200'
                      }`}
                    >
                      {isArticleToday
                        ? '🟢 TODAY (आज)'
                        : `🕓 ${article.publishedDateIst || 'PREV DAY'}`}
                    </span>

                    <span
                      className={`hidden sm:inline-block px-2.5 py-0.5 rounded-full text-[10px] font-semibold border ${
                        article.isBihar
                          ? 'bg-amber-950/90 border-amber-400/50 text-amber-200'
                          : article.isIndia
                          ? 'bg-rose-950/90 border-rose-500/45 text-rose-200'
                          : 'bg-violet-950/90 border-violet-500/45 text-violet-200'
                      }`}
                    >
                      {article.primaryCategory}
                    </span>

                    <a
                      href={article.articleUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-8 h-8 rounded-full bg-[#12061C] hover:bg-rose-950/80 border border-[#2D142C] text-rose-300 flex items-center justify-center"
                      title="Open original news source"
                      aria-label={`Open ${article.headline} on ${article.sourceName}`}
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </div>

                {/* POST IMAGE / VISUAL STAGE (Clicking opens original article; Double-click likes) */}
                <div
                  onDoubleClick={() => handleToggleLike(article)}
                  className="relative w-full bg-[#090312] overflow-hidden border-b border-[#220D23]"
                >
                  {hasValidImage ? (
                    <a
                      href={article.articleUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block relative w-full aspect-[16/10] overflow-hidden group"
                    >
                      <img
                        src={article.imageUrl}
                        alt={article.headline}
                        loading="lazy"
                        onError={() =>
                          setFailedImageById((prev) => ({
                            ...prev,
                            [article.id]: true,
                          }))
                        }
                        className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/15 to-transparent" />
                      <div className="absolute bottom-3 left-3 right-3 flex items-end justify-between gap-2">
                        <span className="px-2.5 py-1 rounded-lg bg-black/80 backdrop-blur-md border border-white/15 text-[10px] font-semibold text-white inline-flex items-center gap-1.5">
                          <Globe className="w-3 h-3 text-rose-400" />
                          <span>
                            {article.countryLabel} • {article.sourceName}
                          </span>
                        </span>
                        <span className="px-2.5 py-1 rounded-lg bg-rose-600/90 text-white text-[10px] font-semibold inline-flex items-center gap-1 shadow-lg">
                          <span>Read Article</span>
                          <ExternalLink className="w-3 h-3" />
                        </span>
                      </div>
                    </a>
                  ) : (
                    /* Official Breaking News Graphic Banner when RSS item does not include an image */
                    <a
                      href={article.articleUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block relative w-full py-7 px-5 bg-gradient-to-br from-[#170526] via-[#3B061E] to-[#06010C] hover:brightness-110 transition-all"
                    >
                      <div className="flex items-center justify-between gap-2 mb-3">
                        <span className="px-2.5 py-0.5 rounded-full bg-black/60 border border-rose-500/40 text-[10px] font-bold uppercase tracking-wider text-rose-300">
                          {article.countryLabel} • {article.primaryCategory}
                        </span>
                        <span className="text-[11px] font-mono text-[#CBD5E1]">
                          {article.sourceName}
                        </span>
                      </div>
                      <h3 className="font-display text-base sm:text-lg font-bold text-white leading-snug">
                        {article.headline}
                      </h3>
                    </a>
                  )}
                </div>

                {/* POST INTERACTION BAR: Like, Comment, Share with Friends, Copy, Save/Bookmark */}
                <div className="px-4 pt-3 pb-2 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 sm:gap-3">
                    {/* Like Button */}
                    <button
                      type="button"
                      onClick={() => handleToggleLike(article)}
                      className={`h-9 px-3 rounded-full border text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer transition-all active:scale-90 ${
                        isLiked
                          ? 'bg-rose-600/90 border-rose-400 text-white shadow-[0_0_16px_rgba(225,29,72,0.55)]'
                          : 'bg-[#0E0518] hover:bg-rose-950/60 border-[#2D142C] text-white'
                      }`}
                      aria-label={isLiked ? 'Unlike news post' : 'Like news post'}
                    >
                      <Heart
                        className={`w-4 h-4 ${
                          isLiked ? 'fill-current text-white' : 'text-rose-400'
                        }`}
                      />
                      <span>{isLiked ? 'Liked' : 'Like'}</span>
                    </button>

                    {/* Comment Button */}
                    <button
                      type="button"
                      onClick={() =>
                        setOpenCommentsPostId((prev) =>
                          prev === article.id ? null : article.id
                        )
                      }
                      className={`h-9 px-3 rounded-full border text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer transition-all active:scale-95 ${
                        isCommentsOpen
                          ? 'bg-violet-600 border-violet-300 text-white'
                          : 'bg-[#0E0518] hover:bg-violet-950/60 border-[#2D142C] text-white'
                      }`}
                      aria-label="Comment on news post"
                    >
                      <MessageCircle className="w-4 h-4 text-violet-300" />
                      <span>
                        Comment
                        {postComments.length > 0
                          ? ` (${postComments.length})`
                          : ''}
                      </span>
                    </button>

                    {/* Share with MOON Friends Button */}
                    <button
                      type="button"
                      onClick={() => {
                        setSharingArticle(article);
                        setSharedSuccessFriendId(null);
                        setShareError(null);
                      }}
                      className="h-9 px-3 rounded-full bg-[#0E0518] hover:bg-[#1A092B] border border-[#2D142C] text-xs font-semibold text-white inline-flex items-center gap-1.5 cursor-pointer transition-all active:scale-95"
                      aria-label="Share news with MOON friends"
                    >
                      <Share2 className="w-4 h-4 text-rose-300" />
                      <span>Share</span>
                    </button>
                  </div>

                  {/* Right Side: Copy Link & Bookmark/Save Button */}
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => void handleCopyArticleLink(article)}
                      className="w-9 h-9 rounded-full bg-[#0E0518] hover:bg-[#19092A] border border-[#2D142C] text-[#CBD5E1] hover:text-white flex items-center justify-center cursor-pointer transition-all active:scale-95"
                      title="Copy Article Link"
                      aria-label="Copy Article Link"
                    >
                      {copiedArticleId === article.id ? (
                        <Check className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={() => handleToggleSave(article)}
                      className={`w-9 h-9 rounded-full border flex items-center justify-center cursor-pointer transition-all active:scale-90 ${
                        isSaved
                          ? 'bg-violet-600 border-violet-300 text-white shadow-[0_0_14px_rgba(124,58,237,0.5)]'
                          : 'bg-[#0E0518] hover:bg-violet-950/60 border-[#2D142C] text-white'
                      }`}
                      aria-label={
                        isSaved ? 'Remove from Saved News' : 'Save News Post'
                      }
                      title={isSaved ? 'Saved' : 'Save News Post'}
                    >
                      <Bookmark
                        className={`w-4 h-4 ${isSaved ? 'fill-current' : ''}`}
                      />
                    </button>
                  </div>
                </div>

                {/* POST BODY: Headline, Short Hindi Summary, Published Date & Read Full News Button */}
                <div className="px-4 pb-4 space-y-2.5">
                  {/* News Headline */}
                  <a
                    href={article.articleUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block group"
                  >
                    <h2 className="text-sm sm:text-base font-bold text-white group-hover:text-rose-300 transition-colors leading-snug">
                      {article.headline}
                    </h2>
                  </a>

                  {/* Short Hindi News Summary Card */}
                  <div className="p-3 rounded-2xl bg-[#0B0415] border border-rose-500/30 space-y-1.5">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-rose-300 flex items-center gap-1">
                        <span>🇮🇳 हिंदी समाचार सारांश (Hindi Summary)</span>
                      </span>

                      {article.language === 'en' &&
                        !translatedHindiById[article.id] && (
                          <button
                            type="button"
                            disabled={translatingById[article.id]}
                            onClick={() =>
                              void handleTranslateToSimpleHindi(article)
                            }
                            className="px-2 py-0.5 rounded-lg bg-rose-950/90 hover:bg-rose-800 border border-rose-500/40 text-[10px] font-semibold text-rose-100 inline-flex items-center gap-1 cursor-pointer disabled:opacity-50"
                          >
                            {translatingById[article.id] ? (
                              <Loader2 className="w-3 h-3 animate-spin" />
                            ) : (
                              <Languages className="w-3 h-3 text-rose-300" />
                            )}
                            <span>
                              {translatingById[article.id]
                                ? 'अनुवाद हो रहा है...'
                                : 'सरल हिंदी में अनुवाद करें'}
                            </span>
                          </button>
                        )}
                    </div>

                    <p className="text-xs sm:text-[13px] text-[#EDE9FE] leading-relaxed">
                      {displayedHindiSummary}
                    </p>
                  </div>

                  {/* Original Summary if English */}
                  {article.language === 'en' &&
                    article.summary &&
                    article.summary !== article.headline && (
                      <p className="text-xs text-[#B8B0C8] leading-relaxed line-clamp-3">
                        {article.summary}
                      </p>
                    )}

                  {/* Published Date (Asia/Kolkata), Relative Time, Source Metadata & Read Full News CTA */}
                  <div className="pt-1 flex flex-wrap items-center justify-between gap-2">
                    <div className="text-[11px] text-[#8E8AA6] flex flex-wrap items-center gap-1.5">
                      <span className="text-white font-medium">
                        Published: {article.publishedAtText}
                      </span>
                      {article.relativeTimeText && (
                        <>
                          <span>•</span>
                          <span
                            className={
                              isArticleToday
                                ? 'text-emerald-300 font-semibold'
                                : 'text-amber-300 font-semibold'
                            }
                          >
                            {article.relativeTimeText}
                          </span>
                        </>
                      )}
                      <span>•</span>
                      <span className="text-rose-300 font-medium">
                        Source: {article.sourceName}
                      </span>
                    </div>

                    <a
                      href={article.articleUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="min-h-[38px] px-4 py-2 rounded-xl bg-gradient-to-r from-[#6D28D9] to-[#E11D48] text-white text-xs font-semibold inline-flex items-center gap-1.5 shadow-[0_0_16px_rgba(225,29,72,0.35)] hover:brightness-110 active:scale-95 transition-all"
                    >
                      <span>Read Full News</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>

                  {/* EXPANDABLE COMMENTS SECTION */}
                  {isCommentsOpen && (
                    <div className="mt-3 pt-3 border-t border-[#220D23] space-y-2.5 animate-[devilScreenFadeIn_150ms_ease-out]">
                      <p className="text-[11px] font-bold uppercase tracking-wider text-violet-300">
                        Discussion ({postComments.length})
                      </p>

                      {postComments.length === 0 ? (
                        <p className="text-xs text-[#8E8AA6]">
                          Be the first to share your thoughts on this news story.
                        </p>
                      ) : (
                        <div className="space-y-1.5 max-h-40 overflow-y-auto">
                          {postComments.map((c) => (
                            <div
                              key={c.id}
                              className="p-2 rounded-xl bg-[#0B0414] border border-[#241024] text-xs"
                            >
                              <div className="flex items-center justify-between text-[10px] text-[#A39BB5] mb-0.5">
                                <span className="font-semibold text-rose-200">
                                  {c.authorName} (@{c.authorUsername})
                                </span>
                                <span>{c.createdAtText}</span>
                              </div>
                              <p className="text-white">{c.text}</p>
                            </div>
                          ))}
                        </div>
                      )}

                      <form
                        onSubmit={(e) => handleAddComment(article.id, e)}
                        className="flex items-center gap-2"
                      >
                        <input
                          type="text"
                          value={commentDraftById[article.id] || ''}
                          onChange={(e) =>
                            setCommentDraftById((prev) => ({
                              ...prev,
                              [article.id]: e.target.value,
                            }))
                          }
                          placeholder="Add a comment on this news post..."
                          className="flex-1 h-9 px-3 rounded-xl bg-black border border-[#2D142C] focus:border-rose-500 text-xs text-white placeholder:text-[#645C75] focus:outline-none"
                        />
                        <button
                          type="submit"
                          className="h-9 px-3.5 rounded-xl bg-gradient-to-r from-[#6D28D9] to-[#E11D48] text-white text-xs font-semibold cursor-pointer shrink-0"
                        >
                          Post
                        </button>
                      </form>
                    </div>
                  )}
                </div>
              </article>
            );
          })}

          {/* PAGINATION / INFINITE SCROLL FOOTER */}
          {activeFilter !== 'saved' && (
            <div
              ref={loadMoreTriggerRef}
              className="py-4 flex flex-col items-center justify-center gap-2"
            >
              {hasMore ? (
                <button
                  type="button"
                  disabled={isLoadingMore}
                  onClick={() =>
                    void fetchNewsFeed({
                      filter: activeFilter,
                      country: selectedCountry,
                      dateMode: dateFilter,
                      query: appliedSearchQuery,
                      offset: articles.length,
                      append: true,
                    })
                  }
                  className="min-h-[42px] px-5 py-2.5 rounded-2xl bg-[#11061B] hover:bg-[#1B092C] border border-rose-500/40 text-xs font-semibold text-rose-200 inline-flex items-center gap-2 cursor-pointer"
                >
                  {isLoadingMore ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin text-rose-400" />
                      <span>Loading more real RSS news...</span>
                    </>
                  ) : (
                    <>
                      <Newspaper className="w-4 h-4 text-rose-400" />
                      <span>
                        Load More Worldwide News ({articles.length}/
                        {totalAvailable})
                      </span>
                    </>
                  )}
                </button>
              ) : (
                <p className="text-xs text-[#8E8AA6]">
                  You&apos;re all caught up with {articles.length} live news
                  posts.
                </p>
              )}
            </div>
          )}
        </div>
      )}

      {/* SHARE NEWS ARTICLE WITH MOON FRIENDS MODAL */}
      {sharingArticle && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Share News Post with MOON Friends"
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4"
        >
          <div className="w-full max-w-md rounded-3xl bg-[#07030D] border border-[#3B1738] p-5 shadow-[0_24px_60px_rgba(0,0,0,0.95)] space-y-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                  <Share2 className="w-4 h-4 text-rose-400" />
                  <span>Share News with MOON Friends</span>
                </h3>
                <p className="text-[11px] text-[#A39BB5] line-clamp-1 mt-0.5">
                  {sharingArticle.sourceName}: {sharingArticle.headline}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSharingArticle(null)}
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center cursor-pointer"
                aria-label="Close share modal"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {shareError && (
              <div className="p-2.5 rounded-xl bg-rose-950/90 border border-rose-500/40 text-xs text-rose-200">
                {shareError}
              </div>
            )}

            <div className="space-y-2 max-h-64 overflow-y-auto">
              {friends.length === 0 ? (
                <p className="text-xs text-[#8E8AA6] py-4 text-center">
                  No accepted MOON friends yet. Add a friend using their MOON
                  Friend Code to share news directly in chat.
                </p>
              ) : (
                friends.map((friend) => {
                  const isSent = sharedSuccessFriendId === friend.id;
                  const isSending = sharingFriendId === friend.id;
                  return (
                    <div
                      key={friend.id}
                      className="flex items-center justify-between gap-3 p-2.5 rounded-2xl bg-[#0E0518] border border-[#2D142C]"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <LunarAvatar
                          name={friend.displayName}
                          hue={friend.avatarHue}
                          size="sm"
                          presence={friend.presence}
                        />
                        <div className="min-w-0">
                          <p className="text-xs font-semibold text-white truncate">
                            {friend.displayName}
                          </p>
                          <p className="text-[10px] font-mono text-[#A39BB5] truncate">
                            @{friend.username}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          disabled={isSending}
                          onClick={() =>
                            void handleShareArticleToFriend(
                              friend,
                              sharingArticle
                            )
                          }
                          className={`px-3 py-1.5 rounded-xl text-xs font-semibold inline-flex items-center gap-1 cursor-pointer ${
                            isSent
                              ? 'bg-emerald-600 text-white'
                              : 'bg-gradient-to-r from-[#6D28D9] to-[#E11D48] text-white'
                          }`}
                        >
                          {isSending ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          ) : isSent ? (
                            <>
                              <Check className="w-3.5 h-3.5" />
                              <span>Sent</span>
                            </>
                          ) : (
                            <>
                              <Send className="w-3.5 h-3.5" />
                              <span>Send</span>
                            </>
                          )}
                        </button>

                        {isSent && (
                          <button
                            type="button"
                            onClick={() => {
                              setSharingArticle(null);
                              onOpenChatWithFriend(friend.id);
                            }}
                            className="px-2.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-[11px] text-white cursor-pointer"
                          >
                            Open Chat
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            <div className="pt-2 border-t border-[#2D142C] flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => void handleCopyArticleLink(sharingArticle)}
                className="flex-1 h-10 rounded-xl bg-[#14071E] hover:bg-[#1F0B2E] border border-[#3B1738] text-xs font-semibold text-rose-200 inline-flex items-center justify-center gap-1.5 cursor-pointer"
              >
                {copiedArticleId === sharingArticle.id ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-300">Article Link Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-rose-400" />
                    <span>Copy Original Article Link</span>
                  </>
                )}
              </button>

              <a
                href={sharingArticle.articleUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="h-10 px-4 rounded-xl bg-gradient-to-r from-[#6D28D9] to-[#E11D48] text-white text-xs font-semibold inline-flex items-center gap-1.5"
              >
                <span>Open Source</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
