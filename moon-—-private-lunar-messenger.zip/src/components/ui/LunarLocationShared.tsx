import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import {
  AlertCircle,
  Compass,
  ExternalLink,
  Loader2,
  LocateFixed,
  Lock,
  MapPin,
  Maximize2,
  Navigation,
  Search,
  Send,
  Sparkles,
  X,
} from 'lucide-react';
import { ChatLocationAttachment, LocationShareSource } from '../../types/moon';
import { MoonButton } from './ReusablePrimitives';

export function getGoogleMapsViewUrl(lat: number, lng: number): string {
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
    `${lat.toFixed(6)},${lng.toFixed(6)}`
  )}`;
}

export function getGoogleMapsDirectionsUrl(lat: number, lng: number): string {
  return `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(
    `${lat.toFixed(6)},${lng.toFixed(6)}`
  )}`;
}

function createLunarPinIcon(): L.DivIcon {
  return L.divIcon({
    className: 'moon-custom-leaflet-pin',
    iconSize: [38, 46],
    iconAnchor: [19, 44],
    popupAnchor: [0, -40],
    html: `
      <div style="position:relative;width:38px;height:46px;display:flex;align-items:center;justify-content:center;">
        <div style="position:absolute;bottom:2px;width:20px;height:8px;border-radius:9999px;background:rgba(225,29,72,0.45);filter:blur(4px);"></div>
        <svg viewBox="0 0 38 46" width="38" height="46" style="filter:drop-shadow(0 4px 10px rgba(0,0,0,0.85));overflow:visible;">
          <defs>
            <linearGradient id="moonPinGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#FB7185" />
              <stop offset="48%" stop-color="#E11D48" />
              <stop offset="100%" stop-color="#6D28D9" />
            </linearGradient>
          </defs>
          <path d="M19 2 C9.6 2 2 9.6 2 19 C2 30.2 19 44 19 44 C19 44 36 30.2 36 19 C36 9.6 28.4 2 19 2 Z" fill="url(#moonPinGrad)" stroke="#FFE4E6" stroke-width="1.8" />
          <circle cx="19" cy="18.5" r="6.5" fill="#09030F" stroke="#FDA4AF" stroke-width="1.5" />
          <circle cx="19" cy="18.5" r="2.8" fill="#FB7185" />
        </svg>
      </div>
    `,
  });
}

interface NominatimPlaceResult {
  place_id: number;
  display_name: string;
  name?: string;
  lat: string;
  lon: string;
}

async function searchPlacesNominatim(
  query: string
): Promise<NominatimPlaceResult[]> {
  const clean = query.trim();
  if (!clean) return [];

  // Support direct "lat, lng" coordinate input in the search box
  const coordMatch = clean.match(
    /^(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)$/
  );
  if (coordMatch) {
    const lat = Number.parseFloat(coordMatch[1]);
    const lng = Number.parseFloat(coordMatch[2]);
    if (
      Number.isFinite(lat) &&
      lat >= -90 &&
      lat <= 90 &&
      Number.isFinite(lng) &&
      lng >= -180 &&
      lng <= 180
    ) {
      return [
        {
          place_id: Date.now(),
          name: `Coordinates (${lat.toFixed(5)}, ${lng.toFixed(5)})`,
          display_name: `Exact GPS Coordinates: ${lat.toFixed(6)}, ${lng.toFixed(
            6
          )}`,
          lat: String(lat),
          lon: String(lng),
        },
      ];
    }
  }

  const url = `https://nominatim.openstreetmap.org/search?format=jsonv2&q=${encodeURIComponent(
    clean
  )}&limit=5&addressdetails=1`;

  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), 8000);

  try {
    const res = await fetch(url, {
      headers: {
        Accept: 'application/json',
      },
      signal: controller.signal,
    });

    if (!res.ok) {
      throw new Error(`Place search failed (HTTP ${res.status}).`);
    }

    const data = (await res.json()) as NominatimPlaceResult[];
    return Array.isArray(data) ? data : [];
  } finally {
    window.clearTimeout(timer);
  }
}

async function reverseGeocodeNominatim(
  lat: number,
  lng: number
): Promise<{ label: string; address: string }> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), 6500);

  try {
    const url = `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${encodeURIComponent(
      lat.toFixed(6)
    )}&lon=${encodeURIComponent(lng.toFixed(6))}`;

    const res = await fetch(url, {
      headers: {
        Accept: 'application/json',
      },
      signal: controller.signal,
    });

    if (!res.ok) {
      throw new Error('Reverse geocoding failed');
    }

    const data = (await res.json()) as {
      name?: string;
      display_name?: string;
      address?: Record<string, string>;
    };

    const addrObj = data.address || {};
    const primaryLabel =
      data.name ||
      addrObj.amenity ||
      addrObj.building ||
      addrObj.road ||
      addrObj.neighbourhood ||
      addrObj.suburb ||
      addrObj.city ||
      addrObj.town ||
      addrObj.state ||
      'Pinned Map Location';

    const fullAddress =
      data.display_name || `${lat.toFixed(5)}, ${lng.toFixed(5)}`;

    return {
      label: primaryLabel,
      address: fullAddress,
    };
  } catch {
    return {
      label: 'Pinned Map Location',
      address: `${lat.toFixed(5)}, ${lng.toFixed(5)}`,
    };
  } finally {
    window.clearTimeout(timer);
  }
}

/**
 * Interactive or Mini-Preview OpenStreetMap + Leaflet Map Canvas
 */
export const LeafletMapCanvas: React.FC<{
  latitude: number;
  longitude: number;
  zoom?: number;
  interactive?: boolean;
  darkTheme?: boolean;
  className?: string;
  onSelectCoordinates?: (lat: number, lng: number) => void;
}> = ({
  latitude,
  longitude,
  zoom = 15,
  interactive = true,
  darkTheme = true,
  className = 'w-full h-64',
  onSelectCoordinates,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const markerRef = useRef<L.Marker | null>(null);
  const onSelectRef = useRef(onSelectCoordinates);
  onSelectRef.current = onSelectCoordinates;

  useEffect(() => {
    const el = containerRef.current;
    if (!el || mapRef.current) return;

    const map = L.map(el, {
      center: [latitude, longitude],
      zoom,
      zoomControl: interactive,
      dragging: interactive,
      scrollWheelZoom: interactive,
      doubleClickZoom: interactive,
      touchZoom: interactive,
      boxZoom: interactive,
      keyboard: interactive,
      attributionControl: true,
    });

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap',
    }).addTo(map);

    const marker = L.marker([latitude, longitude], {
      icon: createLunarPinIcon(),
      draggable: interactive && Boolean(onSelectRef.current),
    }).addTo(map);

    if (interactive) {
      marker.on('dragend', () => {
        const pos = marker.getLatLng();
        onSelectRef.current?.(pos.lat, pos.lng);
      });

      map.on('click', (e: L.LeafletMouseEvent) => {
        onSelectRef.current?.(e.latlng.lat, e.latlng.lng);
      });
    }

    mapRef.current = map;
    markerRef.current = marker;

    // Ensure proper tile sizing after modal/card mount or Android keyboard resize
    const resizeTimer = window.setTimeout(() => {
      map.invalidateSize();
    }, 140);

    let observer: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined') {
      observer = new ResizeObserver(() => {
        map.invalidateSize();
      });
      observer.observe(el);
    }

    return () => {
      window.clearTimeout(resizeTimer);
      observer?.disconnect();
      map.remove();
      mapRef.current = null;
      markerRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [interactive]);

  // Update pin and fly map smoothly when coordinates change
  useEffect(() => {
    const map = mapRef.current;
    const marker = markerRef.current;
    if (!map || !marker) return;

    marker.setLatLng([latitude, longitude]);
    const currentCenter = map.getCenter();
    const dist = currentCenter.distanceTo([latitude, longitude]);
    if (dist > 5) {
      map.setView([latitude, longitude], Math.max(map.getZoom(), 15), {
        animate: true,
      });
    }
  }, [latitude, longitude]);

  return (
    <div
      ref={containerRef}
      className={`${className} ${darkTheme ? 'moon-dark-map' : ''}`}
    />
  );
};

/**
 * Shared Location Preview Card Rendered Inside 1-to-1 Chat Bubbles
 */
export const LunarLocationChatCard: React.FC<{
  location: ChatLocationAttachment;
  onExpandInteractiveMap: (location: ChatLocationAttachment) => void;
}> = ({ location, onExpandInteractiveMap }) => {
  const gmapsViewUrl = getGoogleMapsViewUrl(
    location.latitude,
    location.longitude
  );
  const gmapsDirectionsUrl = getGoogleMapsDirectionsUrl(
    location.latitude,
    location.longitude
  );

  const sourceLabel =
    location.source === 'gps'
      ? 'Current GPS Location'
      : location.source === 'search'
      ? 'Selected Destination'
      : 'Pinned Map Location';

  return (
    <div className="w-64 sm:w-80 space-y-2">
      <div className="rounded-xl overflow-hidden bg-[#06020B]/95 border border-rose-500/35 shadow-[0_8px_24px_rgba(0,0,0,0.85)]">
        {/* Mini OpenStreetMap + Leaflet Preview */}
        <div className="relative h-40 w-full bg-[#050208]">
          <LeafletMapCanvas
            latitude={location.latitude}
            longitude={location.longitude}
            zoom={15}
            interactive={false}
            darkTheme={true}
            className="w-full h-full"
          />

          {/* Top Source Badge + Expand Button */}
          <div className="absolute top-2 left-2 right-2 z-[400] flex items-center justify-between gap-2 pointer-events-none">
            <span className="px-2 py-0.5 rounded-lg bg-black/80 border border-rose-500/40 text-[10px] font-semibold text-rose-200 inline-flex items-center gap-1 shadow-md">
              <MapPin className="w-3 h-3 text-rose-400 shrink-0" />
              <span>{sourceLabel}</span>
            </span>

            <button
              type="button"
              onClick={() => onExpandInteractiveMap(location)}
              aria-label="Expand interactive map"
              className="pointer-events-auto min-h-[30px] px-2 rounded-lg bg-black/80 hover:bg-black border border-rose-500/40 text-white inline-flex items-center gap-1 text-[10px] font-medium shadow-md cursor-pointer"
            >
              <Maximize2 className="w-3 h-3 text-rose-300" />
              <span>Map</span>
            </button>
          </div>

          {/* Coordinates Pill at Bottom-Left of Map */}
          <div className="absolute bottom-1.5 left-2 z-[400] pointer-events-none">
            <span className="px-2 py-0.5 rounded bg-black/85 border border-white/10 font-mono text-[10px] text-[#E2E8F0]">
              {location.latitude.toFixed(5)}, {location.longitude.toFixed(5)}
              {location.accuracyMeters
                ? ` (±${location.accuracyMeters}m)`
                : ''}
            </span>
          </div>
        </div>

        {/* Location Details & Place Title */}
        <div className="p-3 space-y-2.5 bg-gradient-to-b from-[#0C0414] to-[#050209]">
          <div className="space-y-0.5">
            <div className="flex items-start justify-between gap-2">
              <h4 className="font-display text-xs sm:text-sm font-semibold text-white leading-snug break-words">
                {location.label}
              </h4>
            </div>
            {location.address && (
              <p className="text-[11px] text-[#CBD5E1] line-clamp-2 leading-relaxed">
                {location.address}
              </p>
            )}
          </div>

          {/* Action Buttons: Open in Google Maps + Directions */}
          <div className="grid grid-cols-2 gap-1.5 pt-0.5">
            <a
              href={gmapsViewUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="min-h-[36px] px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-[#6D28D9] to-[#9F1239] hover:from-[#7C3AED] hover:to-[#BE123C] text-white border border-rose-400/40 text-[11px] font-medium flex items-center justify-center gap-1.5 shadow-[0_0_14px_rgba(225,29,72,0.28)] transition-all"
            >
              <ExternalLink className="w-3.5 h-3.5 shrink-0" />
              <span className="truncate">Google Maps</span>
            </a>

            <a
              href={gmapsDirectionsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="min-h-[36px] px-2.5 py-1.5 rounded-xl bg-[#160A24] hover:bg-[#221035] text-rose-200 hover:text-white border border-rose-500/35 text-[11px] font-medium flex items-center justify-center gap-1.5 transition-colors"
            >
              <Navigation className="w-3.5 h-3.5 text-rose-300 shrink-0" />
              <span className="truncate">Directions</span>
            </a>
          </div>
        </div>
      </div>

      {/* Optional Caption Below Card */}
      {location.caption && (
        <p className="whitespace-pre-wrap break-words text-sm leading-relaxed px-0.5">
          {location.caption}
        </p>
      )}
    </div>
  );
};

/**
 * Full-Screen Interactive Map Viewer Modal (When user taps "Map" on a shared chat location card)
 */
export const LunarLocationViewerModal: React.FC<{
  location: ChatLocationAttachment | null;
  onClose: () => void;
}> = ({ location, onClose }) => {
  const [darkMap, setDarkMap] = useState(true);

  if (!location) return null;

  const gmapsViewUrl = getGoogleMapsViewUrl(
    location.latitude,
    location.longitude
  );
  const gmapsDirectionsUrl = getGoogleMapsDirectionsUrl(
    location.latitude,
    location.longitude
  );

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Interactive shared location map"
      onClick={onClose}
      className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex flex-col items-center justify-center p-4 sm:p-6 animate-fade-in"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-3xl rounded-3xl bg-[#07030C] border border-rose-500/40 overflow-hidden shadow-[0_24px_70px_rgba(0,0,0,0.95),0_0_40px_rgba(225,29,72,0.22)] flex flex-col"
      >
        {/* Header */}
        <div className="px-4 sm:px-5 py-3.5 bg-[#09030F] border-b border-[#2D142C] flex items-center justify-between gap-3">
          <div className="min-w-0 flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#1A0B26] border border-rose-500/40 flex items-center justify-center shrink-0">
              <MapPin className="w-4 h-4 text-rose-300" />
            </div>
            <div className="min-w-0">
              <h3 className="font-display text-sm sm:text-base font-semibold text-white truncate">
                {location.label}
              </h3>
              <p className="text-[11px] text-[#CBD5E1] font-mono truncate">
                {location.latitude.toFixed(6)}, {location.longitude.toFixed(6)}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setDarkMap((prev) => !prev)}
              className="min-h-[36px] px-2.5 rounded-xl bg-[#14081E] hover:bg-[#220E33] border border-rose-500/30 text-[11px] font-medium text-rose-200 cursor-pointer"
            >
              {darkMap ? 'Standard Map' : 'AMOLED Map'}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="min-h-[36px] px-3 rounded-xl bg-[#1A0B26] hover:bg-rose-600 text-white border border-rose-500/40 inline-flex items-center gap-1.5 text-xs font-medium cursor-pointer"
            >
              <X className="w-4 h-4" />
              <span>Close</span>
            </button>
          </div>
        </div>

        {/* Interactive Leaflet Map */}
        <div className="relative h-80 sm:h-96 w-full bg-black">
          <LeafletMapCanvas
            latitude={location.latitude}
            longitude={location.longitude}
            zoom={16}
            interactive={true}
            darkTheme={darkMap}
            className="w-full h-full"
          />
        </div>

        {/* Footer with Address & Open in Google Maps Navigation */}
        <div className="p-4 sm:p-5 bg-[#08030E] border-t border-[#2D142C] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1 min-w-0">
            {location.address && (
              <p className="text-xs text-[#E2E8F0] leading-relaxed">
                {location.address}
              </p>
            )}
            {location.caption && (
              <p className="text-xs text-rose-200 italic">
                “{location.caption}”
              </p>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <a
              href={gmapsDirectionsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="min-h-[40px] px-3.5 py-2 rounded-xl bg-[#160A24] hover:bg-[#241038] text-rose-200 hover:text-white border border-rose-500/35 text-xs font-medium inline-flex items-center gap-1.5 transition-colors"
            >
              <Navigation className="w-4 h-4 text-rose-300" />
              <span>Directions</span>
            </a>

            <a
              href={gmapsViewUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="min-h-[40px] px-4 py-2 rounded-xl bg-gradient-to-r from-[#6D28D9] to-[#9F1239] hover:from-[#7C3AED] hover:to-[#BE123C] text-white border border-rose-400/40 text-xs font-semibold inline-flex items-center gap-1.5 shadow-[0_0_16px_rgba(225,29,72,0.35)] transition-all"
            >
              <ExternalLink className="w-4 h-4" />
              <span>Open in Google Maps</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

/**
 * Interactive Location & Destination Picker Modal (Opened from Chat Attachment Bar)
 * - Strictly never accesses GPS unless user clicks "Use My Current GPS Location"
 * - Strictly never shares location until user explicitly clicks "Send Location"
 */
export const LunarLocationPickerModal: React.FC<{
  isOpen: boolean;
  friendDisplayName: string;
  onClose: () => void;
  onConfirmSendLocation: (
    location: Omit<ChatLocationAttachment, 'version'>
  ) => Promise<void>;
}> = ({ isOpen, friendDisplayName, onClose, onConfirmSendLocation }) => {
  // Default initial map center (New Delhi / Central view) before user grants GPS or searches
  const [latitude, setLatitude] = useState<number>(28.6139);
  const [longitude, setLongitude] = useState<number>(77.209);
  const [label, setLabel] = useState<string>('India Gate, New Delhi');
  const [address, setAddress] = useState<string>(
    'Kartavya Path, India Gate, New Delhi, Delhi, India'
  );
  const [source, setSource] = useState<LocationShareSource>('pin');
  const [accuracyMeters, setAccuracyMeters] = useState<number | undefined>(
    undefined
  );
  const [caption, setCaption] = useState<string>('');
  const [darkMap, setDarkMap] = useState<boolean>(true);

  // GPS State
  const [isLocatingGps, setIsLocatingGps] = useState<boolean>(false);
  const [gpsError, setGpsError] = useState<string | null>(null);

  // Place Search State
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isSearching, setIsSearching] = useState<boolean>(false);
  const [searchResults, setSearchResults] = useState<NominatimPlaceResult[]>(
    []
  );
  const [searchError, setSearchError] = useState<string | null>(null);

  // Reverse Geocoding & Sending State
  const [isReverseGeocoding, setIsReverseGeocoding] = useState<boolean>(false);
  const [isSending, setIsSending] = useState<boolean>(false);
  const [sendError, setSendError] = useState<string | null>(null);

  if (!isOpen) return null;

  /**
   * Requirement 2 & 8: Browser Geolocation with explicit user action & permission handling.
   * Uses one-shot getCurrentPosition (never background watchPosition).
   */
  const handleRequestCurrentGpsLocation = () => {
    setGpsError(null);
    setSendError(null);

    if (typeof navigator === 'undefined' || !('geolocation' in navigator)) {
      setGpsError(
        'Geolocation is not supported by your current browser or WebView.'
      );
      return;
    }

    setIsLocatingGps(true);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const lat = Number(pos.coords.latitude.toFixed(6));
        const lng = Number(pos.coords.longitude.toFixed(6));
        const acc = pos.coords.accuracy
          ? Math.round(pos.coords.accuracy)
          : undefined;

        setLatitude(lat);
        setLongitude(lng);
        setSource('gps');
        setAccuracyMeters(acc);
        setLabel('My Current GPS Location');
        setAddress(`${lat.toFixed(5)}, ${lng.toFixed(5)}`);
        setIsLocatingGps(false);

        setIsReverseGeocoding(true);
        const rev = await reverseGeocodeNominatim(lat, lng);
        setIsReverseGeocoding(false);
        setLabel(
          rev.label !== 'Pinned Map Location'
            ? `Current GPS · ${rev.label}`
            : 'My Current GPS Location'
        );
        setAddress(rev.address);
      },
      (err) => {
        setIsLocatingGps(false);
        if (err.code === 1) {
          setGpsError(
            'Location permission was denied. Please allow Location access in your browser/Android site settings, or search & tap any destination on the map below.'
          );
        } else if (err.code === 2) {
          setGpsError(
            'Current GPS position is unavailable. Check that device GPS/Location Services are turned on, or search a place below.'
          );
        } else if (err.code === 3) {
          setGpsError(
            'GPS request timed out. Please try again in an area with clearer sky view or select a location on the map.'
          );
        } else {
          setGpsError(
            err.message || 'Could not retrieve current GPS location.'
          );
        }
      },
      {
        enableHighAccuracy: true,
        timeout: 12000,
        maximumAge: 0,
      }
    );
  };

  /**
   * Requirement 3: Search any destination worldwide via OpenStreetMap Nominatim
   */
  const handleSearchSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = searchQuery.trim();
    if (!trimmed || isSearching) return;

    setIsSearching(true);
    setSearchError(null);
    setGpsError(null);

    try {
      const results = await searchPlacesNominatim(trimmed);
      setSearchResults(results);
      if (results.length === 0) {
        setSearchError(
          `No places found matching "${trimmed}". Try a city, landmark, or street name.`
        );
      } else {
        // Automatically preview the top search result on the map (still requires explicit Send to share)
        const top = results[0];
        const lat = Number.parseFloat(top.lat);
        const lng = Number.parseFloat(top.lon);
        if (Number.isFinite(lat) && Number.isFinite(lng)) {
          setLatitude(Number(lat.toFixed(6)));
          setLongitude(Number(lng.toFixed(6)));
          setLabel(
            top.name || top.display_name.split(',')[0] || 'Selected Place'
          );
          setAddress(top.display_name);
          setSource('search');
          setAccuracyMeters(undefined);
        }
      }
    } catch (err) {
      setSearchError(
        err instanceof Error
          ? err.message
          : 'Could not search destination. You can still tap directly on the map.'
      );
    } finally {
      setIsSearching(false);
    }
  };

  const handleSelectSearchResult = (item: NominatimPlaceResult) => {
    const lat = Number.parseFloat(item.lat);
    const lng = Number.parseFloat(item.lon);
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) return;

    setLatitude(Number(lat.toFixed(6)));
    setLongitude(Number(lng.toFixed(6)));
    setLabel(item.name || item.display_name.split(',')[0] || 'Selected Place');
    setAddress(item.display_name);
    setSource('search');
    setAccuracyMeters(undefined);
    setSearchResults([]);
  };

  /**
   * Requirement 4 & 5: Tap anywhere on the interactive map or drag the pin
   */
  const handleMapPinSelected = async (lat: number, lng: number) => {
    const cleanLat = Number(lat.toFixed(6));
    const cleanLng = Number(lng.toFixed(6));
    setLatitude(cleanLat);
    setLongitude(cleanLng);
    setSource('pin');
    setAccuracyMeters(undefined);
    setGpsError(null);

    setIsReverseGeocoding(true);
    const rev = await reverseGeocodeNominatim(cleanLat, cleanLng);
    setIsReverseGeocoding(false);
    setLabel(rev.label);
    setAddress(rev.address);
  };

  /**
   * Explicit user action to send the selected location to the friend
   */
  const handleSendClicked = async () => {
    if (isSending) return;
    setIsSending(true);
    setSendError(null);

    try {
      await onConfirmSendLocation({
        latitude,
        longitude,
        label: label.trim() || 'Shared Location',
        address: address.trim() || undefined,
        caption: caption.trim() || undefined,
        source,
        accuracyMeters,
      });
      onClose();
    } catch (err) {
      setSendError(
        err instanceof Error
          ? err.message
          : 'Failed to send location to friend.'
      );
    } finally {
      setIsSending(false);
    }
  };

  const quickDestinations = [
    {
      label: 'India Gate, New Delhi',
      lat: 28.6129,
      lng: 77.2295,
      addr: 'Kartavya Path, India Gate, New Delhi, India',
    },
    {
      label: 'Gateway of India, Mumbai',
      lat: 18.922,
      lng: 72.8347,
      addr: 'Apollo Bandar, Colaba, Mumbai, Maharashtra, India',
    },
    {
      label: 'Taj Mahal, Agra',
      lat: 27.1751,
      lng: 78.0421,
      addr: 'Dharmapuri, Forest Colony, Tajganj, Agra, India',
    },
  ];

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Share Location & Destination Picker"
      onClick={onClose}
      className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 overflow-y-auto animate-fade-in"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-2xl rounded-3xl bg-[#07030C] border border-rose-500/40 overflow-hidden shadow-[0_24px_75px_rgba(0,0,0,0.95),0_0_40px_rgba(225,29,72,0.22)] flex flex-col max-h-[92vh]"
      >
        {/* Top Modal Header */}
        <div className="px-4 sm:px-5 py-3.5 bg-[#09030F] border-b border-[#2D142C] flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#6D28D9]/40 to-[#9F1239]/40 border border-rose-500/40 flex items-center justify-center shrink-0">
              <Compass className="w-4 h-4 text-rose-300" />
            </div>
            <div className="min-w-0">
              <h3 className="font-display text-sm sm:text-base font-bold text-white truncate">
                Share Location with {friendDisplayName}
              </h3>
              <p className="text-[11px] text-[#CBD5E1] truncate">
                GPS on demand · Destination search · Friend-only RLS
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close location modal"
            className="min-h-[36px] min-w-[36px] rounded-xl bg-[#160A24] hover:bg-rose-950/80 border border-rose-500/35 text-rose-200 hover:text-white flex items-center justify-center cursor-pointer shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {/* Row 1: Current GPS Location Button + Map Theme Toggle */}
          <div className="flex flex-wrap items-center justify-between gap-2.5">
            <button
              type="button"
              onClick={handleRequestCurrentGpsLocation}
              disabled={isLocatingGps || isSending}
              className="flex-1 min-w-[210px] min-h-[42px] px-4 py-2 rounded-2xl bg-gradient-to-r from-[#6D28D9] via-[#5B21B6] to-[#9F1239] hover:from-[#7C3AED] hover:to-[#BE123C] text-white border border-rose-400/40 text-xs font-semibold inline-flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(225,29,72,0.3)] transition-all disabled:opacity-60 cursor-pointer"
            >
              {isLocatingGps ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-rose-200" />
                  <span>Requesting GPS Permission & Signal...</span>
                </>
              ) : (
                <>
                  <LocateFixed className="w-4 h-4 text-rose-200" />
                  <span>Use My Current GPS Location</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={() => setDarkMap((prev) => !prev)}
              className="min-h-[42px] px-3.5 rounded-2xl bg-[#13081E] hover:bg-[#1E0C2E] border border-rose-500/30 text-xs font-medium text-rose-200 hover:text-white transition-colors cursor-pointer"
            >
              {darkMap ? 'Standard Map' : 'AMOLED Map'}
            </button>
          </div>

          {/* GPS / Search / Send Error Notice */}
          {(gpsError || searchError || sendError) && (
            <div className="rounded-2xl bg-[#260917]/90 border border-rose-500/45 p-3 flex items-start gap-2.5 text-xs text-rose-100">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <span className="leading-relaxed">
                {gpsError || searchError || sendError}
              </span>
            </div>
          )}

          {/* Row 2: Destination Search Bar */}
          <form onSubmit={handleSearchSubmit} className="space-y-2">
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-[#8E8AA6] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search any city, landmark, cafe, or address..."
                  className="w-full min-h-[42px] pl-10 pr-3.5 py-2 rounded-2xl bg-[#040208] border border-[#351635] focus:border-rose-500/80 text-xs sm:text-sm text-white placeholder-[#7E7291] focus:outline-none"
                />
              </div>
              <button
                type="submit"
                disabled={!searchQuery.trim() || isSearching}
                className="min-h-[42px] px-4 rounded-2xl bg-[#180A29] hover:bg-[#24103C] border border-rose-500/35 text-xs font-semibold text-rose-200 hover:text-white inline-flex items-center gap-1.5 disabled:opacity-50 cursor-pointer"
              >
                {isSearching ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Search className="w-3.5 h-3.5" />
                )}
                <span>Search</span>
              </button>
            </div>

            {/* Quick Landmark Presets */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5">
              <span className="text-[10px] text-[#948CA8] shrink-0 inline-flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-rose-400" />
                <span>Quick:</span>
              </span>
              {quickDestinations.map((dest) => (
                <button
                  key={dest.label}
                  type="button"
                  onClick={() => {
                    setLatitude(dest.lat);
                    setLongitude(dest.lng);
                    setLabel(dest.label);
                    setAddress(dest.addr);
                    setSource('search');
                    setAccuracyMeters(undefined);
                    setSearchResults([]);
                  }}
                  className="px-2.5 py-1 rounded-lg bg-[#11071B] hover:bg-[#1E0C2E] border border-[#2D142C] text-[11px] text-[#CBD5E1] hover:text-white whitespace-nowrap shrink-0 cursor-pointer"
                >
                  {dest.label}
                </button>
              ))}
            </div>

            {/* Search Result Dropdown List */}
            {searchResults.length > 0 && (
              <div className="rounded-2xl bg-[#0A0412] border border-rose-500/35 divide-y divide-[#241028] overflow-hidden max-h-44 overflow-y-auto">
                {searchResults.map((item) => (
                  <button
                    key={item.place_id}
                    type="button"
                    onClick={() => handleSelectSearchResult(item)}
                    className="w-full px-3.5 py-2.5 text-left hover:bg-[#180A28] transition-colors flex items-start gap-2.5 cursor-pointer"
                  >
                    <MapPin className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-semibold text-white truncate">
                        {item.name || item.display_name.split(',')[0]}
                      </p>
                      <p className="text-[11px] text-[#CBD5E1] truncate">
                        {item.display_name}
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </form>

          {/* Row 3: Interactive OpenStreetMap + Leaflet Map */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-[11px] text-[#CBD5E1]">
              <span>
                Tap anywhere on the map or drag the crimson pin to adjust
                location:
              </span>
              {isReverseGeocoding && (
                <span className="inline-flex items-center gap-1 text-rose-300">
                  <Loader2 className="w-3 h-3 animate-spin" />
                  <span>Resolving address...</span>
                </span>
              )}
            </div>

            <div className="relative rounded-2xl overflow-hidden border border-rose-500/40 h-56 sm:h-64 bg-[#050208] shadow-[0_12px_30px_rgba(0,0,0,0.85)]">
              <LeafletMapCanvas
                latitude={latitude}
                longitude={longitude}
                zoom={15}
                interactive={true}
                darkTheme={darkMap}
                className="w-full h-full"
                onSelectCoordinates={handleMapPinSelected}
              />
            </div>
          </div>

          {/* Row 4: Selected Place Details & Optional Caption */}
          <div className="rounded-2xl bg-black/75 border border-rose-500/30 p-3.5 space-y-3">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0 flex-1 space-y-1">
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="px-2 py-0.5 rounded-md bg-rose-500/20 border border-rose-500/40 text-[10px] font-semibold uppercase tracking-wider text-rose-200">
                    {source === 'gps'
                      ? 'Current GPS'
                      : source === 'search'
                      ? 'Searched Place'
                      : 'Custom Map Pin'}
                  </span>
                  <span className="font-mono text-[11px] text-rose-300">
                    {latitude.toFixed(6)}, {longitude.toFixed(6)}
                    {accuracyMeters ? ` (±${accuracyMeters}m)` : ''}
                  </span>
                </div>

                <input
                  type="text"
                  value={label}
                  onChange={(e) => setLabel(e.target.value)}
                  placeholder="Location title (e.g., Central Cafe, Home, Gate 2)"
                  className="w-full px-2.5 py-1.5 rounded-xl bg-[#09030F] border border-[#2D142C] focus:border-rose-500/70 text-xs sm:text-sm font-semibold text-white focus:outline-none"
                />

                {address && (
                  <p className="text-[11px] text-[#CBD5E1] leading-relaxed px-0.5">
                    {address}
                  </p>
                )}
              </div>

              <a
                href={getGoogleMapsViewUrl(latitude, longitude)}
                target="_blank"
                rel="noopener noreferrer"
                title="Preview in Google Maps"
                className="min-h-[36px] px-2.5 rounded-xl bg-[#160A24] hover:bg-[#241038] border border-rose-500/35 text-rose-200 hover:text-white text-[11px] font-medium inline-flex items-center gap-1 shrink-0"
              >
                <ExternalLink className="w-3.5 h-3.5 text-rose-300" />
                <span className="hidden sm:inline">Google Maps</span>
              </a>
            </div>

            <input
              type="text"
              value={caption}
              onChange={(e) => setCaption(e.target.value)}
              placeholder={`Add a note for ${friendDisplayName} (optional)...`}
              className="w-full px-3 py-2 rounded-xl bg-[#040208] border border-[#351635] focus:border-rose-500/80 text-xs text-white placeholder-[#7E7291] focus:outline-none"
            />
          </div>
        </div>

        {/* Bottom Footer: Privacy Notice + Cancel / Explicit Send Button */}
        <div className="px-4 sm:px-5 py-3.5 bg-[#09030F] border-t border-[#2D142C] flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-1.5 text-[11px] text-[#CBD5E1]">
            <Lock className="w-3.5 h-3.5 text-rose-400 shrink-0" />
            <span>
              No background tracking · Shared only when you press Send
            </span>
          </div>

          <div className="flex items-center gap-2 ml-auto">
            <MoonButton
              type="button"
              variant="secondary"
              onClick={onClose}
              disabled={isSending}
            >
              Cancel
            </MoonButton>
            <MoonButton
              type="button"
              variant="primary"
              onClick={handleSendClicked}
              isLoading={isSending}
              leftIcon={<Send className="w-4 h-4" />}
            >
              Send Location
            </MoonButton>
          </div>
        </div>
      </div>
    </div>
  );
};
