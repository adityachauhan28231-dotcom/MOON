import React from 'react';
import { AlertCircle, Check, Loader2, RefreshCw } from 'lucide-react';
import { PresenceState } from '../../types/moon';

interface MoonButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  size?: 'md' | 'lg';
  isLoading?: boolean;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  fullWidth?: boolean;
}

export const MoonButton: React.FC<MoonButtonProps> = ({
  children,
  variant = 'primary',
  size = 'md',
  isLoading = false,
  leftIcon,
  rightIcon,
  fullWidth = false,
  className = '',
  disabled,
  ...props
}) => {
  const baseClasses =
    'inline-flex items-center justify-center gap-2.5 font-medium rounded-xl transition-all duration-150 active:scale-[0.98] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500 focus-visible:ring-offset-2 focus-visible:ring-offset-black disabled:opacity-50 disabled:pointer-events-none whitespace-nowrap shrink-0 cursor-pointer';

  const sizeClasses =
    size === 'lg'
      ? 'min-h-[48px] px-5 py-3 text-sm'
      : 'min-h-[44px] px-4 py-2.5 text-sm';

  const variantClasses = {
    primary:
      'bg-gradient-to-r from-[#6D28D9] via-[#7E1D53] to-[#9F1239] hover:from-[#7C3AED] hover:via-[#9D174D] hover:to-[#BE123C] text-white border border-rose-400/35 shadow-[0_6px_26px_rgba(190,18,60,0.38)]',
    secondary:
      'bg-[#0D0714]/90 hover:bg-[#190D24] text-[#F6F4FA] border border-[#341832] shadow-[0_4px_16px_rgba(0,0,0,0.65)]',
    ghost:
      'bg-transparent hover:bg-[#170B1E] text-[#C8C2D8] hover:text-white',
    danger:
      'bg-[#2B0914] hover:bg-[#3F0D1D] text-rose-100 border border-rose-500/45 shadow-[0_6px_22px_rgba(225,29,72,0.3)]',
  }[variant];

  return (
    <button
      disabled={disabled || isLoading}
      className={`${baseClasses} ${sizeClasses} ${variantClasses} ${
        fullWidth ? 'w-full' : ''
      } ${className}`}
      {...props}
    >
      {isLoading ? (
        <Loader2 className="w-4 h-4 animate-spin text-rose-200 shrink-0" />
      ) : (
        leftIcon
      )}
      <span>{children}</span>
      {!isLoading && rightIcon}
    </button>
  );
};

interface MoonInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  hint?: string;
  errorText?: string;
  rightSlot?: React.ReactNode;
  mono?: boolean;
}

export const MoonInput: React.FC<MoonInputProps> = ({
  label,
  hint,
  errorText,
  rightSlot,
  mono = false,
  className = '',
  id,
  ...props
}) => {
  const inputId =
    id || `moon-input-${label?.toLowerCase().replace(/\s+/g, '-')}`;

  return (
    <div className="w-full space-y-1.5">
      {label && (
        <label
          htmlFor={inputId}
          className="block text-xs font-medium text-[#D5CFE4] tracking-wide"
        >
          {label}
        </label>
      )}
      <div className="relative flex items-center">
        <input
          id={inputId}
          className={`w-full min-h-[46px] px-3.5 py-2.5 rounded-xl bg-[#050308]/95 border ${
            errorText
              ? 'border-rose-500/70 focus:border-rose-400'
              : 'border-[#2E162D] focus:border-rose-500/70'
          } text-sm text-[#F8FAFC] placeholder-[#6E647E] focus:outline-none focus:ring-2 focus:ring-rose-500/20 transition-colors ${
            mono ? 'font-mono tracking-wider uppercase' : ''
          } ${rightSlot ? 'pr-12' : ''} ${className}`}
          {...props}
        />
        {rightSlot && (
          <div className="absolute right-1.5 flex items-center">{rightSlot}</div>
        )}
      </div>
      {errorText ? (
        <p className="text-xs text-rose-300 flex items-center gap-1.5 pt-0.5">
          <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
          <span>{errorText}</span>
        </p>
      ) : hint ? (
        <p className="text-xs text-[#9188A6]">{hint}</p>
      ) : null}
    </div>
  );
};

interface LunarAvatarProps {
  name: string;
  hue?: number;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  presence?: PresenceState;
}

export const LunarAvatar: React.FC<LunarAvatarProps> = ({
  name,
  hue = 268,
  size = 'md',
}) => {
  const initials =
    name
      .split(/[\s_]+/)
      .filter(Boolean)
      .slice(0, 2)
      .map((part) => part[0]?.toUpperCase())
      .join('') || 'M';

  const sizeStyles = {
    sm: 'w-9 h-9 text-xs rounded-xl',
    md: 'w-11 h-11 text-sm rounded-2xl',
    lg: 'w-14 h-14 text-base rounded-2xl',
    xl: 'w-24 h-24 text-2xl rounded-3xl',
  }[size];

  return (
    <div
      style={{
        background: `radial-gradient(circle at 28% 22%, rgba(225, 29, 72, 0.36), hsla(${hue}, 72%, 30%, 0.48) 52%, #07030C 88%)`,
      }}
      className={`relative inline-flex items-center justify-center font-display font-semibold text-[#F8FAFC] border border-rose-400/30 shadow-[0_0_18px_rgba(190,18,60,0.22)] shrink-0 select-none ${sizeStyles}`}
    >
      <span>{initials}</span>
    </div>
  );
};

interface ErrorBannerProps {
  title?: string;
  message: string;
  onRetry?: () => void;
  onDismiss?: () => void;
}

export const ErrorBanner: React.FC<ErrorBannerProps> = ({
  title = 'Action could not be completed',
  message,
  onRetry,
  onDismiss,
}) => {
  return (
    <div
      role="alert"
      className="p-4 rounded-2xl bg-[#180710]/95 border border-rose-500/40 text-rose-100 space-y-2.5 shadow-[0_8px_28px_rgba(0,0,0,0.75)]"
    >
      <div className="flex items-start gap-3">
        <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
        <div className="flex-1 min-w-0 space-y-1">
          <p className="text-sm font-semibold text-rose-200">{title}</p>
          <p className="text-xs text-rose-100/85 leading-relaxed">{message}</p>
        </div>
      </div>
      {(onRetry || onDismiss) && (
        <div className="flex items-center justify-end gap-2 pt-1">
          {onDismiss && (
            <button
              type="button"
              onClick={onDismiss}
              className="min-h-[40px] px-3 text-xs font-medium text-rose-200/80 hover:text-white rounded-lg transition-colors cursor-pointer"
            >
              Dismiss
            </button>
          )}
          {onRetry && (
            <button
              type="button"
              onClick={onRetry}
              className="min-h-[40px] px-3.5 py-1.5 text-xs font-medium bg-rose-500/20 hover:bg-rose-500/30 border border-rose-400/35 text-rose-100 rounded-lg inline-flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Try Again</span>
            </button>
          )}
        </div>
      )}
    </div>
  );
};

export const LoadingListSkeleton: React.FC<{
  rows?: number;
  label?: string;
}> = ({ rows = 3, label = 'Synchronizing lunar directory...' }) => {
  return (
    <div className="space-y-3 py-2" aria-busy="true">
      <div className="flex items-center gap-2 text-xs text-rose-200/85 px-1">
        <Loader2 className="w-3.5 h-3.5 animate-spin text-rose-400" />
        <span>{label}</span>
      </div>
      {Array.from({ length: rows }).map((_, idx) => (
        <div
          key={idx}
          className="h-16 rounded-2xl bg-[#0A0510]/85 border border-[#281326] p-3.5 flex items-center gap-3 animate-pulse"
        >
          <div className="w-10 h-10 rounded-xl bg-rose-950/45 shrink-0" />
          <div className="flex-1 space-y-2">
            <div className="h-3 w-28 rounded bg-purple-900/35" />
            <div className="h-2.5 w-44 rounded bg-[#1C0E24]" />
          </div>
        </div>
      ))}
    </div>
  );
};

export const CopyFeedbackButton: React.FC<{
  value: string;
  label?: string;
}> = ({ value, label = 'Copy Code' }) => {
  const [copied, setCopied] = React.useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    }
  };

  return (
    <MoonButton
      type="button"
      variant="secondary"
      onClick={handleCopy}
      leftIcon={
        copied ? <Check className="w-4 h-4 text-rose-300" /> : undefined
      }
    >
      {copied ? 'Copied' : label}
    </MoonButton>
  );
};
