import React, { useState } from 'react';
import {
  CheckCircle2,
  Download,
  MoreVertical,
  Smartphone,
  X,
} from 'lucide-react';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import { CopyFeedbackButton, MoonButton } from './ReusablePrimitives';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, swReady, triggerNativeInstall } =
    usePWAInstall();
  const [showFallbackGuide, setShowFallbackGuide] = useState(false);

  // Automatically hide button when running as an installed standalone PWA
  if (isInstalled) {
    return null;
  }

  const handleInstallClick = async () => {
    if (isInstallable) {
      const accepted = await triggerNativeInstall();
      if (accepted) {
        return;
      }
    }
    setShowFallbackGuide(true);
  };

  const appUrl =
    typeof window !== 'undefined' ? window.location.origin : '';

  return (
    <>
      <button
        type="button"
        onClick={handleInstallClick}
        className="min-h-[38px] px-3 py-1.5 rounded-xl bg-[#161329] hover:bg-[#6D28D9] border border-purple-500/35 text-xs font-medium text-purple-200 hover:text-white inline-flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        title="Install MOON on Android Home Screen"
      >
        <Download className="w-3.5 h-3.5 text-purple-300" />
        <span>Install App</span>
      </button>

      {showFallbackGuide && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="pwa-install-modal-title"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md"
        >
          <div className="w-full max-w-md rounded-3xl bg-[#0B0915] border border-purple-500/40 p-6 shadow-[0_24px_70px_rgba(0,0,0,0.85)] text-left space-y-5 relative">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-[#1A1433] border border-purple-500/35 flex items-center justify-center shrink-0">
                  <Smartphone className="w-5 h-5 text-purple-300" />
                </div>
                <div>
                  <h3
                    id="pwa-install-modal-title"
                    className="font-display text-lg font-bold text-white"
                  >
                    Install MOON on Your Phone
                  </h3>
                  <p className="text-xs text-[#9B97B2]">
                    {swReady
                      ? 'PWA Manifest & Service Worker Ready'
                      : 'Standalone Home Screen App'}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setShowFallbackGuide(false)}
                aria-label="Close install guide"
                className="min-h-[38px] min-w-[38px] rounded-xl bg-[#141225] hover:bg-[#1E1B36] text-[#9B97B2] hover:text-white flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {isIOS ? (
              <div className="rounded-2xl bg-[#110F1F] border border-[#24203B] p-4 space-y-2.5 text-xs text-[#D5D1E8] leading-relaxed">
                <p className="font-semibold text-purple-200">
                  iPhone / iPad Safari Instructions:
                </p>
                <ol className="list-decimal list-inside space-y-1.5 text-[#B8B5C8]">
                  <li>
                    Tap the <strong className="text-white">Share</strong> button in Safari&apos;s bottom bar.
                  </li>
                  <li>
                    Scroll down and tap{' '}
                    <strong className="text-white">Add to Home Screen</strong>.
                  </li>
                  <li>
                    Launch <strong className="text-white">MOON</strong> from your Home Screen in standalone full-screen mode.
                  </li>
                </ol>
              </div>
            ) : (
              <div className="rounded-2xl bg-[#110F1F] border border-[#24203B] p-4 space-y-3 text-xs text-[#D5D1E8] leading-relaxed">
                <p className="font-semibold text-purple-200">
                  Android Chrome Installation Steps:
                </p>
                <ol className="list-decimal list-inside space-y-2 text-[#B8B5C8]">
                  <li>
                    Open MOON directly in{' '}
                    <strong className="text-white">Google Chrome</strong> on your Android phone (not inside an embedded preview frame).
                  </li>
                  <li>
                    Tap the Chrome menu icon{' '}
                    <span className="inline-flex items-center px-1.5 py-0.5 rounded bg-[#1D1934] text-purple-200 font-mono">
                      <MoreVertical className="w-3 h-3 inline" /> 3 dots
                    </span>{' '}
                    in the top-right corner.
                  </li>
                  <li>
                    Tap{' '}
                    <strong className="text-white">Install app</strong> or{' '}
                    <strong className="text-white">Add to Home screen</strong>.
                  </li>
                </ol>
              </div>
            )}

            {appUrl && (
              <div className="flex items-center justify-between gap-2 p-3 rounded-2xl bg-[#07060C] border border-[#1E1B32]">
                <span className="text-xs font-mono text-purple-300 truncate">
                  {appUrl}
                </span>
                <CopyFeedbackButton value={appUrl} label="Copy App URL" />
              </div>
            )}

            <div className="flex items-center justify-between gap-3 pt-1">
              <div className="flex items-center gap-1.5 text-[11px] text-purple-300">
                <CheckCircle2 className="w-3.5 h-3.5 text-purple-400" />
                <span>Opens in standalone mode</span>
              </div>

              <MoonButton
                type="button"
                variant="primary"
                onClick={() => setShowFallbackGuide(false)}
              >
                Got It
              </MoonButton>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
