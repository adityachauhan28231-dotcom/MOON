import React from 'react';
import { Phone, PhoneOff, ShieldCheck } from 'lucide-react';
import { VoiceCallSignalPayload } from '../../types/moon';
import { LunarAvatar } from './ReusablePrimitives';

interface IncomingCallModalProps {
  incomingSignal: VoiceCallSignalPayload | null;
  onAccept: (signal: VoiceCallSignalPayload) => void;
  onReject: (signal: VoiceCallSignalPayload) => void;
}

export const IncomingCallModal: React.FC<IncomingCallModalProps> = ({
  incomingSignal,
  onAccept,
  onReject,
}) => {
  if (!incomingSignal) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="incoming-call-title"
      className="fixed inset-0 z-50 flex items-center justify-center px-4 bg-black/85 backdrop-blur-md devil-screen-transition"
    >
      <div className="w-full max-w-sm rounded-3xl bg-[#08030D]/95 border border-rose-500/45 p-6 shadow-[0_24px_80px_rgba(190,18,60,0.45)] text-center space-y-6 relative overflow-hidden">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_20%,rgba(225,29,72,0.28),rgba(109,40,217,0.18)_48%,transparent_72%)]"
        />

        <div className="relative z-10 flex flex-col items-center space-y-4">
          <div className="inline-flex items-center gap-1.5 text-[11px] font-medium text-rose-200 tracking-wide">
            <ShieldCheck className="w-3.5 h-3.5 text-rose-400" />
            <span>Incoming Blood Moon Call · LiveKit</span>
          </div>

          <div className="relative flex items-center justify-center">
            <div className="w-28 h-28 rounded-full border-2 border-rose-500/55 bg-rose-950/30 shadow-[0_0_36px_rgba(225,29,72,0.4)] flex items-center justify-center animate-pulse">
              <LunarAvatar
                name={incomingSignal.fromDisplayName}
                hue={incomingSignal.fromAvatarHue}
                size="xl"
              />
            </div>
          </div>

          <div className="space-y-1">
            <h2
              id="incoming-call-title"
              className="font-display text-2xl font-bold text-[#F8FAFC]"
            >
              {incomingSignal.fromDisplayName}
            </h2>
            <p className="text-xs text-[#B8B0C8]">
              <span>@{incomingSignal.fromUsername}</span>
              {incomingSignal.fromFriendCode && (
                <>
                  <span className="mx-1.5" aria-hidden="true">
                    ·
                  </span>
                  <span className="font-mono text-rose-300">
                    {incomingSignal.fromFriendCode}
                  </span>
                </>
              )}
            </p>
            <p className="text-xs text-rose-200/90 pt-1">
              is calling you under the Blood Moon...
            </p>
          </div>
        </div>

        <div className="relative z-10 grid grid-cols-2 gap-3 pt-2">
          <button
            type="button"
            onClick={() => onReject(incomingSignal)}
            className="min-h-[52px] px-4 rounded-2xl bg-[#290813] hover:bg-[#3B0C1C] border border-rose-500/45 text-rose-100 text-xs font-semibold inline-flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <PhoneOff className="w-4 h-4 text-rose-400" />
            <span>Decline</span>
          </button>

          <button
            type="button"
            onClick={() => onAccept(incomingSignal)}
            className="min-h-[52px] px-4 rounded-2xl bg-gradient-to-r from-[#6D28D9] via-[#881337] to-[#BE123C] hover:from-[#7C3AED] hover:to-[#E11D48] border border-rose-300/40 text-white text-xs font-semibold inline-flex items-center justify-center gap-2 shadow-[0_8px_28px_rgba(225,29,72,0.5)] transition-all cursor-pointer"
          >
            <Phone className="w-4 h-4" />
            <span>Accept Call</span>
          </button>
        </div>
      </div>
    </div>
  );
};
