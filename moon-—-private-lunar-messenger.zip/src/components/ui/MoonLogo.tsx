import React from 'react';

interface MoonLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showWordmark?: boolean;
  showCreatorSubtitle?: boolean;
  headerCreatorBadge?: boolean;
  className?: string;
}

const SIZE_MAP = {
  sm: { box: 32, svg: 22, text: 'text-lg' },
  md: { box: 42, svg: 28, text: 'text-xl' },
  lg: { box: 68, svg: 46, text: 'text-3xl' },
  xl: { box: 92, svg: 64, text: 'text-4xl' },
};

export const MoonLogo: React.FC<MoonLogoProps> = ({
  size = 'md',
  showWordmark = false,
  showCreatorSubtitle = false,
  headerCreatorBadge = false,
  className = '',
}) => {
  const dims = SIZE_MAP[size];

  return (
    <div
      className={`inline-flex ${
        showCreatorSubtitle ? 'flex-col items-center gap-2' : 'items-center gap-3'
      } select-none ${className}`}
    >
      <div className="inline-flex items-center gap-3">
        <div
          style={{ width: dims.box, height: dims.box }}
          className="relative flex items-center justify-center rounded-2xl bg-[#07030A] border border-rose-500/35 shadow-[0_0_32px_rgba(225,29,72,0.28)] shrink-0"
        >
          {/* Subtle inner crimson-violet radial glow */}
          <div
            aria-hidden="true"
            className="absolute inset-1 rounded-xl bg-gradient-to-br from-rose-600/25 via-purple-900/15 to-transparent pointer-events-none"
          />

          {/* Bespoke Devil Blood Moon Crescent Emblem SVG */}
          <svg
            width={dims.svg}
            height={dims.svg}
            viewBox="0 0 64 64"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="relative z-10"
            aria-label="MOON Devil Blood Crescent Emblem"
          >
            <defs>
              <linearGradient
                id="devilMoonGradient"
                x1="10"
                y1="6"
                x2="54"
                y2="58"
                gradientUnits="userSpaceOnUse"
              >
                <stop offset="0%" stopColor="#F8FAFC" />
                <stop offset="38%" stopColor="#FDA4AF" />
                <stop offset="72%" stopColor="#E11D48" />
                <stop offset="100%" stopColor="#6D28D9" />
              </linearGradient>
              <linearGradient
                id="devilOrbitRing"
                x1="8"
                y1="52"
                x2="56"
                y2="14"
                gradientUnits="userSpaceOnUse"
              >
                <stop offset="0%" stopColor="#E11D48" stopOpacity="0.7" />
                <stop offset="50%" stopColor="#7C3AED" stopOpacity="0.25" />
                <stop offset="100%" stopColor="#F8FAFC" stopOpacity="0.0" />
              </linearGradient>
            </defs>

            {/* Subtle crimson-violet orbital arc */}
            <ellipse
              cx="32"
              cy="33"
              rx="25"
              ry="10"
              transform="rotate(-28 32 33)"
              stroke="url(#devilOrbitRing)"
              strokeWidth="1.5"
              strokeLinecap="round"
            />

            {/* Razor-sharp sculpted devil blood crescent moon */}
            <path
              d="M41.5 11.2C31.2 12.6 23.8 21.5 23.8 32.2C23.8 43.9 33.3 53.4 45 53.4C47.5 53.4 49.9 52.9 52.1 52.1C47.3 56.2 41 58.6 34.1 58.6C18.9 58.6 6.6 46.3 6.6 31.1C6.6 17.2 16.9 5.7 30.3 3.9C34.4 3.3 38.4 6.7 41.5 11.2Z"
              fill="url(#devilMoonGradient)"
            />

            {/* Minimal four-point silver-crimson star accent */}
            <path
              d="M47 16L48.3 19.7L52 21L48.3 22.3L47 26L45.7 22.3L42 21L45.7 19.7L47 16Z"
              fill="#FFE4E6"
            />
          </svg>
        </div>

        {showWordmark && (
          <div className="flex flex-col justify-center min-w-0">
            <div className="flex items-center gap-2">
              <span
                className={`font-display font-bold tracking-[0.14em] bg-gradient-to-r from-[#F8FAFC] via-[#FECDD3] to-[#C4B5FD] bg-clip-text text-transparent whitespace-nowrap shrink-0 leading-none ${dims.text}`}
              >
                MOON
              </span>
              {headerCreatorBadge && (
                <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-gradient-to-r from-[#2E1065]/90 via-[#4C0519]/90 to-[#1E0836]/90 border border-fuchsia-500/40 text-[10px] sm:text-[11px] font-semibold tracking-wide text-fuchsia-200 shadow-[0_0_14px_rgba(192,38,211,0.35)] whitespace-nowrap">
                  <span className="text-fuchsia-400">•</span>
                  <span>Aditya Chauhan</span>
                </span>
              )}
            </div>
          </div>
        )}
      </div>

      {showCreatorSubtitle && (
        <div className="flex flex-col items-center gap-1">
          <span className="font-display font-bold tracking-[0.18em] text-2xl sm:text-3xl bg-gradient-to-r from-[#F8FAFC] via-[#FECDD3] to-[#C4B5FD] bg-clip-text text-transparent">
            MOON
          </span>
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-[#1A0633]/95 via-[#3B0764]/80 to-[#4C0519]/90 border border-fuchsia-500/45 text-[11px] sm:text-xs font-semibold tracking-wide text-fuchsia-200 shadow-[0_0_20px_rgba(168,85,247,0.4)]">
            <span className="w-1.5 h-1.5 rounded-full bg-fuchsia-400 animate-pulse" />
            <span>Created by Aditya Chauhan</span>
          </span>
        </div>
      )}
    </div>
  );
};
