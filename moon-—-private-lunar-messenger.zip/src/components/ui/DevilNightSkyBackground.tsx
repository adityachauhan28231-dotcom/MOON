import React from 'react';

const STARS = [
  { top: '5%', left: '8%', size: 2.2, delay: '0s', color: '#F8FAFC' },
  { top: '9%', left: '22%', size: 1.8, delay: '1.1s', color: '#FECDD3' },
  { top: '6%', left: '38%', size: 2.5, delay: '2.3s', color: '#DDD6FE' },
  { top: '12%', left: '54%', size: 1.6, delay: '0.6s', color: '#F8FAFC' },
  { top: '7%', left: '72%', size: 2.2, delay: '1.8s', color: '#FDA4AF' },
  { top: '10%', left: '89%', size: 2.0, delay: '2.9s', color: '#E2E8F0' },
  { top: '19%', left: '14%', size: 1.8, delay: '3.1s', color: '#C4B5FD' },
  { top: '24%', left: '31%', size: 2.2, delay: '0.4s', color: '#F8FAFC' },
  { top: '18%', left: '84%', size: 1.7, delay: '2.6s', color: '#FECDD3' },
  { top: '29%', left: '6%', size: 2.0, delay: '1.4s', color: '#DDD6FE' },
  { top: '35%', left: '92%', size: 2.2, delay: '2.0s', color: '#FDA4AF' },
  { top: '44%', left: '11%', size: 1.8, delay: '3.5s', color: '#F8FAFC' },
  { top: '49%', left: '87%', size: 2.0, delay: '0.8s', color: '#C4B5FD' },
  { top: '58%', left: '18%', size: 1.6, delay: '2.4s', color: '#FECDD3' },
  { top: '64%', left: '79%', size: 2.2, delay: '1.2s', color: '#E2E8F0' },
  { top: '71%', left: '9%', size: 2.0, delay: '3.0s', color: '#FDA4AF' },
  { top: '77%', left: '64%', size: 1.8, delay: '0.5s', color: '#DDD6FE' },
  { top: '83%', left: '29%', size: 2.2, delay: '1.9s', color: '#F8FAFC' },
  { top: '88%', left: '88%', size: 1.8, delay: '2.7s', color: '#FECDD3' },
  { top: '15%', left: '45%', size: 1.6, delay: '1.6s', color: '#F8FAFC' },
];

const EMBERS = [
  { top: '74%', left: '16%', size: 4.5, delay: '0s', color: 'rgba(244,63,94,0.75)' },
  { top: '62%', left: '78%', size: 5.5, delay: '2.1s', color: 'rgba(225,29,72,0.7)' },
  { top: '48%', left: '64%', size: 4.0, delay: '4.2s', color: 'rgba(168,85,247,0.65)' },
  { top: '78%', left: '46%', size: 4.5, delay: '1.4s', color: 'rgba(251,113,133,0.75)' },
  { top: '38%', left: '84%', size: 4.0, delay: '5.6s', color: 'rgba(225,29,72,0.7)' },
  { top: '66%', left: '12%', size: 5.0, delay: '3.2s', color: 'rgba(192,132,252,0.65)' },
  { top: '54%', left: '34%', size: 3.8, delay: '6.4s', color: 'rgba(244,63,94,0.68)' },
  { top: '82%', left: '71%', size: 4.8, delay: '2.8s', color: 'rgba(139,92,246,0.6)' },
  { top: '42%', left: '24%', size: 4.2, delay: '4.9s', color: 'rgba(251,113,133,0.68)' },
];

/**
 * Giant 3D Glowing Devil Blood Moon Background
 * - Pure AMOLED #000000 night sky
 * - Giant photorealistic 3D crimson Blood Moon with lunar maria, ray craters,
 *   3D spherical terminator shadow, and glowing solar-eclipse rim
 * - Slowly moving dark clouds BEHIND the Moon (z-10)
 * - Slowly moving realistic dark crimson-rimmed clouds IN FRONT OF the Moon (z-30)
 * - Moving & twinkling starfield + floating glowing ember particles
 * - Lightweight GPU-accelerated CSS transforms for Android battery efficiency
 */
export const DevilNightSkyBackground: React.FC = () => {
  return (
    <div
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 z-0 overflow-hidden bg-black select-none"
    >
      {/* Pure AMOLED Black Base + Deep Crimson-Violet Celestial Glow */}
      <div
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(circle at 58% 28%, rgba(185, 28, 28, 0.34) 0%, rgba(109, 40, 217, 0.18) 34%, rgba(24, 4, 20, 0.55) 56%, #000000 80%)',
        }}
      />

      {/* Slowly Moving & Twinkling Starfield Layer */}
      <div className="absolute inset-[-4%] z-[5] animate-devil-starfield">
        {STARS.map((star, idx) => (
          <span
            key={idx}
            className="absolute rounded-full animate-devil-twinkle"
            style={{
              top: star.top,
              left: star.left,
              width: `${star.size}px`,
              height: `${star.size}px`,
              backgroundColor: star.color,
              boxShadow: `0 0 8px ${star.color}`,
              animationDelay: star.delay,
            }}
          />
        ))}
      </div>

      {/* Occasional Subtle Shooting Star */}
      <div
        className="absolute top-[10%] right-[16%] z-[6] w-32 h-[1.5px] rounded-full animate-devil-shooting-star"
        style={{
          background:
            'linear-gradient(90deg, rgba(255,228,230,0.95) 0%, rgba(244,63,94,0.65) 45%, transparent 100%)',
          boxShadow: '0 0 12px rgba(244,63,94,0.75)',
        }}
      />

      {/* =====================================================================
          LAYER 1 (z-10): SLOWLY MOVING REALISTIC DARK CLOUDS BEHIND THE MOON
         ===================================================================== */}
      <div className="
        absolute z-10
        top-[8%] sm:top-[6%] left-[-18%] right-[-18%]
        h-[340px] sm:h-[440px]
        animate-devil-cloud-back
      ">
        <svg
          viewBox="0 0 1400 420"
          preserveAspectRatio="none"
          className="w-full h-full opacity-85"
        >
          <defs>
            <linearGradient id="backCloudGrad" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#4C0519" stopOpacity="0.55" />
              <stop offset="45%" stopColor="#1A051D" stopOpacity="0.82" />
              <stop offset="100%" stopColor="#030106" stopOpacity="0.95" />
            </linearGradient>
            <linearGradient id="backCloudRim" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#881337" stopOpacity="0.1" />
              <stop offset="50%" stopColor="#E11D48" stopOpacity="0.48" />
              <stop offset="100%" stopColor="#581C87" stopOpacity="0.15" />
            </linearGradient>
          </defs>
          {/* Distant dark storm cloud bank behind the Blood Moon */}
          <path
            d="M -60 320
               C 80 250, 190 210, 320 235
               C 430 155, 590 130, 740 190
               C 860 125, 1040 145, 1170 220
               C 1270 195, 1370 230, 1460 290
               L 1460 420 L -60 420 Z"
            fill="url(#backCloudGrad)"
            stroke="url(#backCloudRim)"
            strokeWidth="2"
          />
        </svg>
      </div>

      {/* =====================================================================
          LAYER 2 (z-20): GIANT 3D GLOWING DEVIL BLOOD MOON
          Positioned prominently so it stays clearly visible on Friends & Chat
         ===================================================================== */}
      <div
        className="
          absolute z-20
          top-[3%] sm:top-[2%] lg:top-[3%]
          left-1/2 -translate-x-1/2 lg:left-[56%] lg:-translate-x-1/2
          w-[330px] h-[330px] sm:w-[460px] sm:h-[460px] lg:w-[560px] lg:h-[560px]
          flex items-center justify-center
        "
      >
        <div className="relative w-full h-full flex items-center justify-center animate-devil-moon">
          {/* Giant Outer Crimson-Violet Eclipse Corona Halo */}
          <div
            className="absolute inset-[-12%] rounded-full animate-devil-corona"
            style={{
              background:
                'radial-gradient(circle, rgba(225, 29, 72, 0.48) 0%, rgba(185, 28, 28, 0.34) 36%, rgba(109, 40, 217, 0.22) 56%, rgba(0, 0, 0, 0) 76%)',
              filter: 'blur(20px)',
            }}
          />

          {/* Secondary Tight Eclipse Rim Glow */}
          <div
            className="absolute inset-[6%] rounded-full"
            style={{
              background:
                'radial-gradient(circle, rgba(251, 113, 133, 0.32) 0%, rgba(220, 38, 38, 0.28) 54%, transparent 72%)',
              filter: 'blur(10px)',
            }}
          />

          {/* Giant 3D Blood Moon SVG */}
          <svg
            viewBox="0 0 500 500"
            className="relative w-full h-full overflow-visible drop-shadow-[0_0_55px_rgba(225,29,72,0.55)]"
          >
            <defs>
              {/* Clip path for 3D lunar sphere internal details */}
              <clipPath id="giantBloodMoonClip">
                <circle cx="250" cy="256" r="172" />
              </clipPath>

              {/* Photorealistic 3D Spherical Blood Moon Base Gradient */}
              <radialGradient id="giantBloodSphere3D" cx="34%" cy="28%" r="72%" fx="28%" fy="24%">
                <stop offset="0%" stopColor="#FFF1F2" />
                <stop offset="8%" stopColor="#FDA4AF" />
                <stop offset="22%" stopColor="#F43F5E" />
                <stop offset="44%" stopColor="#DC2626" />
                <stop offset="66%" stopColor="#991B1B" />
                <stop offset="84%" stopColor="#450A0A" />
                <stop offset="95%" stopColor="#24052E" />
                <stop offset="100%" stopColor="#08010D" />
              </radialGradient>

              {/* 3D Terminator Shadow Overlay for Deep Spherical Volume */}
              <radialGradient id="lunarTerminator3D" cx="76%" cy="74%" r="65%">
                <stop offset="0%" stopColor="#040108" stopOpacity="0.82" />
                <stop offset="45%" stopColor="#1F0318" stopOpacity="0.48" />
                <stop offset="78%" stopColor="#7F1D1D" stopOpacity="0.12" />
                <stop offset="100%" stopColor="#000000" stopOpacity="0" />
              </radialGradient>

              {/* Inner Limb Atmospheric Backscatter (3D Fresnel Rim Light) */}
              <radialGradient id="lunarFresnelRim" cx="50%" cy="50%" r="50%">
                <stop offset="78%" stopColor="#DC2626" stopOpacity="0" />
                <stop offset="92%" stopColor="#FB7185" stopOpacity="0.28" />
                <stop offset="97%" stopColor="#FFE4E6" stopOpacity="0.58" />
                <stop offset="100%" stopColor="#F43F5E" stopOpacity="0.85" />
              </radialGradient>

              {/* Glowing Eclipse Outer Rim Stroke */}
              <linearGradient id="eclipseRimStroke" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.95" />
                <stop offset="28%" stopColor="#FB7185" stopOpacity="0.9" />
                <stop offset="65%" stopColor="#E11D48" stopOpacity="0.75" />
                <stop offset="100%" stopColor="#7C3AED" stopOpacity="0.65" />
              </linearGradient>

              {/* Devil Eclipse Horns Gradient */}
              <linearGradient id="devilEclipseHorns" x1="0%" y1="100%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#4C0519" stopOpacity="0.2" />
                <stop offset="45%" stopColor="#E11D48" stopOpacity="0.75" />
                <stop offset="100%" stopColor="#FFE4E6" stopOpacity="0.92" />
              </linearGradient>

              {/* Lunar Mare Basaltic Shadow Gradient */}
              <radialGradient id="mareBasaltGrad" cx="45%" cy="45%" r="58%">
                <stop offset="0%" stopColor="#2A0312" stopOpacity="0.68" />
                <stop offset="65%" stopColor="#450A1F" stopOpacity="0.45" />
                <stop offset="100%" stopColor="#7F1D1D" stopOpacity="0" />
              </radialGradient>
            </defs>

            {/* Gothic Devil Eclipse Horns Framing the Giant Blood Moon */}
            <path
              d="M 94 202 C 62 122, 102 44, 166 20 C 128 66, 124 128, 146 174 Z"
              fill="url(#devilEclipseHorns)"
              opacity="0.85"
            />
            <path
              d="M 406 202 C 438 122, 398 44, 334 20 C 372 66, 376 128, 354 174 Z"
              fill="url(#devilEclipseHorns)"
              opacity="0.85"
            />

            {/* Outer Glowing Solar-Eclipse Corona Ring */}
            <circle
              cx="250"
              cy="256"
              r="176"
              fill="none"
              stroke="url(#eclipseRimStroke)"
              strokeWidth="2.5"
              opacity="0.65"
            />

            {/* Main Giant 3D Blood Moon Sphere */}
            <g clipPath="url(#giantBloodMoonClip)">
              <circle
                cx="250"
                cy="256"
                r="172"
                fill="url(#giantBloodSphere3D)"
              />

              {/* Detailed Lunar Maria (Dark Crimson Basaltic Plains) */}
              {/* Mare Imbrium & Oceanus Procellarum (Upper Left / Center Left) */}
              <ellipse
                cx="188"
                cy="196"
                rx="64"
                ry="48"
                transform="rotate(-18 188 196)"
                fill="url(#mareBasaltGrad)"
              />
              <ellipse
                cx="148"
                cy="264"
                rx="52"
                ry="68"
                transform="rotate(12 148 264)"
                fill="url(#mareBasaltGrad)"
              />

              {/* Mare Serenitatis & Mare Tranquillitatis (Center Right) */}
              <ellipse
                cx="278"
                cy="208"
                rx="48"
                ry="38"
                transform="rotate(15 278 208)"
                fill="url(#mareBasaltGrad)"
              />
              <ellipse
                cx="316"
                cy="266"
                rx="54"
                ry="40"
                transform="rotate(-12 316 266)"
                fill="url(#mareBasaltGrad)"
              />

              {/* Mare Crisium (Upper Right Limb) */}
              <ellipse
                cx="368"
                cy="198"
                rx="26"
                ry="34"
                transform="rotate(24 368 198)"
                fill="#2D0414"
                opacity="0.55"
              />

              {/* Mare Humorum & Mare Nubium (Lower Center) */}
              <ellipse
                cx="224"
                cy="322"
                rx="56"
                ry="34"
                transform="rotate(-8 224 322)"
                fill="url(#mareBasaltGrad)"
              />

              {/* Subtle Tycho & Copernicus Crater Ray Ejecta Lines */}
              <g stroke="#FECDD3" strokeWidth="1" opacity="0.22">
                <line x1="216" y1="354" x2="128" y2="292" />
                <line x1="216" y1="354" x2="162" y2="236" />
                <line x1="216" y1="354" x2="288" y2="268" />
                <line x1="216" y1="354" x2="324" y2="366" />
                <line x1="216" y1="354" x2="195" y2="416" />
                <line x1="184" y1="242" x2="112" y2="196" />
                <line x1="184" y1="242" x2="246" y2="178" />
              </g>

              {/* 3D Terraced Lunar Impact Craters (Shadow + Illuminated Rim) */}
              {/* Tycho Crater (Southern Hemisphere) */}
              <circle cx="216" cy="354" r="16" fill="#2A0415" opacity="0.65" />
              <circle
                cx="218"
                cy="356"
                r="16"
                fill="none"
                stroke="#FDA4AF"
                strokeWidth="1.5"
                opacity="0.55"
              />
              <circle cx="216" cy="354" r="4" fill="#FFE4E6" opacity="0.6" />

              {/* Copernicus Crater */}
              <circle cx="184" cy="242" r="20" fill="#2A0415" opacity="0.58" />
              <circle
                cx="186"
                cy="244"
                r="20"
                fill="none"
                stroke="#FECDD3"
                strokeWidth="1.4"
                opacity="0.5"
              />
              <circle cx="184" cy="242" r="5" fill="#FDA4AF" opacity="0.55" />

              {/* Plato & Archimedes Craters */}
              <circle cx="212" cy="134" r="14" fill="#230312" opacity="0.62" />
              <circle
                cx="214"
                cy="135"
                r="14"
                fill="none"
                stroke="#FCA5A5"
                strokeWidth="1.2"
                opacity="0.45"
              />
              <circle cx="136" cy="186" r="11" fill="#2A0415" opacity="0.55" />
              <circle cx="304" cy="158" r="12" fill="#2A0415" opacity="0.5" />
              <circle cx="342" cy="314" r="15" fill="#1F0210" opacity="0.58" />
              <circle cx="268" cy="288" r="9" fill="#2A0415" opacity="0.5" />
              <circle cx="152" cy="322" r="12" fill="#2A0415" opacity="0.52" />

              {/* 3D Spherical Terminator Shadow for Realism */}
              <circle
                cx="250"
                cy="256"
                r="172"
                fill="url(#lunarTerminator3D)"
              />

              {/* 3D Fresnel Glowing Eclipse Rim Inside Sphere */}
              <circle
                cx="250"
                cy="256"
                r="172"
                fill="url(#lunarFresnelRim)"
              />
            </g>

            {/* Crisp Glowing Eclipse Rim Border Around the Sphere */}
            <circle
              cx="250"
              cy="256"
              r="172"
              fill="none"
              stroke="url(#eclipseRimStroke)"
              strokeWidth="2.2"
            />

            {/* Upper-Left Solar-Eclipse Diamond Rim Highlight Arc */}
            <path
              d="M 96 180 A 172 172 0 0 1 312 96"
              fill="none"
              stroke="#FFF1F2"
              strokeWidth="3"
              strokeLinecap="round"
              opacity="0.75"
            />

            {/* Lower-Right Violet-Crimson Eclipse Limb Arc */}
            <path
              d="M 404 332 A 172 172 0 0 1 162 404"
              fill="none"
              stroke="#C084FC"
              strokeWidth="2.2"
              strokeLinecap="round"
              opacity="0.55"
            />
          </svg>
        </div>
      </div>

      {/* =====================================================================
          LAYER 3 (z-30): SLOWLY MOVING REALISTIC DARK CLOUDS IN FRONT OF MOON
          Drifts directly across the middle and lower face of the Blood Moon
         ===================================================================== */}
      <div
        className="
          absolute z-30
          top-[14%] sm:top-[16%] lg:top-[18%]
          left-[-20%] right-[-20%]
          h-[260px] sm:h-[340px]
          animate-devil-cloud-front
        "
      >
        <svg
          viewBox="0 0 1440 320"
          preserveAspectRatio="none"
          className="w-full h-full opacity-90 drop-shadow-[0_12px_28px_rgba(0,0,0,0.95)]"
        >
          <defs>
            <linearGradient id="frontDarkCloud1" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#2A0514" stopOpacity="0.88" />
              <stop offset="38%" stopColor="#0D020A" stopOpacity="0.94" />
              <stop offset="100%" stopColor="#000000" stopOpacity="0" />
            </linearGradient>
            <linearGradient id="frontCloudCrimsonEdge" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#9F1239" stopOpacity="0.15" />
              <stop offset="35%" stopColor="#FB7185" stopOpacity="0.75" />
              <stop offset="65%" stopColor="#E11D48" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#6D28D9" stopOpacity="0.2" />
            </linearGradient>
          </defs>

          {/* Foreground sculpted dark cloud bank 1 passing across the Moon */}
          <path
            d="M 80 185
               C 190 140, 290 125, 410 155
               C 510 95, 650 88, 770 142
               C 880 92, 1020 105, 1130 158
               C 1220 138, 1310 155, 1390 190
               C 1260 235, 1040 250, 760 245
               C 460 250, 240 232, 80 185 Z"
            fill="url(#frontDarkCloud1)"
          />
          {/* Glowing crimson-lit top edge of the foreground cloud */}
          <path
            d="M 80 185
               C 190 140, 290 125, 410 155
               C 510 95, 650 88, 770 142
               C 880 92, 1020 105, 1130 158
               C 1220 138, 1310 155, 1390 190"
            fill="none"
            stroke="url(#frontCloudCrimsonEdge)"
            strokeWidth="2.2"
            strokeLinecap="round"
          />
        </svg>
      </div>

      {/* Second Foreground Cloud Bank (Counter-Drifting Across Lower Moon) */}
      <div
        className="
          absolute z-30
          top-[26%] sm:top-[30%] lg:top-[32%]
          left-[-22%] right-[-22%]
          h-[240px] sm:h-[300px]
          animate-devil-cloud-front-alt
        "
      >
        <svg
          viewBox="0 0 1440 280"
          preserveAspectRatio="none"
          className="w-full h-full opacity-80"
        >
          <defs>
            <linearGradient id="frontDarkCloud2" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#1E0416" stopOpacity="0.82" />
              <stop offset="45%" stopColor="#070109" stopOpacity="0.9" />
              <stop offset="100%" stopColor="#000000" stopOpacity="0" />
            </linearGradient>
          </defs>
          <path
            d="M -40 165
               C 120 120, 280 112, 430 148
               C 570 98, 730 102, 890 145
               C 1030 108, 1190 118, 1360 162
               C 1180 215, 910 228, 640 224
               C 340 226, 110 208, -40 165 Z"
            fill="url(#frontDarkCloud2)"
          />
        </svg>
      </div>

      {/* =====================================================================
          LAYER 4 (z-35): FLOATING GLOWING CRIMSON & VIOLET PARTICLES
         ===================================================================== */}
      {EMBERS.map((ember, idx) => (
        <span
          key={idx}
          className="absolute z-30 rounded-full animate-devil-ember"
          style={{
            top: ember.top,
            left: ember.left,
            width: `${ember.size}px`,
            height: `${ember.size}px`,
            backgroundColor: ember.color,
            boxShadow: `0 0 14px ${ember.color}`,
            animationDelay: ember.delay,
          }}
        />
      ))}
    </div>
  );
};
