import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import {registerMoonServiceWorker} from './hooks/usePWAInstall.ts';

registerMoonServiceWorker();

createRoot(document.getElementById('root')!).render(<App />);

