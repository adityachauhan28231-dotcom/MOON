/**
 * MOON — Private Lunar Messenger Service Worker
 * Strictly caches only static app shell assets (icons, manifest).
 * NEVER caches or intercepts:
 * - /api/* backend endpoints (LiveKit tokens, MOON AI, etc.)
 * - Supabase Auth, REST, or Realtime requests
 * - LiveKit Cloud signaling or WebRTC traffic
 * - Non-GET requests
 */

const CACHE_NAME = 'moon-pwa-shell-v1';
const STATIC_SHELL_ASSETS = [
  '/manifest.json',
  '/icon.svg',
  '/pwa-192x192.png',
  '/pwa-512x512.png',
  '/pwa-maskable-512x512.png',
  '/apple-touch-icon.png',
];

self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches
      .open(CACHE_NAME)
      .then((cache) => cache.addAll(STATIC_SHELL_ASSETS))
      .catch(() => {
        // Non-fatal if an optional asset is not yet cached
      })
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys
            .filter((key) => key !== CACHE_NAME)
            .map((oldKey) => caches.delete(oldKey))
        )
      )
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const request = event.request;

  // Never intercept non-GET requests
  if (request.method !== 'GET') {
    return;
  }

  let url;
  try {
    url = new URL(request.url);
  } catch {
    return;
  }

  // Strictly bypass cross-origin traffic (Supabase, LiveKit Cloud, WebRTC, fonts, etc.)
  if (url.origin !== self.location.origin) {
    return;
  }

  // Strictly bypass all backend API routes, auth callbacks, and websocket upgrades
  if (
    url.pathname.startsWith('/api/') ||
    url.pathname.startsWith('/auth/') ||
    url.pathname.startsWith('/rest/') ||
    url.pathname.startsWith('/realtime/') ||
    request.headers.get('upgrade') === 'websocket'
  ) {
    return;
  }

  // For static PWA icons and manifest: serve from network first, falling back to cache
  if (STATIC_SHELL_ASSETS.includes(url.pathname)) {
    event.respondWith(
      fetch(request)
        .then((response) => {
          if (response && response.status === 200) {
            const cloned = response.clone();
            caches
              .open(CACHE_NAME)
              .then((cache) => cache.put(request, cloned))
              .catch(() => {});
          }
          return response;
        })
        .catch(() => caches.match(request))
    );
  }
});
